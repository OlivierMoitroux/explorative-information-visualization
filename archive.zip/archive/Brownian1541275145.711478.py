# Get this figure: fig = py.get_figure("https://plot.ly/~harry11733/105/")
# Get this figure's data: data = py.get_figure("https://plot.ly/~harry11733/105/").get_data()
# Add data to this figure: py.plot(Data([Scatter(x=[1, 2], y=[2, 3])]), filename ="Brownian1541275145.711478", fileopt="extend")
# Get y data of first trace: y1 = py.get_figure("https://plot.ly/~harry11733/105/").get_data()[0]["y"]

# Get figure documentation: https://plot.ly/python/get-requests/
# Add data documentation: https://plot.ly/python/file-options/

# If you're using unicode in your file, you may need to specify the encoding.
# You can reproduce this figure in Python with the following code!

# Learn about API authentication here: https://plot.ly/python/getting-started
# Find your api_key here: https://plot.ly/settings/api

import plotly.plotly as py
from plotly.graph_objs import *
py.sign_in('username', 'api_key')
trace1 = {
  "mode": "markers", 
  "name": "f0", 
  "type": "scatter", 
  "xsrc": "harry11733:104:b51c2a", 
  "x": [-0.482, -1.193, -1.373, -3.41, -0.447, -2.119, -3.038, -0.437, -1.314, -3.715, -0.642, -2.874, -2.806, -3.086, -1.307, -2.07, -2.257, -2.502, -1.04, -2.049, -0.142, -1.791, -2.478, -1.748, -3.48, -1.289, -3.809, -1.783, -1.943, -2.694, -2.947, -0.676, -3.663, -2.986, -0.237, -2.221, -0.151, -3.501, -3.31, -2.473, -1.544, -2.685, -2.583, -3.108, -0.635, -3.265, -1.241, -0.15, -3.69, -0.684], 
  "ysrc": "harry11733:104:b32d2a", 
  "y": [3.511, 2.824, -2.217, 1.97, -2.575, 0.025, 3.733, -3.316, -1.363, -0.757, -0.623, -3.598, 1.087, -2.352, -0.982, 0.425, -3.589, 3.022, 0.669, -0.638, -3.693, 3.77, -0.816, -3.714, 3.271, -0.303, -0.559, -3.393, 1.162, -2.546, -2.14, -3.591, -3.816, 2.995, -1.791, -1.993, -0.343, 2.004, -2.327, -2.481, 0.91, -3.441, 1.863, 1.802, -2.717, 0.025, -3.084, -1.542, -3.581, 0.578], 
  "xaxis": "x1", 
  "yaxis": "y1", 
  "marker": {
    "size": 6, 
    "color": "#990000"
  }, 
  "showlegend": False
}
trace2 = {
  "line": {
    "color": "red", 
    "width": 3
  }, 
  "mode": "lines", 
  "name": "f1", 
  "type": "scatter", 
  "xsrc": "harry11733:104:a4fa8e", 
  "x": [0.0, 0.0], 
  "ysrc": "harry11733:104:72b2c9", 
  "y": [-4.0, 4.0], 
  "xaxis": "x1", 
  "yaxis": "y1", 
  "showlegend": False
}
trace3 = {
  "mode": "markers", 
  "name": "f2", 
  "type": "scatter", 
  "xsrc": "harry11733:104:a2c6d9", 
  "x": [0], 
  "ysrc": "harry11733:104:4c97e2", 
  "y": [0.0], 
  "xaxis": "x2", 
  "yaxis": "y2", 
  "marker": {
    "size": 3, 
    "color": "#3b528b"
  }, 
  "showlegend": False
}
data = Data([trace1, trace2, trace3])
layout = {
  "width": 500, 
  "height": 240, 
  "margin": {
    "b": 2, 
    "l": 2, 
    "r": 2, 
    "t": 4
  }, 
  "xaxis1": {
    "range": [-4.0, 4.0], 
    "anchor": "y1", 
    "domain": [0.0, 0.44], 
    "mirror": True, 
    "showgrid": False, 
    "showline": True, 
    "zeroline": False, 
    "linecolor": "#808080", 
    "linewidth": 3, 
    "showspikes": False, 
    "showticklabels": False
  }, 
  "xaxis2": {
    "range": [0, 201], 
    "title": "Time", 
    "anchor": "y2", 
    "domain": [0.62, 1.0], 
    "showgrid": False, 
    "showline": True, 
    "zeroline": False, 
    "showticklabels": False
  }, 
  "yaxis1": {
    "range": [-4.0, 4.0], 
    "anchor": "x1", 
    "domain": [0.0, 1.0], 
    "mirror": True, 
    "showgrid": False, 
    "showline": True, 
    "zeroline": False, 
    "linecolor": "#808080", 
    "linewidth": 3, 
    "showspikes": False, 
    "showticklabels": False
  }, 
  "yaxis2": {
    "range": [-0.01, 1.1], 
    "title": "Entropy", 
    "anchor": "x2", 
    "domain": [0.0, 1.0], 
    "showline": True, 
    "tickmode": "array", 
    "ticktext": ["Equil."], 
    "tickvals": [1.0], 
    "zeroline": False, 
    "showticklabels": True
  }, 
  "sliders": [
    {
      "x": 0.1, 
      "y": 0, 
      "len": 0.4, 
      "pad": {
        "b": -25, 
        "t": 10
      }, 
      "font": {"color": "rgba(0,0,0,0)"}, 
      "steps": [
        {
          "args": [
            [0], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 0, 
          "method": "animate"
        }, 
        {
          "args": [
            [1], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 1, 
          "method": "animate"
        }, 
        {
          "args": [
            [2], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 2, 
          "method": "animate"
        }, 
        {
          "args": [
            [3], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 3, 
          "method": "animate"
        }, 
        {
          "args": [
            [4], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 4, 
          "method": "animate"
        }, 
        {
          "args": [
            [5], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 5, 
          "method": "animate"
        }, 
        {
          "args": [
            [6], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 6, 
          "method": "animate"
        }, 
        {
          "args": [
            [7], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 7, 
          "method": "animate"
        }, 
        {
          "args": [
            [8], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 8, 
          "method": "animate"
        }, 
        {
          "args": [
            [9], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 9, 
          "method": "animate"
        }, 
        {
          "args": [
            [10], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 10, 
          "method": "animate"
        }, 
        {
          "args": [
            [11], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 11, 
          "method": "animate"
        }, 
        {
          "args": [
            [12], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 12, 
          "method": "animate"
        }, 
        {
          "args": [
            [13], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 13, 
          "method": "animate"
        }, 
        {
          "args": [
            [14], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 14, 
          "method": "animate"
        }, 
        {
          "args": [
            [15], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 15, 
          "method": "animate"
        }, 
        {
          "args": [
            [16], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 16, 
          "method": "animate"
        }, 
        {
          "args": [
            [17], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 17, 
          "method": "animate"
        }, 
        {
          "args": [
            [18], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 18, 
          "method": "animate"
        }, 
        {
          "args": [
            [19], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 19, 
          "method": "animate"
        }, 
        {
          "args": [
            [20], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 20, 
          "method": "animate"
        }, 
        {
          "args": [
            [21], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 21, 
          "method": "animate"
        }, 
        {
          "args": [
            [22], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 22, 
          "method": "animate"
        }, 
        {
          "args": [
            [23], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 23, 
          "method": "animate"
        }, 
        {
          "args": [
            [24], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 24, 
          "method": "animate"
        }, 
        {
          "args": [
            [25], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 25, 
          "method": "animate"
        }, 
        {
          "args": [
            [26], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 26, 
          "method": "animate"
        }, 
        {
          "args": [
            [27], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 27, 
          "method": "animate"
        }, 
        {
          "args": [
            [28], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 28, 
          "method": "animate"
        }, 
        {
          "args": [
            [29], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 29, 
          "method": "animate"
        }, 
        {
          "args": [
            [30], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 30, 
          "method": "animate"
        }, 
        {
          "args": [
            [31], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 31, 
          "method": "animate"
        }, 
        {
          "args": [
            [32], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 32, 
          "method": "animate"
        }, 
        {
          "args": [
            [33], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 33, 
          "method": "animate"
        }, 
        {
          "args": [
            [34], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 34, 
          "method": "animate"
        }, 
        {
          "args": [
            [35], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 35, 
          "method": "animate"
        }, 
        {
          "args": [
            [36], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 36, 
          "method": "animate"
        }, 
        {
          "args": [
            [37], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 37, 
          "method": "animate"
        }, 
        {
          "args": [
            [38], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 38, 
          "method": "animate"
        }, 
        {
          "args": [
            [39], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 39, 
          "method": "animate"
        }, 
        {
          "args": [
            [40], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 40, 
          "method": "animate"
        }, 
        {
          "args": [
            [41], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 41, 
          "method": "animate"
        }, 
        {
          "args": [
            [42], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 42, 
          "method": "animate"
        }, 
        {
          "args": [
            [43], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 43, 
          "method": "animate"
        }, 
        {
          "args": [
            [44], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 44, 
          "method": "animate"
        }, 
        {
          "args": [
            [45], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 45, 
          "method": "animate"
        }, 
        {
          "args": [
            [46], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 46, 
          "method": "animate"
        }, 
        {
          "args": [
            [47], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 47, 
          "method": "animate"
        }, 
        {
          "args": [
            [48], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 48, 
          "method": "animate"
        }, 
        {
          "args": [
            [49], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 49, 
          "method": "animate"
        }, 
        {
          "args": [
            [50], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 50, 
          "method": "animate"
        }, 
        {
          "args": [
            [51], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 51, 
          "method": "animate"
        }, 
        {
          "args": [
            [52], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 52, 
          "method": "animate"
        }, 
        {
          "args": [
            [53], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 53, 
          "method": "animate"
        }, 
        {
          "args": [
            [54], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 54, 
          "method": "animate"
        }, 
        {
          "args": [
            [55], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 55, 
          "method": "animate"
        }, 
        {
          "args": [
            [56], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 56, 
          "method": "animate"
        }, 
        {
          "args": [
            [57], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 57, 
          "method": "animate"
        }, 
        {
          "args": [
            [58], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 58, 
          "method": "animate"
        }, 
        {
          "args": [
            [59], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 59, 
          "method": "animate"
        }, 
        {
          "args": [
            [60], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 60, 
          "method": "animate"
        }, 
        {
          "args": [
            [61], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 61, 
          "method": "animate"
        }, 
        {
          "args": [
            [62], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 62, 
          "method": "animate"
        }, 
        {
          "args": [
            [63], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 63, 
          "method": "animate"
        }, 
        {
          "args": [
            [64], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 64, 
          "method": "animate"
        }, 
        {
          "args": [
            [65], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 65, 
          "method": "animate"
        }, 
        {
          "args": [
            [66], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 66, 
          "method": "animate"
        }, 
        {
          "args": [
            [67], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 67, 
          "method": "animate"
        }, 
        {
          "args": [
            [68], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 68, 
          "method": "animate"
        }, 
        {
          "args": [
            [69], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 69, 
          "method": "animate"
        }, 
        {
          "args": [
            [70], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 70, 
          "method": "animate"
        }, 
        {
          "args": [
            [71], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 71, 
          "method": "animate"
        }, 
        {
          "args": [
            [72], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 72, 
          "method": "animate"
        }, 
        {
          "args": [
            [73], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 73, 
          "method": "animate"
        }, 
        {
          "args": [
            [74], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 74, 
          "method": "animate"
        }, 
        {
          "args": [
            [75], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 75, 
          "method": "animate"
        }, 
        {
          "args": [
            [76], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 76, 
          "method": "animate"
        }, 
        {
          "args": [
            [77], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 77, 
          "method": "animate"
        }, 
        {
          "args": [
            [78], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 78, 
          "method": "animate"
        }, 
        {
          "args": [
            [79], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 79, 
          "method": "animate"
        }, 
        {
          "args": [
            [80], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 80, 
          "method": "animate"
        }, 
        {
          "args": [
            [81], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 81, 
          "method": "animate"
        }, 
        {
          "args": [
            [82], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 82, 
          "method": "animate"
        }, 
        {
          "args": [
            [83], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 83, 
          "method": "animate"
        }, 
        {
          "args": [
            [84], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 84, 
          "method": "animate"
        }, 
        {
          "args": [
            [85], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 85, 
          "method": "animate"
        }, 
        {
          "args": [
            [86], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 86, 
          "method": "animate"
        }, 
        {
          "args": [
            [87], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 87, 
          "method": "animate"
        }, 
        {
          "args": [
            [88], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 88, 
          "method": "animate"
        }, 
        {
          "args": [
            [89], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 89, 
          "method": "animate"
        }, 
        {
          "args": [
            [90], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 90, 
          "method": "animate"
        }, 
        {
          "args": [
            [91], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 91, 
          "method": "animate"
        }, 
        {
          "args": [
            [92], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 92, 
          "method": "animate"
        }, 
        {
          "args": [
            [93], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 93, 
          "method": "animate"
        }, 
        {
          "args": [
            [94], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 94, 
          "method": "animate"
        }, 
        {
          "args": [
            [95], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 95, 
          "method": "animate"
        }, 
        {
          "args": [
            [96], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 96, 
          "method": "animate"
        }, 
        {
          "args": [
            [97], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 97, 
          "method": "animate"
        }, 
        {
          "args": [
            [98], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 98, 
          "method": "animate"
        }, 
        {
          "args": [
            [99], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 99, 
          "method": "animate"
        }, 
        {
          "args": [
            [100], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 100, 
          "method": "animate"
        }, 
        {
          "args": [
            [101], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 101, 
          "method": "animate"
        }, 
        {
          "args": [
            [102], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 102, 
          "method": "animate"
        }, 
        {
          "args": [
            [103], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 103, 
          "method": "animate"
        }, 
        {
          "args": [
            [104], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 104, 
          "method": "animate"
        }, 
        {
          "args": [
            [105], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 105, 
          "method": "animate"
        }, 
        {
          "args": [
            [106], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 106, 
          "method": "animate"
        }, 
        {
          "args": [
            [107], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 107, 
          "method": "animate"
        }, 
        {
          "args": [
            [108], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 108, 
          "method": "animate"
        }, 
        {
          "args": [
            [109], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 109, 
          "method": "animate"
        }, 
        {
          "args": [
            [110], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 110, 
          "method": "animate"
        }, 
        {
          "args": [
            [111], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 111, 
          "method": "animate"
        }, 
        {
          "args": [
            [112], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 112, 
          "method": "animate"
        }, 
        {
          "args": [
            [113], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 113, 
          "method": "animate"
        }, 
        {
          "args": [
            [114], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 114, 
          "method": "animate"
        }, 
        {
          "args": [
            [115], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 115, 
          "method": "animate"
        }, 
        {
          "args": [
            [116], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 116, 
          "method": "animate"
        }, 
        {
          "args": [
            [117], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 117, 
          "method": "animate"
        }, 
        {
          "args": [
            [118], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 118, 
          "method": "animate"
        }, 
        {
          "args": [
            [119], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 119, 
          "method": "animate"
        }, 
        {
          "args": [
            [120], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 120, 
          "method": "animate"
        }, 
        {
          "args": [
            [121], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 121, 
          "method": "animate"
        }, 
        {
          "args": [
            [122], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 122, 
          "method": "animate"
        }, 
        {
          "args": [
            [123], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 123, 
          "method": "animate"
        }, 
        {
          "args": [
            [124], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 124, 
          "method": "animate"
        }, 
        {
          "args": [
            [125], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 125, 
          "method": "animate"
        }, 
        {
          "args": [
            [126], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 126, 
          "method": "animate"
        }, 
        {
          "args": [
            [127], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 127, 
          "method": "animate"
        }, 
        {
          "args": [
            [128], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 128, 
          "method": "animate"
        }, 
        {
          "args": [
            [129], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 129, 
          "method": "animate"
        }, 
        {
          "args": [
            [130], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 130, 
          "method": "animate"
        }, 
        {
          "args": [
            [131], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 131, 
          "method": "animate"
        }, 
        {
          "args": [
            [132], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 132, 
          "method": "animate"
        }, 
        {
          "args": [
            [133], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 133, 
          "method": "animate"
        }, 
        {
          "args": [
            [134], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 134, 
          "method": "animate"
        }, 
        {
          "args": [
            [135], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 135, 
          "method": "animate"
        }, 
        {
          "args": [
            [136], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 136, 
          "method": "animate"
        }, 
        {
          "args": [
            [137], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 137, 
          "method": "animate"
        }, 
        {
          "args": [
            [138], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 138, 
          "method": "animate"
        }, 
        {
          "args": [
            [139], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 139, 
          "method": "animate"
        }, 
        {
          "args": [
            [140], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 140, 
          "method": "animate"
        }, 
        {
          "args": [
            [141], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 141, 
          "method": "animate"
        }, 
        {
          "args": [
            [142], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 142, 
          "method": "animate"
        }, 
        {
          "args": [
            [143], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 143, 
          "method": "animate"
        }, 
        {
          "args": [
            [144], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 144, 
          "method": "animate"
        }, 
        {
          "args": [
            [145], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 145, 
          "method": "animate"
        }, 
        {
          "args": [
            [146], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 146, 
          "method": "animate"
        }, 
        {
          "args": [
            [147], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 147, 
          "method": "animate"
        }, 
        {
          "args": [
            [148], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 148, 
          "method": "animate"
        }, 
        {
          "args": [
            [149], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 149, 
          "method": "animate"
        }, 
        {
          "args": [
            [150], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 150, 
          "method": "animate"
        }, 
        {
          "args": [
            [151], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 151, 
          "method": "animate"
        }, 
        {
          "args": [
            [152], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 152, 
          "method": "animate"
        }, 
        {
          "args": [
            [153], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 153, 
          "method": "animate"
        }, 
        {
          "args": [
            [154], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 154, 
          "method": "animate"
        }, 
        {
          "args": [
            [155], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 155, 
          "method": "animate"
        }, 
        {
          "args": [
            [156], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 156, 
          "method": "animate"
        }, 
        {
          "args": [
            [157], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 157, 
          "method": "animate"
        }, 
        {
          "args": [
            [158], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 158, 
          "method": "animate"
        }, 
        {
          "args": [
            [159], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 159, 
          "method": "animate"
        }, 
        {
          "args": [
            [160], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 160, 
          "method": "animate"
        }, 
        {
          "args": [
            [161], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 161, 
          "method": "animate"
        }, 
        {
          "args": [
            [162], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 162, 
          "method": "animate"
        }, 
        {
          "args": [
            [163], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 163, 
          "method": "animate"
        }, 
        {
          "args": [
            [164], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 164, 
          "method": "animate"
        }, 
        {
          "args": [
            [165], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 165, 
          "method": "animate"
        }, 
        {
          "args": [
            [166], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 166, 
          "method": "animate"
        }, 
        {
          "args": [
            [167], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 167, 
          "method": "animate"
        }, 
        {
          "args": [
            [168], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 168, 
          "method": "animate"
        }, 
        {
          "args": [
            [169], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 169, 
          "method": "animate"
        }, 
        {
          "args": [
            [170], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 170, 
          "method": "animate"
        }, 
        {
          "args": [
            [171], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 171, 
          "method": "animate"
        }, 
        {
          "args": [
            [172], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 172, 
          "method": "animate"
        }, 
        {
          "args": [
            [173], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 173, 
          "method": "animate"
        }, 
        {
          "args": [
            [174], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 174, 
          "method": "animate"
        }, 
        {
          "args": [
            [175], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 175, 
          "method": "animate"
        }, 
        {
          "args": [
            [176], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 176, 
          "method": "animate"
        }, 
        {
          "args": [
            [177], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 177, 
          "method": "animate"
        }, 
        {
          "args": [
            [178], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 178, 
          "method": "animate"
        }, 
        {
          "args": [
            [179], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 179, 
          "method": "animate"
        }, 
        {
          "args": [
            [180], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 180, 
          "method": "animate"
        }, 
        {
          "args": [
            [181], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 181, 
          "method": "animate"
        }, 
        {
          "args": [
            [182], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 182, 
          "method": "animate"
        }, 
        {
          "args": [
            [183], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 183, 
          "method": "animate"
        }, 
        {
          "args": [
            [184], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 184, 
          "method": "animate"
        }, 
        {
          "args": [
            [185], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 185, 
          "method": "animate"
        }, 
        {
          "args": [
            [186], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 186, 
          "method": "animate"
        }, 
        {
          "args": [
            [187], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 187, 
          "method": "animate"
        }, 
        {
          "args": [
            [188], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 188, 
          "method": "animate"
        }, 
        {
          "args": [
            [189], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 189, 
          "method": "animate"
        }, 
        {
          "args": [
            [190], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 190, 
          "method": "animate"
        }, 
        {
          "args": [
            [191], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 191, 
          "method": "animate"
        }, 
        {
          "args": [
            [192], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 192, 
          "method": "animate"
        }, 
        {
          "args": [
            [193], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 193, 
          "method": "animate"
        }, 
        {
          "args": [
            [194], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 194, 
          "method": "animate"
        }, 
        {
          "args": [
            [195], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 195, 
          "method": "animate"
        }, 
        {
          "args": [
            [196], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 196, 
          "method": "animate"
        }, 
        {
          "args": [
            [197], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 197, 
          "method": "animate"
        }, 
        {
          "args": [
            [198], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 198, 
          "method": "animate"
        }, 
        {
          "args": [
            [199], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 199, 
          "method": "animate"
        }, 
        {
          "args": [
            [200], {
              "frame": {
                "easing": "linear", 
                "redraw": False, 
                "duration": 0.0
              }, 
              "transition": {
                "easing": "linear", 
                "duration": 0
              }
            }
          ], 
          "label": 200, 
          "method": "animate"
        }
      ], 
      "xanchor": "left", 
      "yanchor": "top", 
      "tickcolor": "rgba(0,0,0,0)", 
      "transition": {
        "easing": "linear", 
        "duration": 0.0
      }, 
      "currentvalue": {
        "font": {
          "size": 14, 
          "color": "#666"
        }, 
        "prefix": " ", 
        "suffix": " µs", 
        "visible": True, 
        "xanchor": "right"
      }
    }
  ], 
  "hovermode": False, 
  "updatemenus": [
    {
      "x": 0.1, 
      "y": 0, 
      "pad": {
        "r": 10, 
        "t": 10
      }, 
      "type": "buttons", 
      "buttons": [
        {
          "args": [
            ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200"], {
              "mode": "immediate", 
              "frame": {
                "redraw": False, 
                "duration": 0
              }, 
              "easing": "linear", 
              "transition": {"duration": 0}, 
              "fromcurrent": True
            }
          ], 
          "label": "Play", 
          "method": "animate"
        }, 
        {
          "args": [
            [None], {
              "mode": "immediate", 
              "frame": {
                "redraw": False, 
                "duration": 0
              }, 
              "easing": "linear", 
              "transition": {"duration": 0}, 
              "fromcurrent": True
            }
          ], 
          "label": "Pause", 
          "method": "animate"
        }
      ], 
      "xanchor": "right", 
      "yanchor": "top", 
      "direction": "left", 
      "showactive": True
    }
  ], 
  "plot_bgcolor": "white"
}
frame1 = {
  "data": [
    {
      "xsrc": "harry11733:104:b51c2a", 
      "x": [-0.482, -1.193, -1.373, -3.41, -0.447, -2.119, -3.038, -0.437, -1.314, -3.715, -0.642, -2.874, -2.806, -3.086, -1.307, -2.07, -2.257, -2.502, -1.04, -2.049, -0.142, -1.791, -2.478, -1.748, -3.48, -1.289, -3.809, -1.783, -1.943, -2.694, -2.947, -0.676, -3.663, -2.986, -0.237, -2.221, -0.151, -3.501, -3.31, -2.473, -1.544, -2.685, -2.583, -3.108, -0.635, -3.265, -1.241, -0.15, -3.69, -0.684], 
      "ysrc": "harry11733:104:b32d2a", 
      "y": [3.511, 2.824, -2.217, 1.97, -2.575, 0.025, 3.733, -3.316, -1.363, -0.757, -0.623, -3.598, 1.087, -2.352, -0.982, 0.425, -3.589, 3.022, 0.669, -0.638, -3.693, 3.77, -0.816, -3.714, 3.271, -0.303, -0.559, -3.393, 1.162, -2.546, -2.14, -3.591, -3.816, 2.995, -1.791, -1.993, -0.343, 2.004, -2.327, -2.481, 0.91, -3.441, 1.863, 1.802, -2.717, 0.025, -3.084, -1.542, -3.581, 0.578]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a2c6d9", 
      "x": [0], 
      "ysrc": "harry11733:104:4c97e2", 
      "y": [0.0]
    }
  ], 
  "name": 0, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame2 = {
  "data": [
    {
      "xsrc": "harry11733:104:efa004", 
      "x": [-0.799, -1.262, -1.481, -3.538, -0.413, -1.75, -3.094, -0.797, -1.34, -3.672, -0.429, -3.047, -3.419, -3.231, -0.458, -2.164, -1.956, -2.837, -0.924, -1.81, -0.175, -1.835, -2.689, -1.517, -3.854, -1.256, -3.588, -1.725, -1.684, -2.494, -3.067, -0.596, -3.489, -2.82, -0.198, -1.886, -0.16, -3.456, -3.418, -2.413, -1.374, -3.43, -2.163, -3.245, -0.518, -3.761, -1.347, -0.492, -3.525, -0.523], 
      "ysrc": "harry11733:104:4aec5f", 
      "y": [3.762, 3.454, -2.212, 1.521, -2.678, 0.031, 3.692, -3.788, -1.408, -0.682, -0.395, -3.274, 1.326, -2.048, -1.285, 0.226, -3.329, 3.068, 0.7, -0.814, -3.654, 3.8, -1.123, -3.661, 3.509, 0.017, 0.003, -3.794, 1.735, -3.074, -1.69, -3.708, -3.499, 2.783, -1.69, -1.859, -0.398, 1.648, -2.227, -2.724, 0.541, -3.047, 2.103, 1.816, -2.886, -0.143, -3.21, -1.758, -3.295, 0.4]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:bb07d0", 
      "x": [0, 1], 
      "ysrc": "harry11733:104:416a5d", 
      "y": [0.0, 0.0]
    }
  ], 
  "name": 1, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame3 = {
  "data": [
    {
      "xsrc": "harry11733:104:f9712e", 
      "x": [-1.132, -1.216, -1.414, -3.55, -0.874, -1.964, -3.106, -0.151, -1.327, -3.696, -0.846, -3.023, -3.74, -3.348, -0.311, -2.167, -2.199, -3.253, -1.079, -1.999, -0.433, -1.779, -2.899, -2.283, -3.83, -1.089, -3.56, -1.637, -1.46, -2.186, -2.616, -0.797, -3.766, -2.442, -0.332, -1.823, -0.239, -3.674, -3.284, -2.269, -1.668, -3.693, -2.047, -3.354, -0.694, -3.657, -1.631, -0.341, -3.857, -0.398], 
      "ysrc": "harry11733:104:ff088c", 
      "y": [3.474, 3.286, -1.94, 1.044, -3.094, -0.045, 3.688, -3.479, -1.659, -0.368, -0.126, -3.675, 1.318, -1.864, -1.578, -0.288, -3.102, 3.041, 0.924, -0.592, -3.733, 3.812, -1.529, -3.491, 3.38, -0.361, -0.233, -3.842, 1.817, -2.915, -1.908, -3.741, -3.798, 3.443, -1.529, -2.011, -0.504, 1.697, -2.446, -2.679, -0.317, -2.913, 1.637, 1.749, -3.053, 0.195, -3.319, -1.916, -3.793, 0.143]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:5049d1", 
      "x": [0, 1, 2], 
      "ysrc": "harry11733:104:e0708b", 
      "y": [0.0, 0.0, 0.0]
    }
  ], 
  "name": 2, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame4 = {
  "data": [
    {
      "xsrc": "harry11733:104:76f6f8", 
      "x": [-0.774, -1.376, -1.31, -3.405, -0.68, -2.114, -2.892, -0.144, -1.438, -3.719, -0.732, -2.71, -3.714, -3.508, -0.191, -2.628, -2.622, -2.966, -1.05, -2.008, -0.241, -2.013, -3.059, -1.89, -3.707, -1.205, -3.164, -1.858, -2.071, -1.979, -2.701, -0.333, -3.432, -2.595, -0.179, -1.325, -0.31, -3.639, -3.698, -2.775, -1.321, -3.819, -1.775, -3.171, -1.199, -3.366, -1.695, -0.247, -3.834, -0.387], 
      "ysrc": "harry11733:104:b9b60a", 
      "y": [3.796, 3.355, -2.163, 1.102, -2.873, -0.017, 3.45, -3.538, -1.887, -0.547, -0.522, -3.758, 0.85, -1.978, -2.041, -0.196, -3.104, 3.011, 0.764, -0.523, -3.77, 3.65, -1.091, -3.158, 3.335, 0.011, 0.091, -3.588, 2.457, -2.73, -1.883, -3.462, -3.698, 3.263, -1.22, -1.886, -0.466, 1.78, -2.709, -2.934, -1.12, -2.936, 1.834, 2.1, -3.281, -0.04, -2.923, -1.808, -3.385, 0.696]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c7d6ab", 
      "x": [0, 1, 2, 3], 
      "ysrc": "harry11733:104:6839b6", 
      "y": [0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 3, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame5 = {
  "data": [
    {
      "xsrc": "harry11733:104:eb7728", 
      "x": [-0.581, -1.111, -1.834, -3.527, -1.326, -2.209, -3.108, -0.466, -1.662, -3.526, -1.218, -2.514, -3.788, -3.336, -0.221, -2.584, -2.659, -3.048, -1.033, -2.045, -0.49, -1.553, -3.625, -1.361, -3.69, -1.538, -3.229, -2.165, -1.846, -1.282, -2.652, -0.213, -3.596, -2.615, -0.156, -1.584, -0.305, -3.315, -3.778, -2.993, -1.111, -3.861, -1.869, -2.957, -1.5, -3.149, -2.096, -0.158, -3.779, -0.144], 
      "ysrc": "harry11733:104:1e8114", 
      "y": [3.696, 3.406, -2.126, 0.916, -2.919, -0.314, 3.157, -3.386, -1.968, -0.182, -0.433, -3.714, 0.732, -1.828, -1.514, -0.531, -3.709, 2.963, 0.972, -1.386, -3.705, 3.459, -1.217, -3.462, 3.403, 0.002, 0.019, -3.814, 2.464, -2.462, -2.123, -2.601, -3.199, 3.071, -0.876, -1.945, -0.454, 1.092, -2.46, -2.6, -1.246, -2.927, 1.265, 2.159, -3.565, 0.029, -3.341, -1.818, -3.711, 1.181]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c2b875", 
      "x": [0, 1, 2, 3, 4], 
      "ysrc": "harry11733:104:fc8f5e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 4, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame6 = {
  "data": [
    {
      "xsrc": "harry11733:104:351916", 
      "x": [-0.841, -1.309, -1.372, -3.721, -1.089, -2.159, -3.006, -0.248, -1.978, -2.884, -1.534, -3.044, -3.812, -3.326, -0.552, -2.23, -2.572, -3.024, -0.896, -1.692, -1.069, -1.481, -3.795, -1.953, -3.386, -2.032, -3.43, -2.002, -1.995, -1.006, -3.019, -0.196, -3.784, -2.514, -0.246, -1.966, -0.805, -3.4, -3.841, -3.272, -0.775, -3.581, -2.204, -2.749, -1.209, -3.043, -1.869, -0.251, -3.697, -0.288], 
      "ysrc": "harry11733:104:500ee4", 
      "y": [3.595, 3.53, -2.253, 0.507, -2.461, -0.213, 3.055, -3.13, -1.996, -0.046, -0.526, -3.439, 0.932, -1.263, -1.587, -0.986, -3.321, 2.852, 0.724, -1.218, -3.171, 3.329, -1.321, -3.568, 3.488, 0.205, 0.093, -3.807, 2.69, -2.599, -2.169, -2.428, -3.124, 3.417, -1.059, -1.963, -0.221, 1.292, -2.037, -2.479, -0.618, -3.167, 1.573, 2.804, -3.616, 0.373, -3.818, -1.795, -3.719, 1.185]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ff8113", 
      "x": [0, 1, 2, 3, 4, 5], 
      "ysrc": "harry11733:104:8bfc36", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 5, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame7 = {
  "data": [
    {
      "xsrc": "harry11733:104:071e99", 
      "x": [-0.838, -1.497, -1.877, -3.465, -1.203, -2.411, -2.95, -0.354, -1.98, -3.083, -1.495, -2.857, -3.729, -3.167, -0.402, -2.424, -2.846, -3.663, -0.561, -1.08, -1.304, -1.169, -3.618, -1.953, -3.302, -2.092, -3.751, -1.625, -2.031, -1.008, -3.554, -0.352, -3.154, -2.0, -0.4, -1.484, -1.369, -3.224, -3.375, -3.672, -0.706, -2.879, -2.111, -2.263, -1.386, -3.222, -1.804, -0.308, -3.178, -0.498], 
      "ysrc": "harry11733:104:391262", 
      "y": [3.863, 3.27, -2.41, 0.657, -2.678, 0.272, 3.196, -2.758, -2.268, -0.059, -0.151, -3.703, 0.725, -0.995, -1.69, -0.818, -3.022, 2.808, 0.767, -1.413, -3.349, 3.84, -1.206, -3.621, 3.292, 0.76, 0.345, -3.793, 3.312, -2.595, -2.245, -2.137, -3.455, 3.661, -1.274, -1.614, -0.366, 1.591, -1.934, -2.238, -0.745, -3.221, 1.752, 3.063, -2.853, 0.371, -3.333, -1.372, -3.665, 1.285]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:6427bc", 
      "x": [0, 1, 2, 3, 4, 5, 6], 
      "ysrc": "harry11733:104:0089ba", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 6, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame8 = {
  "data": [
    {
      "xsrc": "harry11733:104:469107", 
      "x": [-1.829, -1.642, -2.477, -3.478, -1.356, -2.549, -2.825, -0.247, -1.89, -3.184, -1.37, -3.28, -3.602, -3.646, -0.395, -2.148, -2.727, -3.561, -0.353, -0.862, -0.851, -1.268, -3.251, -1.75, -3.17, -2.112, -3.814, -1.405, -1.747, -0.775, -3.82, -0.197, -3.404, -1.268, -0.377, -1.524, -1.877, -3.413, -3.391, -3.598, -1.239, -2.608, -2.308, -1.928, -1.343, -3.322, -1.308, -0.608, -3.302, -0.352], 
      "ysrc": "harry11733:104:32f64f", 
      "y": [3.79, 3.129, -2.708, 0.596, -2.291, 0.125, 3.494, -2.463, -2.293, -0.118, -0.175, -3.63, 1.395, -0.224, -1.803, -0.748, -2.704, 2.306, 1.187, -1.152, -3.207, 3.585, -1.378, -3.561, 3.476, 0.185, 0.13, -3.602, 3.846, -2.659, -2.2, -1.731, -3.383, 3.806, -1.265, -1.348, -0.921, 1.862, -2.145, -1.754, -0.984, -3.355, 2.009, 2.596, -2.78, 0.406, -3.009, -1.382, -3.785, 1.059]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:17d62e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7], 
      "ysrc": "harry11733:104:7c62a2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 7, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame9 = {
  "data": [
    {
      "xsrc": "harry11733:104:4d50c6", 
      "x": [-1.441, -1.952, -2.222, -3.393, -1.22, -2.732, -2.626, -0.339, -2.015, -3.519, -1.207, -3.492, -3.698, -3.547, -0.48, -1.838, -2.427, -3.698, -0.197, -1.335, -1.291, -1.289, -3.004, -2.136, -3.272, -2.217, -3.712, -0.978, -1.508, -1.163, -3.621, -0.495, -3.303, -1.762, -0.49, -1.36, -1.556, -3.336, -3.559, -3.842, -0.882, -2.476, -2.103, -1.806, -1.063, -3.214, -1.272, -0.311, -3.66, -0.55], 
      "ysrc": "harry11733:104:a6b7b6", 
      "y": [3.481, 3.343, -3.013, 0.303, -2.298, -0.049, 3.446, -2.123, -2.126, -0.124, -0.764, -3.309, 1.471, -0.153, -1.533, -0.666, -2.849, 2.329, 1.067, -1.22, -2.776, 3.331, -1.546, -3.129, 3.518, 0.097, 0.192, -3.576, 3.666, -2.826, -2.563, -1.415, -3.084, 3.804, -1.502, -1.788, -0.866, 1.91, -2.683, -1.886, -0.859, -3.311, 2.042, 2.387, -2.721, 0.37, -3.395, -1.004, -3.808, 0.604]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:39846c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8], 
      "ysrc": "harry11733:104:e4a94d", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 8, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame10 = {
  "data": [
    {
      "xsrc": "harry11733:104:c6e844", 
      "x": [-1.365, -1.608, -1.749, -3.783, -1.243, -2.872, -3.024, -0.157, -2.135, -3.776, -1.259, -3.6, -3.386, -3.48, -0.163, -1.939, -2.076, -3.773, -0.415, -1.326, -0.961, -1.238, -2.626, -2.288, -2.88, -2.165, -3.807, -1.039, -1.581, -0.806, -3.003, -0.626, -3.576, -1.486, -0.858, -1.367, -1.475, -3.331, -3.469, -3.867, -0.425, -2.568, -2.164, -1.921, -0.71, -2.588, -1.009, -0.416, -3.103, -0.645], 
      "ysrc": "harry11733:104:dbf5a7", 
      "y": [3.228, 3.379, -2.998, 0.282, -2.357, -0.094, 3.354, -2.012, -2.343, -0.301, -1.058, -3.41, 1.51, -0.023, -1.532, -0.917, -2.691, 1.907, 1.438, -2.217, -2.967, 3.062, -1.952, -2.818, 3.27, -0.007, 0.208, -3.752, 3.844, -2.814, -2.428, -0.885, -2.765, 3.703, -1.512, -1.619, -0.668, 1.806, -2.217, -2.089, -0.998, -2.863, 1.228, 2.62, -3.084, -0.104, -3.002, -0.78, -3.761, 0.112]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4506c6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 
      "ysrc": "harry11733:104:86bd27", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 9, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame11 = {
  "data": [
    {
      "xsrc": "harry11733:104:af5809", 
      "x": [-1.575, -1.471, -2.104, -3.724, -1.152, -2.688, -3.32, -0.17, -1.757, -3.369, -1.557, -3.552, -2.954, -3.319, -0.204, -1.828, -1.85, -3.18, -0.454, -1.28, -0.709, -1.486, -2.752, -2.0, -3.159, -2.41, -3.537, -1.123, -1.875, -0.277, -3.034, -0.666, -3.699, -0.921, -0.906, -1.806, -1.248, -2.956, -3.794, -3.659, -0.733, -2.504, -1.956, -2.015, -0.839, -2.488, -0.98, -0.689, -3.503, -0.624], 
      "ysrc": "harry11733:104:509741", 
      "y": [3.466, 3.366, -3.209, -0.165, -2.815, -0.377, 3.396, -2.106, -2.509, -0.355, -0.446, -3.403, 1.394, 0.167, -1.745, -1.102, -2.62, 1.846, 1.23, -1.695, -2.972, 3.315, -1.767, -2.479, 3.087, 0.391, 0.511, -3.288, 3.847, -2.838, -2.1, -0.883, -2.925, 3.596, -1.866, -1.152, -0.727, 1.609, -2.778, -2.076, -0.756, -2.917, 1.368, 2.819, -3.048, 0.067, -2.501, -0.981, -3.726, -0.138]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:3b3f6b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 
      "ysrc": "harry11733:104:59df98", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 10, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame12 = {
  "data": [
    {
      "xsrc": "harry11733:104:ff8ef0", 
      "x": [-1.645, -1.236, -2.062, -3.522, -1.373, -2.835, -3.24, -0.154, -2.222, -3.766, -0.829, -3.812, -3.24, -2.84, -0.731, -2.404, -2.279, -2.96, -0.308, -1.115, -0.958, -1.808, -2.482, -2.071, -2.958, -2.422, -3.506, -1.47, -1.335, -0.151, -3.34, -0.96, -3.602, -0.6, -1.207, -1.837, -0.95, -2.27, -3.527, -3.84, -0.669, -2.648, -1.5, -1.631, -1.091, -2.225, -0.69, -0.524, -3.424, -0.748], 
      "ysrc": "harry11733:104:0f189b", 
      "y": [3.612, 3.697, -2.707, -0.314, -2.9, -0.4, 3.68, -2.431, -2.147, -1.016, -0.867, -3.163, 1.342, 0.002, -1.481, -0.847, -2.489, 2.059, 1.386, -1.535, -2.957, 3.759, -1.696, -2.153, 3.47, 0.036, 0.581, -3.055, 3.297, -2.404, -1.811, -1.253, -2.708, 3.797, -1.913, -1.52, -0.526, 1.885, -2.84, -1.75, -1.197, -2.957, 1.564, 3.065, -3.357, 0.127, -2.66, -0.408, -3.83, -0.539]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:901866", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 
      "ysrc": "harry11733:104:c26315", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 11, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame13 = {
  "data": [
    {
      "xsrc": "harry11733:104:6f02da", 
      "x": [-1.784, -1.593, -1.705, -3.106, -1.075, -2.861, -3.569, -0.185, -2.548, -3.647, -0.532, -3.318, -3.023, -2.973, -0.524, -2.562, -2.661, -3.053, -0.196, -1.383, -1.192, -1.762, -2.395, -1.868, -2.991, -2.574, -3.388, -1.49, -1.287, -0.329, -2.866, -1.065, -3.446, -0.612, -1.436, -1.955, -1.256, -2.172, -3.493, -3.732, -0.462, -2.706, -1.528, -2.099, -0.812, -1.945, -1.299, -0.368, -3.826, -0.928], 
      "ysrc": "harry11733:104:8a47b7", 
      "y": [3.841, 3.753, -3.163, -0.066, -3.612, -0.736, 3.822, -2.311, -1.993, -1.076, -0.601, -2.941, 1.853, 0.03, -1.825, -1.317, -2.619, 1.596, 0.862, -1.562, -2.858, 3.045, -1.452, -2.052, 3.557, -0.157, 0.825, -2.899, 3.348, -2.174, -1.354, -1.285, -2.943, 3.822, -2.382, -1.652, -0.102, 2.442, -3.047, -2.135, -0.93, -2.607, 1.827, 2.454, -3.417, -0.178, -2.456, 0.046, -3.558, -0.326]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e94f0a", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 
      "ysrc": "harry11733:104:832a66", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 12, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame14 = {
  "data": [
    {
      "xsrc": "harry11733:104:37f0e9", 
      "x": [-2.062, -1.819, -1.461, -3.259, -0.786, -2.814, -3.827, -0.21, -2.835, -3.584, -0.736, -3.312, -3.247, -2.543, -0.568, -2.439, -2.545, -3.291, -0.263, -2.136, -1.659, -2.164, -2.508, -1.983, -2.84, -2.776, -3.408, -1.135, -1.1, -0.604, -3.011, -1.058, -3.018, -0.2, -1.059, -1.945, -1.457, -2.104, -3.051, -3.555, -0.631, -3.113, -1.91, -1.649, -0.956, -1.494, -1.339, -0.231, -3.752, -0.605], 
      "ysrc": "harry11733:104:0609ba", 
      "y": [3.71, 3.705, -3.043, -0.863, -3.726, -0.788, 3.792, -2.324, -2.109, -0.915, -0.552, -2.977, 1.825, -0.064, -1.828, -1.634, -2.498, 2.226, 0.884, -1.495, -2.666, 3.121, -1.613, -1.96, 3.578, 0.069, 1.242, -3.087, 2.742, -2.372, -1.071, -1.809, -2.862, 3.648, -2.25, -1.541, -0.314, 2.984, -3.128, -1.857, -0.893, -2.582, 2.242, 3.054, -2.93, -0.565, -2.12, 0.28, -3.508, 0.006]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:12a5a0", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13], 
      "ysrc": "harry11733:104:ef4d56", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 13, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame15 = {
  "data": [
    {
      "xsrc": "harry11733:104:203a19", 
      "x": [-2.322, -1.682, -1.741, -3.106, -0.967, -2.819, -3.856, -0.164, -2.507, -3.65, -0.26, -3.097, -3.23, -3.456, -0.29, -2.916, -2.748, -3.538, -0.721, -2.175, -2.367, -2.354, -2.7, -2.471, -2.95, -2.114, -3.619, -1.667, -0.835, -0.674, -2.882, -0.856, -2.603, -0.372, -1.109, -2.28, -1.697, -2.185, -3.13, -3.649, -1.301, -2.569, -2.103, -1.829, -0.748, -1.445, -1.352, -0.148, -3.452, -0.823], 
      "ysrc": "harry11733:104:6285e9", 
      "y": [3.723, 3.702, -2.734, -0.458, -3.564, -0.547, 3.491, -2.213, -1.816, -1.012, -1.459, -3.456, 1.592, 0.121, -1.879, -1.776, -1.914, 2.366, 0.691, -1.391, -2.819, 3.24, -1.354, -2.021, 3.664, 0.238, 1.383, -3.314, 2.297, -2.371, -0.966, -1.548, -3.201, 3.544, -2.398, -1.033, -0.385, 2.473, -2.962, -1.437, -0.641, -2.9, 2.735, 3.237, -2.803, -0.387, -2.412, 0.183, -3.567, -0.011]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:35df22", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], 
      "ysrc": "harry11733:104:82c02a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 14, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame16 = {
  "data": [
    {
      "xsrc": "harry11733:104:e56bca", 
      "x": [-1.956, -1.618, -2.244, -3.293, -0.709, -3.052, -3.821, -0.697, -2.735, -3.217, -0.756, -3.518, -3.528, -3.709, -0.36, -2.518, -2.693, -3.752, -0.515, -2.414, -1.779, -2.507, -2.406, -2.683, -2.929, -1.945, -3.559, -1.933, -1.648, -0.588, -2.926, -0.617, -2.41, -0.528, -1.382, -2.223, -2.05, -2.655, -2.774, -3.651, -0.865, -3.002, -1.203, -2.074, -0.906, -1.634, -1.522, -0.246, -3.172, -1.434], 
      "ysrc": "harry11733:104:ecd96a", 
      "y": [3.63, 3.715, -2.59, -0.181, -3.299, -0.491, 3.591, -2.401, -1.329, -0.809, -1.128, -3.557, 1.588, -0.492, -2.151, -1.159, -1.854, 1.904, 0.97, -1.619, -2.372, 3.218, -1.392, -2.238, 3.753, 0.893, 1.513, -3.093, 2.347, -2.309, -0.947, -1.734, -3.295, 3.209, -2.524, -1.049, -0.058, 2.159, -3.121, -1.586, 0.059, -2.733, 2.879, 2.893, -2.66, -0.647, -2.613, 0.374, -3.342, 0.054]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:fa857a", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], 
      "ysrc": "harry11733:104:25eecd", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 15, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame17 = {
  "data": [
    {
      "xsrc": "harry11733:104:6afb5b", 
      "x": [-2.002, -2.362, -2.317, -3.202, -1.021, -3.136, -3.843, -0.199, -2.561, -3.223, -0.958, -3.202, -3.367, -3.855, -0.642, -1.684, -2.929, -3.785, -0.25, -2.16, -2.114, -2.7, -2.517, -2.226, -3.252, -1.777, -3.602, -2.216, -1.625, -0.207, -3.393, -0.799, -2.076, -1.038, -1.527, -2.766, -1.422, -2.311, -2.682, -3.61, -1.119, -3.136, -1.884, -1.5, -0.708, -1.156, -1.602, -0.325, -2.657, -1.764], 
      "ysrc": "harry11733:104:5475d2", 
      "y": [3.748, 3.701, -2.85, -0.508, -3.556, -0.322, 3.549, -2.95, -1.505, -1.028, -0.419, -3.513, 2.183, -0.843, -2.144, -0.925, -2.22, 1.642, 1.173, -1.482, -2.673, 2.891, -1.088, -2.401, 3.621, 1.19, 0.866, -2.707, 2.502, -2.288, -0.621, -1.922, -2.81, 3.663, -2.432, -0.919, -0.057, 2.456, -2.803, -1.305, 0.144, -3.098, 2.642, 2.948, -2.811, -0.848, -2.411, 0.642, -3.04, 0.984]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:2f0984", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], 
      "ysrc": "harry11733:104:f9f10a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 16, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame18 = {
  "data": [
    {
      "xsrc": "harry11733:104:27ffd9", 
      "x": [-1.769, -2.226, -2.144, -2.872, -1.046, -2.551, -3.832, -0.223, -2.626, -3.382, -0.639, -3.298, -3.042, -3.707, -0.725, -2.039, -2.766, -3.736, -0.542, -1.99, -1.976, -2.688, -2.176, -2.265, -2.845, -1.534, -3.186, -2.32, -1.449, -0.477, -3.408, -1.364, -2.229, -0.955, -1.686, -2.709, -1.817, -2.473, -3.003, -3.457, -1.114, -3.66, -1.846, -1.686, -1.051, -0.84, -2.196, -0.803, -2.969, -1.913], 
      "ysrc": "harry11733:104:c648ec", 
      "y": [3.686, 3.828, -2.762, -1.066, -3.676, -0.943, 3.017, -2.947, -1.84, -1.104, -0.541, -3.609, 2.287, -0.984, -2.342, -0.835, -1.519, 1.767, 0.594, -1.66, -2.092, 2.193, -1.012, -2.31, 3.627, 1.666, 1.605, -2.722, 2.544, -1.784, -0.321, -2.11, -3.205, 3.86, -3.082, -0.943, -0.296, 2.106, -2.781, -1.094, 0.502, -3.051, 3.253, 2.976, -2.797, -1.152, -2.565, 0.61, -2.488, 1.227]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:353099", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], 
      "ysrc": "harry11733:104:95c031", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 17, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame19 = {
  "data": [
    {
      "xsrc": "harry11733:104:55ade8", 
      "x": [-1.663, -2.613, -2.516, -3.211, -0.736, -2.337, -3.823, -0.343, -2.592, -3.474, -0.885, -2.754, -2.98, -3.626, -0.561, -1.465, -2.554, -3.82, -0.361, -2.493, -2.099, -2.232, -2.722, -2.353, -2.292, -1.235, -3.011, -2.038, -1.21, -0.795, -3.544, -1.395, -2.449, -0.619, -1.653, -2.741, -1.275, -2.733, -2.768, -3.289, -1.6, -3.766, -1.604, -1.574, -0.572, -1.126, -2.204, -0.762, -2.882, -2.423], 
      "ysrc": "harry11733:104:5c963a", 
      "y": [3.608, 3.76, -2.512, -0.997, -3.626, -0.917, 3.148, -2.977, -1.915, -1.027, -0.9, -3.483, 2.716, -0.841, -2.464, -1.099, -1.385, 2.089, 0.442, -1.917, -1.965, 2.432, -1.275, -1.568, 3.175, 1.678, 1.075, -2.801, 2.844, -2.018, -0.315, -1.945, -2.961, 3.699, -2.802, -0.805, 0.027, 2.09, -3.171, -0.828, 0.296, -3.109, 3.126, 2.736, -2.672, -0.807, -2.563, 0.267, -2.428, 0.716]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:93e5df", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18], 
      "ysrc": "harry11733:104:d05561", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 18, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame20 = {
  "data": [
    {
      "xsrc": "harry11733:104:2630bd", 
      "x": [-0.879, -2.824, -2.563, -3.643, -0.716, -2.095, -3.8, -0.764, -2.421, -3.738, -0.858, -2.812, -2.721, -3.636, -0.56, -1.513, -2.807, -3.601, -0.599, -2.117, -1.497, -2.2, -2.884, -2.14, -2.454, -1.174, -3.059, -2.109, -1.601, -0.514, -3.223, -0.906, -2.164, -0.47, -1.553, -2.066, -1.313, -2.803, -3.196, -3.212, -1.853, -3.697, -1.629, -2.179, -0.648, -0.8, -1.968, -0.921, -2.892, -2.287], 
      "ysrc": "harry11733:104:b4e33e", 
      "y": [3.172, 3.592, -2.274, -1.256, -3.687, -0.884, 3.145, -2.566, -1.427, -0.044, -1.559, -3.536, 2.839, -0.981, -2.379, -1.546, -1.646, 1.749, 0.816, -1.758, -1.634, 2.231, -1.116, -1.427, 3.062, 1.702, 1.559, -2.913, 2.754, -1.777, -0.293, -1.804, -2.513, 3.643, -3.041, -0.364, 0.001, 2.779, -3.09, -0.526, 0.295, -3.373, 2.982, 2.619, -2.579, -0.753, -2.627, 0.191, -2.635, 1.068]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:029bfe", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19], 
      "ysrc": "harry11733:104:f2b11e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 19, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame21 = {
  "data": [
    {
      "xsrc": "harry11733:104:b946e3", 
      "x": [-0.761, -2.756, -2.502, -3.48, -0.869, -2.27, -3.782, -1.198, -2.354, -3.702, -0.927, -3.105, -2.934, -3.749, -0.787, -1.557, -2.764, -3.474, -0.553, -2.167, -1.964, -2.6, -2.878, -2.4, -2.233, -0.949, -3.532, -2.272, -1.582, -0.318, -3.115, -0.191, -2.223, -0.749, -1.854, -1.967, -1.402, -2.443, -3.318, -3.504, -1.507, -3.775, -1.817, -2.641, -0.204, -0.759, -2.124, -1.084, -3.245, -3.042], 
      "ysrc": "harry11733:104:f30291", 
      "y": [3.215, 3.187, -2.221, -1.347, -3.681, -1.395, 3.08, -1.796, -1.621, -0.337, -1.045, -3.631, 2.803, -0.825, -2.365, -1.654, -1.356, 1.308, 0.918, -1.344, -1.839, 1.892, -1.339, -1.471, 3.29, 1.573, 1.75, -3.469, 2.449, -1.751, -0.011, -1.678, -2.426, 2.931, -2.654, -0.043, 0.021, 2.423, -2.859, -0.953, 0.946, -3.258, 3.096, 2.687, -2.806, -0.879, -2.827, 0.183, -2.565, 1.001]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:970557", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], 
      "ysrc": "harry11733:104:49a6e7", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 20, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame22 = {
  "data": [
    {
      "xsrc": "harry11733:104:031678", 
      "x": [-0.61, -2.413, -2.335, -3.266, -0.372, -2.333, -3.449, -1.108, -2.415, -3.657, -0.937, -3.153, -3.246, -3.569, -0.736, -1.753, -2.297, -3.866, -0.729, -2.016, -1.779, -2.876, -2.714, -2.357, -2.549, -1.023, -3.802, -2.308, -1.879, -0.192, -2.798, -0.264, -2.297, -0.728, -1.73, -2.086, -1.302, -2.347, -3.323, -3.322, -1.806, -2.911, -1.958, -2.749, -0.283, -0.6, -2.204, -1.109, -3.623, -2.569], 
      "ysrc": "harry11733:104:91b1d9", 
      "y": [3.356, 3.24, -1.953, -1.779, -3.521, -1.493, 2.519, -1.658, -1.487, 0.072, -1.212, -3.774, 2.948, -0.54, -2.654, -1.986, -1.488, 1.573, 0.913, -1.259, -1.982, 2.097, -1.867, -1.802, 3.138, 1.781, 1.709, -3.408, 2.904, -1.531, 0.566, -1.658, -2.777, 3.187, -2.705, -0.189, -0.685, 1.67, -2.875, -1.792, 1.141, -2.65, 3.266, 2.539, -3.15, -1.362, -3.153, 0.947, -2.645, 0.43]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ab2c32", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21], 
      "ysrc": "harry11733:104:b344c5", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 21, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame23 = {
  "data": [
    {
      "xsrc": "harry11733:104:eff3d7", 
      "x": [-0.392, -2.267, -2.145, -3.604, -0.595, -2.523, -3.31, -1.258, -2.586, -3.824, -1.046, -3.073, -3.105, -3.438, -0.316, -1.744, -1.957, -3.814, -1.205, -1.788, -1.168, -2.455, -2.902, -2.18, -2.837, -1.357, -3.863, -2.516, -1.929, -0.228, -3.013, -0.175, -2.311, -0.997, -1.428, -2.213, -0.913, -2.185, -3.336, -3.316, -2.299, -3.25, -2.06, -2.819, -0.208, -0.456, -2.548, -1.167, -3.746, -2.47], 
      "ysrc": "harry11733:104:4f5985", 
      "y": [3.531, 3.321, -1.936, -1.611, -3.712, -1.428, 2.957, -1.692, -1.029, -0.162, -0.897, -3.772, 2.919, -0.691, -2.454, -1.72, -1.5, 1.569, 0.658, -1.893, -1.689, 2.244, -1.887, -2.026, 2.612, 1.294, 1.516, -3.348, 3.149, -1.834, 0.426, -1.328, -2.486, 3.303, -3.239, -0.3, -1.207, 1.834, -2.687, -1.859, 0.803, -3.095, 3.669, 2.881, -2.645, -1.184, -3.437, 0.672, -2.776, -0.194]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:3dd0a5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22], 
      "ysrc": "harry11733:104:bb84fd", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 22, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame24 = {
  "data": [
    {
      "xsrc": "harry11733:104:144112", 
      "x": [-0.65, -2.052, -1.9, -3.856, -0.222, -2.653, -3.277, -1.494, -3.171, -3.477, -1.007, -2.689, -2.937, -2.799, -0.183, -1.797, -1.692, -3.795, -0.554, -1.285, -1.458, -2.339, -2.892, -1.945, -3.038, -1.559, -3.571, -2.47, -1.861, -0.412, -2.828, -0.145, -2.546, -0.727, -1.64, -2.312, -0.651, -2.347, -3.852, -3.172, -2.743, -3.06, -1.771, -2.928, -0.196, -0.722, -2.563, -1.294, -3.506, -2.573], 
      "ysrc": "harry11733:104:fb5cbe", 
      "y": [3.538, 3.585, -1.77, -1.299, -3.794, -1.638, 3.25, -1.858, -0.537, -0.177, -0.591, -3.712, 3.144, -0.116, -2.669, -2.248, -2.04, 1.114, 0.894, -2.056, -1.78, 2.668, -2.034, -2.111, 2.325, 1.303, 1.453, -2.991, 3.139, -1.9, 0.075, -0.964, -2.774, 2.695, -3.071, -0.268, -1.663, 1.968, -3.011, -1.989, 0.603, -2.596, 3.847, 2.336, -2.43, -1.249, -3.057, 0.801, -2.372, 0.057]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b06223", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23], 
      "ysrc": "harry11733:104:af8961", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 23, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame25 = {
  "data": [
    {
      "xsrc": "harry11733:104:78fc58", 
      "x": [-0.173, -2.58, -2.238, -3.65, -0.228, -2.437, -3.264, -1.125, -3.088, -3.4, -1.31, -3.515, -2.26, -2.848, -0.137, -1.823, -2.101, -3.806, -0.553, -1.413, -1.621, -2.231, -2.653, -2.229, -3.462, -1.878, -3.428, -2.599, -1.59, -0.363, -3.161, -0.448, -2.685, -0.504, -2.107, -3.127, -0.841, -2.654, -3.777, -3.386, -2.818, -2.572, -1.906, -2.516, -0.337, -1.051, -2.718, -1.757, -3.186, -2.539], 
      "ysrc": "harry11733:104:f49b0d", 
      "y": [3.792, 3.322, -1.187, -1.316, -3.766, -1.368, 3.458, -2.38, -0.985, -0.13, -0.571, -3.661, 3.44, -0.053, -2.905, -2.098, -1.694, 1.189, 0.804, -1.883, -1.339, 2.725, -2.232, -2.151, 2.103, 1.408, 1.274, -2.883, 3.82, -2.005, -0.206, -0.598, -2.743, 2.877, -3.271, -0.833, -1.176, 1.798, -3.483, -1.768, 0.666, -2.727, 3.715, 2.12, -2.466, -1.366, -3.08, 0.621, -2.648, -0.522]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:d3569c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 
      "ysrc": "harry11733:104:dc4a21", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 24, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame26 = {
  "data": [
    {
      "xsrc": "harry11733:104:5e3855", 
      "x": [-0.407, -3.039, -2.703, -3.711, -0.195, -2.322, -3.367, -0.837, -3.242, -3.272, -1.155, -3.775, -2.345, -3.014, -0.175, -1.988, -2.151, -3.253, -0.69, -1.401, -2.424, -2.132, -2.724, -2.486, -3.213, -1.817, -3.692, -2.373, -2.344, -0.372, -3.382, -0.515, -3.0, -0.396, -2.086, -2.95, -0.673, -2.778, -3.629, -3.491, -2.815, -2.961, -1.912, -2.49, -1.004, -1.122, -2.787, -2.329, -3.432, -2.111], 
      "ysrc": "harry11733:104:5971c8", 
      "y": [3.434, 3.038, -1.416, -1.504, -3.779, -0.936, 3.305, -2.157, -0.722, -0.998, -0.818, -3.678, 3.807, -0.063, -2.593, -1.732, -1.518, 1.938, 1.093, -1.75, -1.364, 2.914, -1.729, -1.823, 2.275, 1.474, 1.164, -2.95, 3.78, -1.578, -0.368, -0.848, -2.805, 3.459, -3.211, -0.366, -1.631, 1.854, -3.152, -1.593, 0.531, -2.452, 3.602, 2.091, -2.077, -1.367, -3.049, 0.873, -2.726, -0.367]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:36131c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25], 
      "ysrc": "harry11733:104:b8757f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 25, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame27 = {
  "data": [
    {
      "xsrc": "harry11733:104:8d8266", 
      "x": [-0.602, -2.913, -2.641, -3.761, -0.258, -2.006, -2.999, -1.412, -3.486, -3.216, -1.278, -3.364, -2.293, -3.196, -0.188, -2.361, -2.428, -3.243, -0.685, -0.783, -1.926, -2.369, -2.983, -2.736, -3.288, -1.778, -3.857, -2.478, -2.221, -0.566, -3.026, -0.182, -2.28, -0.3, -2.095, -2.863, -0.749, -2.861, -3.708, -3.255, -2.756, -3.243, -2.043, -2.671, -1.419, -1.554, -2.494, -2.322, -3.068, -2.13], 
      "ysrc": "harry11733:104:21cb6e", 
      "y": [3.195, 3.022, -1.363, -1.403, -3.595, -1.146, 3.389, -2.242, -0.563, -0.918, -0.636, -3.495, 3.305, -0.23, -3.554, -1.708, -1.704, 1.74, 0.752, -1.711, -1.871, 3.038, -1.392, -1.685, 2.294, 1.582, 1.374, -2.247, 3.735, -1.803, -0.362, -0.777, -2.33, 3.091, -3.374, -0.458, -1.11, 1.871, -3.424, -1.331, 0.891, -2.473, 3.245, 2.401, -1.84, -1.958, -3.514, 1.219, -2.483, -0.142]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:10cec8", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26], 
      "ysrc": "harry11733:104:48e7f5", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 26, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame28 = {
  "data": [
    {
      "xsrc": "harry11733:104:d36fb2", 
      "x": [-0.384, -2.596, -2.219, -3.722, -0.791, -2.049, -2.737, -1.547, -3.724, -3.007, -1.227, -3.586, -2.616, -3.22, -0.295, -2.446, -2.791, -3.259, -0.618, -0.946, -2.034, -2.081, -3.392, -2.542, -2.79, -2.096, -3.532, -2.329, -1.827, -0.487, -3.241, -0.279, -2.499, -0.174, -1.741, -2.496, -1.668, -2.905, -3.694, -3.841, -2.213, -2.511, -2.228, -2.737, -1.872, -1.837, -2.459, -1.895, -2.59, -1.58], 
      "ysrc": "harry11733:104:17fef9", 
      "y": [3.196, 3.138, -1.796, -0.92, -3.735, -1.088, 3.617, -2.361, -0.904, -1.073, -0.171, -3.032, 3.388, 0.225, -3.581, -1.908, -1.847, 1.641, 0.086, -1.584, -1.913, 3.329, -1.42, -2.2, 1.783, 1.54, 1.52, -2.582, 3.826, -1.666, -0.518, -1.098, -2.264, 3.002, -2.967, -0.428, -1.154, 1.698, -3.798, -1.437, 1.072, -2.382, 3.107, 3.099, -1.674, -1.841, -3.754, 1.167, -2.897, 0.137]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:327992", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27], 
      "ysrc": "harry11733:104:4602c1", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 27, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame29 = {
  "data": [
    {
      "xsrc": "harry11733:104:72a53c", 
      "x": [-0.154, -2.795, -2.082, -3.628, -0.511, -1.452, -2.423, -2.298, -3.792, -2.772, -1.546, -3.673, -2.299, -3.454, -0.521, -2.4, -3.03, -2.717, -0.414, -1.56, -2.434, -2.189, -3.371, -2.187, -2.809, -1.917, -3.587, -2.832, -1.835, -0.746, -2.243, -0.738, -2.124, -0.388, -2.081, -2.16, -1.883, -3.074, -3.749, -3.685, -2.502, -2.782, -1.804, -2.612, -1.671, -1.871, -2.333, -1.509, -3.067, -1.818], 
      "ysrc": "harry11733:104:cbc18d", 
      "y": [3.363, 3.538, -2.108, -0.565, -3.711, -1.408, 3.653, -2.01, -0.813, -0.608, -0.273, -3.144, 3.099, 0.435, -3.164, -1.742, -2.151, 1.89, -0.737, -1.406, -1.903, 3.458, -1.424, -2.638, 2.042, 2.001, 1.74, -2.458, 3.73, -1.526, -0.152, -0.557, -2.334, 3.257, -3.428, -0.132, -1.348, 1.608, -3.829, -1.549, 0.999, -2.349, 2.792, 3.139, -2.118, -2.008, -3.025, 1.154, -2.948, 0.156]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a36470", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28], 
      "ysrc": "harry11733:104:a45d2a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 28, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame30 = {
  "data": [
    {
      "xsrc": "harry11733:104:0d8efc", 
      "x": [-0.216, -2.807, -2.194, -3.108, -0.616, -1.219, -2.316, -3.154, -3.695, -2.344, -1.332, -3.749, -2.424, -3.385, -0.725, -2.541, -2.96, -3.182, -0.453, -1.848, -2.261, -2.105, -3.057, -2.037, -2.975, -2.371, -3.541, -2.763, -1.905, -0.617, -2.035, -0.301, -2.089, -0.218, -2.12, -2.182, -1.564, -2.704, -3.676, -3.419, -1.944, -2.451, -1.711, -3.296, -1.635, -1.944, -2.272, -1.166, -3.227, -2.316], 
      "ysrc": "harry11733:104:4f82a6", 
      "y": [2.958, 3.221, -2.612, -0.399, -3.588, -0.854, 3.656, -2.172, -0.24, -0.828, -0.827, -3.278, 2.74, 0.553, -2.858, -1.619, -2.13, 1.915, -0.63, -1.696, -1.731, 3.519, -1.306, -2.07, 2.175, 1.735, 1.719, -3.004, 3.85, -1.214, -0.1, -0.483, -1.909, 3.5, -3.289, -0.014, -1.486, 1.678, -3.822, -1.56, 0.929, -2.551, 2.939, 2.954, -1.943, -1.951, -2.75, 0.546, -2.905, -0.359]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:aa1979", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29], 
      "ysrc": "harry11733:104:46c9c8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 29, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame31 = {
  "data": [
    {
      "xsrc": "harry11733:104:f731f7", 
      "x": [-0.467, -2.888, -2.301, -3.215, -0.852, -1.589, -1.868, -3.292, -3.682, -2.502, -1.31, -3.732, -1.889, -3.27, -0.848, -2.255, -2.79, -3.152, -0.524, -1.406, -2.379, -1.781, -3.203, -2.509, -3.177, -1.87, -3.411, -2.541, -1.642, -0.542, -2.036, -0.677, -1.993, -0.444, -2.309, -1.937, -1.357, -3.075, -3.805, -3.603, -1.809, -2.515, -2.185, -3.585, -1.558, -1.947, -1.825, -0.766, -3.499, -2.317], 
      "ysrc": "harry11733:104:c08b6f", 
      "y": [2.54, 3.532, -2.223, -0.481, -3.143, -0.577, 3.81, -1.437, 0.021, -1.353, -1.014, -2.894, 2.436, 0.795, -2.812, -1.285, -2.053, 1.489, -0.408, -1.431, -1.821, 3.448, -1.268, -1.506, 1.387, 1.88, 1.966, -3.299, 3.73, -1.115, 0.012, -0.444, -1.629, 3.783, -3.671, -0.642, -1.995, 1.486, -3.383, -1.934, 1.166, -2.635, 3.512, 2.855, -1.882, -1.996, -2.435, 0.533, -3.017, -0.471]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e9b07e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30], 
      "ysrc": "harry11733:104:c4a530", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 30, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame32 = {
  "data": [
    {
      "xsrc": "harry11733:104:eb652c", 
      "x": [-0.939, -3.128, -2.55, -2.656, -0.552, -1.819, -2.312, -3.297, -3.349, -2.17, -1.113, -3.602, -2.148, -3.019, -1.26, -2.463, -3.147, -3.085, -0.139, -1.562, -2.322, -1.788, -2.753, -2.525, -3.198, -1.82, -3.764, -2.109, -1.558, -0.532, -1.735, -0.572, -2.678, -0.527, -2.048, -1.829, -1.439, -3.332, -3.85, -3.218, -1.339, -2.453, -1.915, -3.591, -1.28, -1.912, -2.055, -1.015, -3.837, -2.454], 
      "ysrc": "harry11733:104:496a68", 
      "y": [2.691, 3.327, -2.17, -0.23, -3.193, -0.407, 3.822, -0.997, -0.423, -1.275, -0.992, -2.697, 2.807, 0.706, -2.463, -1.341, -1.748, 1.554, -0.368, -1.299, -2.362, 3.527, -1.577, -0.726, 1.658, 1.362, 1.967, -3.215, 3.803, -1.405, 0.359, -0.241, -1.523, 3.787, -3.854, -0.719, -2.636, 1.387, -3.61, -1.962, 0.721, -1.757, 3.731, 3.265, -2.235, -1.705, -2.63, 0.29, -2.875, -0.991]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ddb0e0", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31], 
      "ysrc": "harry11733:104:4ddb0d", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 31, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame33 = {
  "data": [
    {
      "xsrc": "harry11733:104:4256d0", 
      "x": [-1.294, -3.254, -2.294, -2.319, -0.158, -2.164, -2.241, -3.508, -3.135, -1.663, -1.447, -3.478, -2.412, -2.699, -0.763, -2.717, -3.322, -3.083, -0.214, -1.146, -2.128, -2.426, -2.954, -2.384, -2.761, -1.712, -3.647, -2.006, -0.591, -0.933, -1.851, -0.527, -2.562, -0.24, -2.274, -2.567, -1.03, -3.7, -3.788, -3.372, -1.279, -2.144, -1.358, -3.409, -0.865, -2.061, -1.993, -1.397, -3.454, -2.965], 
      "ysrc": "harry11733:104:d95d03", 
      "y": [2.549, 3.761, -2.288, 0.046, -2.963, 0.495, 3.728, -1.017, -0.169, -1.448, -1.272, -2.779, 2.791, 0.441, -2.761, -1.713, -1.967, 1.198, -0.409, -1.299, -3.121, 3.488, -1.005, -0.66, 1.476, 1.73, 2.094, -2.797, 3.747, -2.072, 0.723, -0.317, -1.172, 3.494, -3.692, -0.864, -3.11, 0.866, -3.425, -1.792, 0.689, -1.962, 3.789, 3.419, -2.436, -2.059, -2.773, 0.069, -3.197, -0.618]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e3b303", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32], 
      "ysrc": "harry11733:104:1407f5", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 32, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame34 = {
  "data": [
    {
      "xsrc": "harry11733:104:b2c329", 
      "x": [-1.57, -3.656, -2.177, -2.508, -0.495, -2.382, -2.41, -3.368, -3.369, -2.529, -0.947, -3.191, -2.389, -2.776, -0.947, -2.803, -3.513, -2.9, -0.6, -1.278, -2.032, -2.312, -2.992, -2.42, -2.22, -1.41, -3.442, -2.112, -0.54, -0.662, -1.738, -0.691, -2.701, -0.228, -2.819, -2.345, -0.606, -3.794, -3.623, -2.91, -1.282, -1.978, -2.092, -3.68, -0.379, -1.457, -2.527, -1.59, -3.69, -2.873], 
      "ysrc": "harry11733:104:2157df", 
      "y": [1.976, 3.814, -1.889, 0.165, -3.184, 0.105, 3.739, -1.196, 0.147, -1.697, -1.035, -2.458, 2.697, 0.295, -2.905, -1.992, -2.056, 1.583, -0.952, -1.678, -2.946, 3.685, -0.569, -0.617, 0.919, 1.429, 2.383, -2.497, 3.268, -2.142, 0.899, -0.416, -0.883, 3.189, -3.735, -0.684, -3.308, 0.313, -3.452, -1.793, 0.712, -2.308, 3.762, 3.196, -2.455, -2.319, -2.828, 0.473, -3.099, -0.39]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:de752f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33], 
      "ysrc": "harry11733:104:dc79af", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 33, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame35 = {
  "data": [
    {
      "xsrc": "harry11733:104:8e0319", 
      "x": [-1.91, -3.492, -2.198, -2.845, -0.447, -2.619, -2.519, -3.494, -3.156, -2.689, -0.489, -2.906, -2.391, -2.941, -0.737, -2.874, -3.412, -3.062, -1.024, -1.632, -1.955, -2.605, -3.287, -2.876, -2.295, -1.628, -3.574, -2.622, -0.748, -0.38, -1.374, -0.725, -2.784, -0.263, -3.074, -2.323, -0.901, -3.836, -3.492, -3.379, -1.436, -2.526, -2.113, -3.796, -0.586, -1.309, -2.467, -1.308, -3.686, -3.141], 
      "ysrc": "harry11733:104:0b7e5c", 
      "y": [1.386, 3.519, -1.548, 0.179, -3.292, -0.081, 3.399, -1.04, 0.095, -2.256, -1.664, -2.47, 3.179, -0.048, -3.104, -1.774, -2.158, 2.327, -0.565, -1.409, -2.889, 3.769, -0.48, -0.418, 1.378, 0.868, 2.316, -2.268, 3.769, -1.996, 0.479, -0.146, -0.62, 3.407, -3.81, -0.44, -3.204, 0.822, -2.996, -2.397, 1.44, -2.392, 3.828, 3.507, -2.611, -2.383, -3.207, 0.541, -2.779, -0.379]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:5df493", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34], 
      "ysrc": "harry11733:104:f3b858", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 34, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame36 = {
  "data": [
    {
      "xsrc": "harry11733:104:e96141", 
      "x": [-2.363, -3.49, -2.333, -3.053, -0.311, -2.131, -2.624, -3.423, -2.823, -2.578, -0.235, -3.265, -2.386, -2.427, -0.265, -2.823, -3.695, -3.231, -0.774, -1.725, -2.115, -2.192, -3.183, -2.833, -2.128, -1.343, -3.525, -2.616, -0.186, -0.438, -0.784, -0.711, -2.858, -0.559, -2.481, -2.568, -1.239, -3.808, -3.512, -3.432, -1.248, -2.445, -1.993, -3.689, -0.25, -1.564, -2.544, -1.453, -2.96, -3.602], 
      "ysrc": "harry11733:104:78a3ad", 
      "y": [1.514, 3.536, -2.057, -0.428, -3.235, -0.055, 3.263, -0.874, 0.299, -1.988, -0.829, -2.497, 2.826, -0.161, -2.387, -1.847, -2.416, 1.898, -0.369, -1.663, -3.091, 3.701, -0.709, -0.435, 1.487, 0.304, 1.871, -2.88, 3.851, -2.165, 0.696, -0.606, -0.85, 3.501, -3.851, -0.794, -3.344, 1.361, -3.229, -2.327, 1.294, -2.317, 3.764, 3.35, -2.272, -2.176, -2.936, 0.115, -2.83, -0.033]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:9f2868", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35], 
      "ysrc": "harry11733:104:732449", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 35, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame37 = {
  "data": [
    {
      "xsrc": "harry11733:104:73a955", 
      "x": [-2.012, -3.162, -2.321, -2.905, -0.54, -1.908, -2.19, -3.237, -2.824, -2.578, -0.475, -3.83, -2.335, -2.451, -0.627, -2.672, -3.602, -3.012, -1.087, -1.567, -2.175, -2.449, -3.367, -2.622, -2.088, -1.319, -3.461, -2.467, -0.183, -0.312, -0.777, -0.665, -2.562, -0.614, -2.52, -2.332, -0.777, -3.798, -3.407, -3.48, -1.572, -1.868, -2.527, -3.629, -0.269, -1.331, -2.863, -1.451, -3.246, -3.144], 
      "ysrc": "harry11733:104:fded77", 
      "y": [1.501, 3.683, -2.345, -0.578, -3.776, 0.442, 3.481, -1.247, 0.582, -2.474, -0.638, -2.838, 3.173, -0.572, -2.257, -2.08, -2.743, 2.2, -0.299, -1.736, -2.859, 3.58, -0.455, 0.083, 1.14, 0.208, 1.396, -2.633, 3.765, -2.314, 0.367, -0.73, -1.311, 3.004, -3.089, -0.529, -3.562, 1.413, -3.418, -1.98, 0.954, -2.0, 3.719, 3.029, -1.913, -1.82, -2.941, -0.159, -3.222, 0.35]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f8402e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36], 
      "ysrc": "harry11733:104:155ca1", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 36, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame38 = {
  "data": [
    {
      "xsrc": "harry11733:104:ad57b2", 
      "x": [-2.496, -2.555, -2.957, -2.45, -0.716, -1.964, -2.392, -2.77, -2.732, -2.422, -0.372, -3.471, -2.176, -2.834, -0.769, -2.506, -3.616, -3.201, -0.915, -2.057, -1.667, -2.28, -3.421, -2.98, -2.095, -1.198, -3.637, -2.562, -0.342, -0.269, -0.919, -0.984, -2.864, -0.604, -2.344, -2.722, -0.948, -3.855, -3.623, -3.49, -0.967, -2.299, -2.105, -3.582, -0.167, -1.559, -3.101, -1.842, -2.989, -3.195], 
      "ysrc": "harry11733:104:f90a71", 
      "y": [1.467, 3.864, -2.113, -0.348, -3.706, 0.962, 3.652, -0.886, 0.839, -2.428, -0.519, -3.069, 2.781, -0.583, -2.481, -2.239, -3.009, 2.445, -0.431, -2.04, -2.525, 3.277, -0.686, -0.553, 0.752, -0.075, 1.702, -3.06, 3.452, -2.265, -0.133, -0.918, -1.303, 3.089, -2.773, -0.519, -3.394, 0.653, -3.399, -1.976, 0.801, -1.299, 3.7, 3.092, -1.782, -2.057, -3.555, -0.231, -3.267, 0.71]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:919cfc", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37], 
      "ysrc": "harry11733:104:ad2113", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 37, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame39 = {
  "data": [
    {
      "xsrc": "harry11733:104:f425f0", 
      "x": [-2.879, -3.111, -3.12, -2.262, -0.902, -2.144, -2.433, -2.711, -3.274, -2.377, -0.306, -3.123, -2.325, -2.386, -0.634, -2.625, -3.182, -3.14, -0.504, -1.831, -2.276, -2.09, -3.0, -2.911, -2.028, -0.909, -3.8, -2.517, -0.534, -0.534, -1.511, -1.152, -2.444, -1.231, -2.41, -2.6, -1.1, -3.758, -3.668, -2.967, -1.153, -2.072, -1.762, -3.563, -0.246, -1.418, -2.46, -2.488, -3.437, -3.498], 
      "ysrc": "harry11733:104:1c042e", 
      "y": [1.102, 3.299, -1.767, -0.275, -3.309, 0.394, 3.708, -0.755, 0.969, -2.78, -0.361, -2.95, 2.944, -0.356, -2.608, -2.164, -3.37, 2.542, -0.919, -1.623, -2.112, 3.157, -0.483, -0.643, 1.079, 0.142, 1.314, -2.952, 3.354, -2.488, -0.504, -0.244, -1.311, 3.07, -2.668, -0.427, -3.079, 0.508, -3.161, -2.25, 0.807, -1.243, 3.512, 3.122, -1.938, -2.26, -3.741, -0.342, -2.98, 0.503]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:5f1255", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38], 
      "ysrc": "harry11733:104:e1bb78", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 38, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame40 = {
  "data": [
    {
      "xsrc": "harry11733:104:16ca78", 
      "x": [-2.937, -2.856, -3.37, -2.841, -0.647, -2.611, -2.283, -2.531, -3.33, -2.441, -0.255, -2.987, -1.862, -2.162, -1.04, -2.522, -3.739, -2.912, -0.245, -1.509, -2.356, -2.538, -2.561, -2.67, -2.108, -1.392, -3.578, -2.14, -0.641, -0.504, -1.693, -1.325, -2.151, -0.432, -2.689, -2.742, -1.7, -3.659, -3.766, -2.742, -1.394, -2.162, -1.192, -3.545, -0.491, -1.835, -3.099, -2.268, -3.534, -3.71], 
      "ysrc": "harry11733:104:372de6", 
      "y": [1.573, 3.293, -1.057, 0.055, -3.446, 0.227, 3.495, -1.038, 1.087, -2.909, -0.586, -3.075, 2.918, -0.268, -2.207, -2.057, -3.689, 2.373, -1.249, -1.776, -2.228, 2.958, -0.196, -0.608, 1.179, 0.229, 1.951, -2.747, 3.561, -2.557, -0.212, 0.224, -1.625, 2.918, -3.08, -0.294, -2.636, 0.468, -3.174, -2.024, 1.081, -1.279, 3.853, 2.623, -1.705, -2.894, -3.723, -0.541, -2.511, 0.572]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:65b8c9", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39], 
      "ysrc": "harry11733:104:8bd66a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 39, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame41 = {
  "data": [
    {
      "xsrc": "harry11733:104:a0e254", 
      "x": [-3.143, -3.26, -2.795, -2.98, -0.877, -2.819, -2.568, -1.989, -3.694, -2.259, -0.189, -2.976, -1.555, -1.913, -1.012, -2.532, -3.835, -2.729, -0.58, -1.448, -2.077, -2.8, -2.857, -3.032, -2.472, -1.501, -3.412, -2.502, -0.828, -0.6, -1.887, -1.561, -2.434, -0.798, -2.683, -3.24, -1.552, -3.459, -3.589, -2.257, -0.843, -2.09, -1.311, -3.244, -0.387, -1.128, -3.494, -2.074, -3.434, -3.648], 
      "ysrc": "harry11733:104:01d813", 
      "y": [1.644, 2.744, -1.005, 0.254, -3.053, 0.266, 3.865, -1.18, 0.95, -2.727, -0.832, -3.0, 3.226, -0.186, -2.494, -2.177, -3.293, 2.922, -0.875, -1.651, -2.843, 3.499, -0.139, -0.857, 1.74, 0.119, 2.32, -2.356, 3.448, -2.667, -0.308, -0.19, -1.094, 2.665, -3.149, -0.15, -2.988, 0.564, -3.013, -2.143, 1.489, -0.832, 3.838, 2.183, -1.926, -3.103, -3.777, -0.194, -2.588, 0.766]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:d6223b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40], 
      "ysrc": "harry11733:104:1db7b2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 40, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame42 = {
  "data": [
    {
      "xsrc": "harry11733:104:6fe07a", 
      "x": [-3.421, -3.001, -2.434, -2.809, -1.149, -3.206, -2.9, -1.727, -3.755, -2.316, -0.293, -3.345, -2.163, -1.924, -1.682, -2.704, -3.756, -2.442, -0.581, -1.41, -2.063, -3.224, -2.933, -2.679, -2.595, -1.757, -3.24, -2.146, -0.759, -0.227, -1.273, -1.941, -2.214, -1.314, -2.643, -3.504, -1.168, -3.845, -3.855, -2.417, -1.005, -1.996, -0.676, -3.529, -0.398, -0.61, -3.72, -2.236, -3.706, -3.128], 
      "ysrc": "harry11733:104:c7c8db", 
      "y": [1.546, 2.543, -0.614, 0.208, -2.556, 0.272, 3.773, -1.214, 0.868, -3.135, -0.79, -2.77, 3.139, -0.339, -2.884, -1.736, -3.236, 3.153, -0.848, -1.977, -3.018, 3.852, -0.35, -0.615, 1.766, -0.334, 2.471, -2.284, 3.498, -2.72, -0.09, -0.128, -1.067, 2.65, -2.832, 0.315, -2.779, 1.304, -2.418, -1.896, 1.556, -1.168, 3.533, 2.289, -2.238, -2.812, -3.743, -0.193, -2.554, 0.984]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:31cb2f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41], 
      "ysrc": "harry11733:104:e40286", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 41, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame43 = {
  "data": [
    {
      "xsrc": "harry11733:104:74eb79", 
      "x": [-3.521, -2.929, -2.148, -2.177, -1.555, -3.601, -3.86, -1.966, -3.322, -2.043, -0.186, -3.806, -2.413, -1.615, -1.733, -2.618, -3.388, -1.804, -0.438, -1.552, -2.475, -2.95, -2.551, -2.266, -2.457, -1.598, -3.161, -1.909, -1.39, -0.358, -1.383, -2.278, -1.87, -1.461, -3.239, -3.718, -1.262, -3.771, -3.758, -2.582, -0.426, -1.796, -0.227, -3.335, -0.437, -0.39, -3.827, -1.609, -3.238, -2.893], 
      "ysrc": "harry11733:104:99bd71", 
      "y": [1.525, 3.232, -1.426, -0.068, -2.865, 0.531, 3.764, -0.87, 0.884, -3.657, -0.169, -3.382, 3.223, -0.333, -3.515, -1.552, -3.227, 3.375, -1.424, -2.298, -3.089, 3.573, -0.114, -0.388, 1.692, -0.172, 2.495, -2.197, 3.743, -2.932, 0.656, -0.342, -0.877, 2.687, -3.291, 0.261, -3.327, 1.351, -2.773, -1.381, 1.296, -1.28, 3.594, 1.583, -2.126, -3.148, -3.824, -0.202, -2.512, 0.98]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:3dab75", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42], 
      "ysrc": "harry11733:104:7adf7a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 42, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame44 = {
  "data": [
    {
      "xsrc": "harry11733:104:e8d2b2", 
      "x": [-3.727, -3.499, -1.954, -2.734, -1.271, -2.952, -3.863, -2.408, -3.345, -2.216, -0.276, -3.795, -1.807, -1.904, -1.426, -3.115, -3.297, -2.001, -0.791, -1.44, -2.474, -3.023, -2.841, -1.857, -2.008, -2.063, -3.516, -1.955, -1.814, -0.253, -0.769, -2.234, -1.825, -1.703, -2.805, -3.604, -1.553, -3.786, -3.839, -2.367, -0.669, -2.009, -0.905, -3.494, -0.532, -0.56, -3.378, -1.157, -3.838, -3.175], 
      "ysrc": "harry11733:104:8670dd", 
      "y": [1.518, 3.418, -1.496, -0.206, -2.795, 0.74, 3.755, -1.078, 0.722, -3.587, -0.233, -3.47, 3.244, -0.387, -3.092, -1.83, -3.031, 3.478, -1.038, -2.191, -3.305, 3.678, -0.039, -0.012, 1.612, -0.572, 2.468, -1.558, 3.637, -3.219, 0.342, -0.363, -0.759, 3.035, -3.549, -0.019, -3.484, 1.378, -2.874, -1.476, 1.595, -0.949, 3.584, 1.965, -1.342, -3.38, -3.729, -0.65, -2.805, 0.64]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a0fa43", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43], 
      "ysrc": "harry11733:104:4437e1", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 43, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame45 = {
  "data": [
    {
      "xsrc": "harry11733:104:b62856", 
      "x": [-3.78, -3.591, -2.025, -3.3, -1.131, -3.066, -3.581, -2.109, -3.2, -2.079, -0.253, -3.827, -1.892, -2.253, -1.566, -3.56, -2.869, -2.192, -0.71, -0.916, -2.385, -3.137, -3.016, -1.634, -2.101, -1.506, -3.688, -2.001, -1.896, -0.856, -0.492, -2.221, -1.818, -1.192, -2.744, -3.622, -1.923, -3.676, -3.339, -2.878, -0.633, -1.72, -0.415, -3.666, -0.601, -0.522, -2.969, -1.68, -2.958, -3.287], 
      "ysrc": "harry11733:104:390a08", 
      "y": [1.459, 3.609, -1.565, 0.171, -3.113, 0.566, 3.706, -0.606, 0.887, -3.857, -0.638, -3.854, 3.082, -0.789, -3.437, -1.615, -2.638, 3.86, -1.295, -2.343, -2.863, 3.53, -0.26, 0.191, 2.093, -0.379, 2.652, -1.266, 3.746, -3.288, 0.675, -0.342, -0.553, 3.313, -3.56, -0.237, -3.564, 1.444, -2.366, -0.967, 2.108, -0.43, 3.676, 1.511, -1.134, -3.229, -3.751, -0.834, -2.869, 0.387]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:27e60f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44], 
      "ysrc": "harry11733:104:3cffa6", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 44, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame46 = {
  "data": [
    {
      "xsrc": "harry11733:104:721c78", 
      "x": [-3.531, -3.819, -2.08, -3.271, -1.252, -2.934, -3.662, -2.662, -3.081, -1.887, -0.725, -3.742, -1.782, -2.224, -1.536, -3.328, -2.755, -2.212, -1.125, -0.781, -2.595, -3.196, -3.45, -1.696, -2.162, -1.603, -3.59, -2.11, -2.214, -1.047, -0.819, -2.355, -1.958, -1.295, -2.7, -3.202, -2.59, -3.172, -2.723, -3.034, -0.475, -1.088, -0.414, -3.483, -0.719, -0.75, -3.229, -1.105, -2.778, -3.819], 
      "ysrc": "harry11733:104:aebb90", 
      "y": [1.415, 3.228, -1.19, -0.033, -3.704, 0.164, 3.521, -0.566, 0.592, -3.571, -0.396, -3.76, 3.339, -0.509, -3.185, -1.561, -2.022, 3.653, -1.472, -2.366, -2.535, 3.808, -0.229, -0.118, 2.437, -0.289, 2.692, -1.585, 3.261, -3.614, 0.191, -0.662, -0.557, 3.341, -3.667, -0.748, -3.706, 1.513, -2.411, -0.852, 1.634, -0.409, 3.644, 2.119, -0.901, -3.736, -2.885, -1.189, -2.516, 0.243]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a567ef", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45], 
      "ysrc": "harry11733:104:8fd17c", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 45, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame47 = {
  "data": [
    {
      "xsrc": "harry11733:104:a962ad", 
      "x": [-3.13, -3.511, -1.722, -3.429, -0.959, -2.971, -3.488, -2.741, -2.597, -1.837, -1.183, -3.585, -1.551, -1.873, -1.228, -3.017, -2.381, -1.556, -1.1, -0.139, -2.381, -3.156, -3.48, -1.987, -2.012, -1.604, -3.456, -2.159, -2.239, -1.26, -0.942, -2.26, -1.464, -1.512, -2.394, -3.188, -2.654, -2.882, -2.632, -2.955, -0.622, -1.802, -0.567, -3.54, -0.713, -1.124, -3.274, -0.923, -2.76, -3.708], 
      "ysrc": "harry11733:104:875b90", 
      "y": [1.611, 2.96, -1.275, -0.659, -3.76, 0.607, 3.323, -0.646, 0.653, -3.213, -0.873, -3.674, 3.169, -0.328, -2.738, -1.37, -1.817, 3.659, -1.222, -2.161, -2.786, 3.798, -0.191, -0.026, 1.995, -0.516, 2.844, -1.633, 3.088, -3.529, 0.254, -0.712, -0.674, 3.001, -3.441, -1.046, -3.635, 1.693, -2.639, -1.035, 1.797, -0.47, 3.651, 2.184, -0.65, -3.757, -2.664, -0.907, -2.482, 0.324]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:86f112", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46], 
      "ysrc": "harry11733:104:6e4f55", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 46, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame48 = {
  "data": [
    {
      "xsrc": "harry11733:104:33e0ce", 
      "x": [-3.206, -3.722, -1.107, -3.614, -0.792, -3.016, -3.615, -2.619, -2.512, -1.882, -0.912, -3.413, -0.903, -1.858, -0.797, -2.744, -3.102, -1.759, -1.143, -0.17, -2.136, -3.115, -3.796, -1.48, -1.821, -1.617, -3.153, -2.632, -2.762, -1.601, -1.403, -2.01, -1.888, -1.919, -2.433, -2.948, -2.67, -2.986, -2.249, -2.778, -0.651, -1.645, -0.897, -3.473, -1.093, -1.074, -3.101, -0.755, -2.201, -3.537], 
      "ysrc": "harry11733:104:2233be", 
      "y": [1.964, 2.667, -1.307, -0.29, -3.409, 1.072, 3.604, -0.193, 0.98, -3.67, -0.937, -3.633, 3.19, -0.565, -2.707, -0.999, -1.656, 3.122, -1.463, -1.681, -2.933, 3.737, 0.095, 0.07, 1.861, -0.416, 2.476, -1.612, 3.587, -3.62, 0.096, -0.482, -0.637, 2.632, -3.365, -0.91, -3.49, 2.073, -2.797, -1.131, 1.518, -0.559, 3.62, 2.253, -0.741, -3.331, -2.21, -0.969, -1.992, 0.628]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:13a656", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47], 
      "ysrc": "harry11733:104:25c109", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 47, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame49 = {
  "data": [
    {
      "xsrc": "harry11733:104:45f7da", 
      "x": [-3.588, -3.651, -0.506, -3.776, -1.023, -3.785, -3.184, -2.486, -2.457, -1.881, -0.544, -3.373, -1.196, -1.644, -0.704, -2.642, -2.261, -1.267, -1.302, -0.347, -1.829, -3.289, -3.702, -1.29, -1.855, -1.8, -2.997, -2.955, -3.109, -1.694, -1.029, -1.803, -1.691, -1.992, -2.122, -3.724, -2.637, -3.351, -3.0, -2.826, -0.638, -1.188, -0.663, -3.583, -1.046, -0.78, -3.128, -1.089, -2.388, -3.793], 
      "ysrc": "harry11733:104:7783bf", 
      "y": [1.508, 2.799, -1.608, 0.322, -2.918, 1.031, 3.66, -0.072, 1.605, -3.591, -0.725, -3.479, 3.43, -1.242, -2.853, -0.712, -1.616, 2.925, -2.126, -2.017, -3.018, 3.712, -0.344, 0.186, 1.632, -0.733, 2.18, -1.8, 3.71, -3.299, 0.455, -0.605, -0.793, 2.853, -2.955, -0.972, -3.366, 1.941, -2.786, -1.049, 1.956, -0.469, 3.77, 2.175, -0.676, -3.243, -2.468, -0.909, -2.267, 0.922]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f3922d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48], 
      "ysrc": "harry11733:104:b4562b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 48, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame50 = {
  "data": [
    {
      "xsrc": "harry11733:104:9d6721", 
      "x": [-3.793, -3.364, -0.858, -3.715, -0.797, -3.437, -3.278, -2.6, -2.343, -2.02, -1.107, -3.267, -1.088, -1.548, -0.281, -2.374, -1.878, -1.346, -1.662, -0.283, -2.064, -3.248, -3.839, -0.71, -2.167, -2.153, -3.335, -3.066, -3.27, -1.627, -1.151, -1.773, -1.743, -2.127, -2.074, -3.555, -2.748, -3.116, -3.413, -3.187, -0.719, -0.964, -0.853, -3.625, -1.322, -0.552, -3.344, -1.07, -2.673, -3.541], 
      "ysrc": "harry11733:104:f8d5f6", 
      "y": [1.283, 2.86, -1.814, 0.582, -2.773, 0.718, 2.95, -0.062, 1.312, -3.193, -1.176, -3.086, 3.753, -1.471, -2.697, -0.505, -2.041, 2.939, -2.302, -2.516, -2.955, 3.596, -0.266, 0.328, 1.244, -0.465, 2.382, -1.968, 3.853, -3.568, 0.677, -0.79, -1.102, 2.912, -3.143, -0.53, -3.411, 1.553, -3.189, -1.058, 1.977, -0.252, 3.135, 2.588, -0.692, -3.209, -2.642, -0.766, -2.097, 0.842]
    }, 
    {
      "line": {"color": "red"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:9dc202", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49], 
      "ysrc": "harry11733:104:35a3ff", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 49, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame51 = {
  "data": [
    {
      "xsrc": "harry11733:104:41619d", 
      "x": [-3.611, -3.546, -0.641, -3.269, -0.414, -3.383, -2.762, -2.095, -1.594, -2.257, -0.832, -3.222, -1.214, -1.296, -0.842, -2.512, -1.935, -1.503, -1.485, -0.442, -2.013, -2.856, -3.595, -0.652, -2.609, -2.04, -3.664, -3.627, -3.381, -2.375, -1.14, -1.751, -2.417, -2.342, -2.035, -3.191, -2.503, -2.846, -3.157, -3.037, -0.833, -0.738, -0.619, -3.701, -1.496, -0.443, -2.925, -0.911, -2.336, -3.272], 
      "ysrc": "harry11733:104:72f4fe", 
      "y": [1.184, 2.613, -1.965, 0.641, -3.212, 0.874, 3.2, -0.458, 1.488, -2.729, -1.189, -2.801, 3.486, -1.811, -2.656, -0.59, -1.756, 2.967, -1.86, -3.255, -3.031, 3.392, -0.31, 0.149, 0.358, -0.759, 2.439, -1.78, 3.526, -3.211, 0.521, -0.633, -1.109, 2.434, -3.33, -0.902, -3.46, 1.899, -3.062, -1.176, 2.08, -0.087, 2.915, 2.48, -0.54, -3.0, -2.254, -0.38, -1.685, 0.598]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:cfbfc6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50], 
      "ysrc": "harry11733:104:8e4e5c", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    }
  ], 
  "name": 50, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame52 = {
  "data": [
    {
      "xsrc": "harry11733:104:03b8ad", 
      "x": [-3.719, -3.825, -0.979, -3.579, -0.806, -3.121, -2.474, -2.096, -1.658, -2.797, -1.269, -2.619, -0.734, -1.547, -0.759, -2.637, -1.579, -1.688, -1.246, -0.852, -1.721, -2.977, -3.522, -0.388, -2.891, -2.393, -3.626, -3.679, -3.366, -2.405, -1.047, -2.174, -2.511, -2.831, -1.821, -3.078, -2.617, -3.066, -3.162, -2.871, -0.168, -0.961, -0.74, -3.579, -1.14, -0.751, -3.11, -1.636, -2.195, -3.184], 
      "ysrc": "harry11733:104:5e9260", 
      "y": [0.734, 2.795, -2.009, 0.525, -3.443, 0.57, 3.029, -0.367, 1.404, -2.451, -1.448, -2.658, 3.33, -2.293, -2.974, -0.453, -1.706, 2.74, -1.324, -3.268, -3.079, 3.352, -0.198, -0.272, 0.414, -0.777, 2.44, -1.169, 3.268, -3.286, -0.131, -0.738, -1.134, 2.133, -3.628, -0.985, -3.154, 1.634, -2.926, -0.898, 1.565, 0.056, 3.012, 2.828, -1.166, -2.584, -2.265, -0.258, -1.215, 0.097]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:13878d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51], 
      "ysrc": "harry11733:104:5f5eb6", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368]
    }
  ], 
  "name": 51, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame53 = {
  "data": [
    {
      "xsrc": "harry11733:104:8c27ef", 
      "x": [-3.835, -3.73, -0.565, -3.664, -1.106, -2.859, -2.329, -2.061, -1.0, -2.748, -0.751, -2.2, -0.515, -1.462, -0.185, -2.876, -1.537, -2.271, -0.877, -0.768, -0.741, -3.371, -3.332, -0.42, -3.484, -2.253, -3.468, -3.694, -3.423, -2.111, -1.027, -3.26, -2.693, -3.265, -2.252, -3.039, -1.944, -2.599, -3.036, -3.302, 0.13, -0.946, -1.111, -3.806, -1.133, -1.164, -2.864, -1.38, -2.261, -2.743], 
      "ysrc": "harry11733:104:f400b5", 
      "y": [0.357, 2.083, -1.7, 0.466, -3.418, 0.886, 3.133, 0.004, 1.139, -1.836, -1.161, -2.492, 3.484, -2.504, -3.215, -0.335, -2.464, 2.477, -0.946, -3.186, -3.551, 3.517, -0.376, -0.538, 0.482, -1.104, 2.757, -0.962, 3.147, -3.017, 0.0, -0.502, -0.975, 2.832, -3.646, -1.249, -3.033, 1.54, -2.597, -0.863, 1.467, 0.774, 3.009, 2.774, -1.311, -2.576, -2.139, 0.073, -0.477, -0.56]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:3cf612", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52], 
      "ysrc": "harry11733:104:d8cbd2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692]
    }
  ], 
  "name": 52, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame54 = {
  "data": [
    {
      "xsrc": "harry11733:104:87ba55", 
      "x": [-3.743, -3.635, -0.232, -3.253, -1.277, -2.863, -2.56, -2.383, -1.161, -2.707, -1.106, -1.95, -0.294, -1.646, -0.031, -3.3, -1.385, -2.509, -0.741, -0.492, -1.469, -3.452, -3.103, -0.202, -2.9, -1.789, -2.821, -3.717, -2.926, -2.314, -0.832, -3.842, -2.972, -3.159, -2.482, -3.565, -2.533, -3.033, -3.325, -2.822, 0.616, -1.419, -0.979, -3.529, -1.337, -1.42, -2.809, -1.187, -1.894, -2.324], 
      "ysrc": "harry11733:104:3207d1", 
      "y": [0.663, 1.719, -1.881, 0.246, -3.816, -0.058, 3.367, 0.123, 1.329, -1.628, -1.239, -2.321, 3.493, -2.687, -3.347, -0.428, -2.391, 2.085, -0.306, -2.819, -3.113, 3.501, -0.926, -0.783, 0.345, -0.975, 2.866, -0.662, 3.45, -2.864, 0.156, -0.334, -1.242, 2.704, -3.611, -1.493, -3.065, 1.821, -2.89, -0.992, 1.277, 0.408, 2.857, 2.821, -1.211, -2.674, -1.499, 0.043, -0.655, -0.148]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:aeb256", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53], 
      "ysrc": "harry11733:104:957fee", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772]
    }
  ], 
  "name": 53, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame55 = {
  "data": [
    {
      "xsrc": "harry11733:104:1d4269", 
      "x": [-3.364, -3.502, 0.458, -2.889, -1.023, -2.752, -2.21, -1.896, -0.938, -2.502, -0.829, -1.74, -0.262, -1.632, -0.222, -3.345, -1.765, -2.503, -0.488, -0.707, -1.326, -3.38, -2.846, -0.679, -3.017, -1.75, -3.27, -3.753, -2.604, -2.81, -0.467, -3.783, -3.23, -3.286, -2.368, -3.621, -2.77, -2.915, -3.489, -3.111, 0.824, -1.756, -1.377, -3.53, -1.353, -2.036, -2.682, -1.163, -1.749, -2.416], 
      "ysrc": "harry11733:104:b1cc32", 
      "y": [0.928, 1.406, -1.749, 0.034, -3.687, -0.361, 2.958, -0.129, 1.062, -1.817, -1.062, -2.793, 2.9, -2.974, -3.656, -0.629, -2.367, 1.533, -0.224, -2.565, -3.038, 2.77, -0.583, -1.105, 0.453, -1.824, 3.2, -0.704, 3.854, -2.339, 0.2, -0.331, -1.496, 2.992, -3.368, -1.761, -2.802, 1.401, -2.743, -0.987, 1.324, 0.221, 2.551, 2.617, -0.747, -2.747, -1.406, 0.14, -0.339, 0.181]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:63704c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54], 
      "ysrc": "harry11733:104:a66cd8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004]
    }
  ], 
  "name": 54, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame56 = {
  "data": [
    {
      "xsrc": "harry11733:104:1960da", 
      "x": [-3.151, -3.461, -0.11, -2.84, -0.937, -3.174, -2.325, -2.11, -1.061, -2.615, -0.683, -1.534, -0.621, -1.546, -0.406, -3.353, -2.039, -2.247, -0.542, -0.819, -1.059, -3.577, -2.817, -0.925, -2.841, -1.871, -3.3, -3.765, -3.044, -3.261, -0.387, -3.591, -3.798, -3.0, -2.08, -3.504, -2.564, -2.582, -3.571, -2.905, 0.675, -1.756, -1.061, -3.145, -1.314, -1.546, -2.732, -0.955, -1.151, -1.949], 
      "ysrc": "harry11733:104:edcfe4", 
      "y": [0.914, 1.606, -1.262, -0.032, -3.693, -0.273, 2.533, -0.089, 1.567, -1.639, -1.017, -3.647, 2.958, -3.34, -3.431, -0.331, -2.333, 1.431, 0.131, -2.352, -2.881, 2.528, -0.674, -1.381, 0.191, -1.806, 3.097, -0.833, 3.626, -2.273, 0.893, -0.188, -1.232, 3.234, -3.475, -2.208, -2.97, 1.205, -2.272, -0.182, 0.636, 0.531, 3.018, 1.878, -0.903, -2.369, -1.129, 0.74, -0.611, 0.703]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a615f6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55], 
      "ysrc": "harry11733:104:dc4cc0", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164]
    }
  ], 
  "name": 55, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame57 = {
  "data": [
    {
      "xsrc": "harry11733:104:d62290", 
      "x": [-3.668, -3.415, -0.402, -2.689, -0.525, -3.031, -2.435, -2.213, -1.132, -2.442, -0.56, -1.25, -0.598, -0.983, 0.04, -3.492, -2.343, -2.297, -0.864, -1.17, -0.994, -3.749, -3.0, -0.973, -2.787, -1.982, -3.42, -3.818, -2.83, -3.103, -0.257, -3.76, -3.812, -3.415, -1.84, -3.175, -2.367, -3.145, -3.517, -2.747, 0.83, -1.947, -1.117, -3.068, -0.559, -1.757, -2.737, -1.179, -1.298, -1.469], 
      "ysrc": "harry11733:104:ccb69f", 
      "y": [1.142, 1.489, -1.902, -0.008, -3.445, -0.811, 2.975, -0.445, 1.973, -1.0, -1.1, -3.512, 3.307, -3.78, -3.324, -0.431, -2.283, 1.18, -0.539, -2.696, -3.076, 2.438, -0.294, -1.072, 0.177, -1.575, 3.422, -0.768, 3.585, -2.358, 1.034, 0.447, -1.707, 3.237, -3.29, -1.717, -3.346, 0.611, -1.765, -0.889, 0.358, 0.138, 2.784, 1.895, -1.45, -2.755, -1.822, 0.24, -0.91, 0.927]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0e33a7", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56], 
      "ysrc": "harry11733:104:c605d4", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332]
    }
  ], 
  "name": 56, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame58 = {
  "data": [
    {
      "xsrc": "harry11733:104:b1bbf0", 
      "x": [-3.459, -3.345, 0.089, -2.456, -0.545, -3.46, -2.83, -2.24, -1.172, -2.765, -0.696, -1.334, -0.308, -0.864, -0.226, -3.661, -1.849, -2.488, -0.906, -1.358, -1.261, -3.195, -2.918, -0.689, -2.492, -2.366, -3.833, -3.792, -2.454, -2.966, -0.627, -3.684, -3.703, -3.531, -2.22, -3.441, -2.724, -3.379, -3.132, -3.289, 0.532, -1.998, -1.048, -3.064, -0.653, -1.441, -2.757, -1.261, -1.314, -1.949], 
      "ysrc": "harry11733:104:5d897f", 
      "y": [0.796, 1.24, -2.158, -0.264, -3.809, -0.59, 2.508, -0.341, 2.478, -0.593, -0.808, -3.802, 3.76, -3.692, -2.995, -0.481, -2.078, 0.962, -0.675, -2.711, -2.822, 2.082, 0.265, -1.225, 0.322, -1.793, 3.619, -0.401, 3.616, -1.916, 1.155, 0.357, -1.699, 2.447, -3.38, -1.306, -3.581, 0.501, -1.226, -1.129, 0.488, -0.035, 2.587, 2.169, -1.312, -2.389, -1.99, 0.623, -1.111, 0.908]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0e3c75", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57], 
      "ysrc": "harry11733:104:1d4428", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468]
    }
  ], 
  "name": 57, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame59 = {
  "data": [
    {
      "xsrc": "harry11733:104:827af5", 
      "x": [-3.695, -3.064, -0.063, -2.669, -0.75, -3.137, -2.931, -1.788, -1.452, -2.719, -1.014, -1.2, -0.684, -1.337, -0.218, -3.089, -2.235, -3.174, -0.946, -1.648, -1.265, -2.826, -3.275, -1.346, -2.498, -2.892, -3.271, -3.763, -2.748, -3.307, -0.45, -3.712, -3.746, -3.344, -1.82, -3.348, -2.868, -3.134, -3.298, -3.399, 1.048, -1.512, -0.782, -2.753, -0.296, -1.618, -2.581, -1.563, -1.18, -1.923], 
      "ysrc": "harry11733:104:2ee29c", 
      "y": [0.318, 0.526, -2.286, -0.475, -3.772, 0.168, 2.364, -0.323, 2.245, -0.358, -0.997, -3.327, 3.837, -3.808, -2.926, -0.593, -2.111, 0.887, -0.514, -2.822, -2.842, 2.689, -0.169, -1.11, 1.009, -1.957, 3.697, -0.551, 3.727, -2.021, 1.068, 0.651, -2.203, 2.5, -3.772, -1.222, -3.327, 1.108, -0.857, -1.28, 0.406, 0.073, 2.34, 1.837, -1.16, -3.152, -2.051, 0.254, -1.526, 0.53]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:9b983d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58], 
      "ysrc": "harry11733:104:8aae85", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584]
    }
  ], 
  "name": 58, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame60 = {
  "data": [
    {
      "xsrc": "harry11733:104:cc535b", 
      "x": [-3.767, -2.718, -0.894, -2.851, -0.574, -2.835, -3.265, -1.578, -1.76, -3.102, -1.249, -1.384, -0.977, -1.725, 0.201, -2.841, -1.608, -3.246, -0.48, -2.133, -1.217, -3.271, -3.133, -1.415, -2.367, -3.269, -2.786, -3.681, -2.975, -2.927, -0.725, -3.362, -3.826, -3.602, -1.771, -3.581, -2.531, -3.38, -3.023, -3.319, 1.55, -1.439, -0.578, -3.094, -0.233, -1.47, -3.003, -2.075, -1.073, -1.771], 
      "ysrc": "harry11733:104:8011a3", 
      "y": [0.378, 0.488, -2.373, -0.082, -3.703, 0.178, 2.335, 0.271, 1.827, -0.222, -0.656, -3.178, 3.579, -3.8, -3.225, -0.517, -1.855, 0.964, -0.888, -2.416, -2.835, 2.625, -0.533, -1.076, 1.241, -1.964, 3.732, -0.163, 3.598, -1.617, 1.145, 1.011, -1.999, 2.596, -3.506, -1.346, -3.53, 1.657, -0.75, -0.834, 0.492, -0.363, 2.341, 2.25, -1.269, -2.937, -1.802, 0.115, -1.37, 0.25]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:064a28", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59], 
      "ysrc": "harry11733:104:04ddd7", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656]
    }
  ], 
  "name": 59, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame61 = {
  "data": [
    {
      "xsrc": "harry11733:104:25d5a7", 
      "x": [-3.805, -2.569, -0.356, -2.742, -0.465, -3.103, -3.52, -1.812, -2.013, -3.257, -1.186, -1.776, -1.342, -1.935, 0.418, -2.716, -1.276, -3.517, -0.976, -2.129, -1.232, -3.143, -3.443, -1.292, -2.383, -3.79, -2.728, -3.61, -2.506, -2.556, -0.625, -3.66, -3.819, -3.438, -2.135, -3.488, -2.682, -3.235, -2.817, -3.095, 1.224, -1.287, -0.21, -3.497, 0.148, -1.989, -3.206, -2.439, -0.933, -1.507], 
      "ysrc": "harry11733:104:76f80d", 
      "y": [0.435, 0.655, -2.478, -0.185, -3.852, 0.829, 2.157, 0.41, 1.534, -0.219, -0.755, -3.1, 3.373, -3.739, -2.973, -0.442, -1.947, 0.838, -1.287, -2.316, -2.26, 2.893, -0.562, -1.329, 1.107, -1.745, 3.858, -0.448, 3.683, -1.451, 0.933, 0.718, -2.149, 2.626, -3.852, -1.426, -3.826, 1.303, -0.34, -0.7, 0.425, -0.151, 2.288, 2.401, -1.281, -3.332, -1.519, 0.61, -1.563, 0.196]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:65fe17", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60], 
      "ysrc": "harry11733:104:94935b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812]
    }
  ], 
  "name": 60, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame62 = {
  "data": [
    {
      "xsrc": "harry11733:104:ca6db3", 
      "x": [-3.652, -2.364, -0.407, -2.519, -0.393, -3.677, -3.423, -2.318, -2.445, -2.852, -0.883, -1.712, -1.741, -1.416, 0.796, -2.758, -1.088, -3.235, -0.883, -2.043, -0.924, -3.22, -3.485, -1.556, -2.083, -3.807, -2.113, -3.688, -2.442, -2.913, -0.79, -3.328, -3.504, -3.263, -2.49, -3.804, -2.515, -3.057, -2.718, -2.981, 1.506, -1.374, -0.171, -3.586, 0.294, -1.841, -2.887, -2.08, -0.317, -1.832], 
      "ysrc": "harry11733:104:9227e3", 
      "y": [0.103, 0.881, -2.367, -0.461, -3.529, 1.495, 2.197, 0.161, 1.122, -0.753, -1.216, -3.302, 3.465, -3.661, -2.785, -0.106, -1.91, 0.794, -1.167, -2.549, -2.478, 2.385, -0.925, -1.278, 0.658, -1.382, 3.642, -0.713, 3.632, -1.18, 1.395, 0.91, -2.326, 2.376, -3.707, -2.09, -3.581, 1.318, -0.697, 0.166, 0.113, -0.378, 1.928, 2.472, -0.547, -3.586, -1.291, 0.753, -1.38, -0.356]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:860761", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61], 
      "ysrc": "harry11733:104:4c6d40", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864]
    }
  ], 
  "name": 61, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame63 = {
  "data": [
    {
      "xsrc": "harry11733:104:8e4227", 
      "x": [-3.832, -2.805, -0.237, -2.372, -0.093, -3.86, -2.911, -2.322, -2.276, -2.453, -0.462, -1.832, -1.993, -1.557, 0.776, -2.878, -1.214, -3.28, -0.964, -2.234, -0.79, -3.461, -3.68, -1.323, -1.928, -3.766, -2.186, -3.668, -2.293, -2.781, -0.288, -3.389, -3.551, -3.712, -3.164, -3.713, -2.516, -3.604, -2.357, -3.385, 1.509, -1.005, -0.271, -3.614, 0.024, -0.705, -2.714, -1.792, -0.35, -2.324], 
      "ysrc": "harry11733:104:11ac87", 
      "y": [-0.046, 0.725, -2.387, -0.061, -3.341, 1.882, 1.791, 0.091, 0.618, -0.074, -1.163, -3.291, 3.592, -3.762, -2.96, -0.353, -1.396, 1.002, -0.741, -2.626, -2.319, 2.067, -0.524, -0.618, 1.254, -1.251, 3.611, -0.674, 3.751, -1.403, 1.349, 0.637, -2.831, 1.914, -2.962, -2.244, -3.718, 1.13, -0.95, 0.387, 0.345, 0.064, 1.764, 2.357, -0.979, -3.279, -1.301, 0.638, -1.364, -0.542]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:df04a5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62], 
      "ysrc": "harry11733:104:6762a2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944]
    }
  ], 
  "name": 62, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame64 = {
  "data": [
    {
      "xsrc": "harry11733:104:dd5b14", 
      "x": [-3.629, -3.056, -0.066, -1.99, 0.395, -3.726, -2.523, -2.428, -2.111, -2.069, -0.59, -1.883, -3.027, -1.154, 0.594, -2.575, -0.688, -3.698, -0.68, -2.039, -0.555, -3.835, -3.478, -1.475, -1.709, -3.503, -1.745, -3.476, -2.052, -2.977, -0.299, -3.637, -3.83, -3.41, -3.063, -3.585, -2.501, -3.28, -2.468, -3.231, 2.008, -1.226, -0.307, -3.696, -0.028, -0.878, -2.668, -1.587, -0.16, -2.304], 
      "ysrc": "harry11733:104:90370f", 
      "y": [-0.022, 0.415, -2.677, 0.119, -3.464, 1.183, 2.077, 0.38, 0.488, 0.051, -1.017, -3.242, 3.735, -3.843, -2.646, -0.344, -1.132, 0.746, -1.373, -3.013, -2.508, 1.556, -1.203, -0.607, 0.922, -1.213, 3.111, -0.948, 3.596, -1.697, 1.519, 1.351, -2.858, 1.482, -2.745, -2.438, -3.772, 1.0, -1.102, 0.364, 0.077, 0.578, 1.157, 2.937, -1.18, -3.071, -1.382, 1.419, -1.039, -0.933]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e5710f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63], 
      "ysrc": "harry11733:104:e324f8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204]
    }
  ], 
  "name": 63, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame65 = {
  "data": [
    {
      "xsrc": "harry11733:104:0dcd65", 
      "x": [-3.681, -2.866, -0.212, -2.023, 0.398, -3.349, -2.757, -1.784, -2.345, -2.33, -1.09, -2.415, -2.808, -1.15, 0.278, -2.286, -0.058, -3.58, -0.715, -2.02, 0.175, -3.741, -3.003, -1.115, -1.695, -3.721, -1.493, -3.548, -2.697, -3.25, 0.342, -3.77, -3.854, -3.576, -3.102, -3.482, -2.507, -3.366, -2.688, -3.691, 1.358, -1.129, -0.565, -3.401, 0.265, -0.907, -2.865, -1.087, -0.29, -2.346], 
      "ysrc": "harry11733:104:285b8b", 
      "y": [0.4, 0.503, -3.064, -0.313, -3.167, 1.279, 2.116, 0.532, -0.049, -0.123, -1.174, -2.982, 3.646, -3.837, -2.183, -0.218, -0.903, 0.977, -1.083, -3.039, -2.369, 1.512, -1.699, -0.871, 0.878, -1.528, 2.729, -1.127, 3.813, -1.544, 1.898, 1.252, -2.981, 1.213, -3.161, -2.363, -3.767, 1.19, -0.818, 0.292, 0.505, 0.901, 1.378, 2.375, -1.354, -2.781, -1.602, 1.306, -0.58, -1.289]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:2040be", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64], 
      "ysrc": "harry11733:104:977f3d", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222]
    }
  ], 
  "name": 64, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame66 = {
  "data": [
    {
      "xsrc": "harry11733:104:192a1e", 
      "x": [-3.456, -2.691, -0.12, -2.234, 0.555, -3.303, -3.167, -1.685, -2.095, -2.256, -0.978, -2.342, -2.693, -1.103, 0.541, -2.694, 0.176, -2.739, -0.683, -1.96, 0.639, -3.812, -3.02, -1.576, -2.027, -3.618, -1.717, -3.537, -2.53, -3.052, 0.092, -3.672, -3.829, -3.766, -2.432, -3.491, -2.536, -2.656, -2.668, -3.103, 1.024, -1.408, -0.444, -2.993, 0.448, -0.556, -2.743, -0.885, -0.316, -2.811], 
      "ysrc": "harry11733:104:edc2ff", 
      "y": [0.379, 0.538, -2.374, -0.626, -3.014, 1.291, 1.99, 0.399, -0.654, -0.005, -0.774, -3.123, 3.192, -3.815, -2.54, 0.097, -0.052, 1.398, -0.967, -2.947, -2.19, 1.376, -1.137, -1.348, 0.76, -1.393, 3.023, -0.959, 3.584, -1.789, 1.294, 1.096, -3.207, 1.336, -2.638, -1.646, -3.706, 0.685, -0.441, 0.364, 0.101, 1.221, 1.725, 2.429, -1.032, -2.738, -1.686, 1.592, -0.269, -1.258]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e868d3", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65], 
      "ysrc": "harry11733:104:cb4b70", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232]
    }
  ], 
  "name": 65, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame67 = {
  "data": [
    {
      "xsrc": "harry11733:104:17a823", 
      "x": [-3.559, -2.899, -0.125, -2.829, 0.22, -3.421, -3.484, -1.672, -1.384, -2.846, -0.455, -2.365, -2.993, -1.525, 0.715, -3.132, 0.167, -2.655, -1.663, -1.87, 0.906, -3.29, -2.749, -1.391, -1.991, -3.6, -2.156, -3.601, -2.542, -3.836, 0.615, -3.838, -3.387, -3.603, -2.334, -3.536, -2.747, -2.658, -3.051, -2.967, 1.441, -1.694, -0.441, -3.374, 0.43, -0.816, -2.629, -1.291, -0.147, -3.39], 
      "ysrc": "harry11733:104:40062a", 
      "y": [0.223, 0.625, -2.22, -0.665, -3.368, 1.108, 1.799, 0.949, 0.075, -0.11, -1.066, -3.071, 3.087, -3.638, -2.95, 0.081, -0.292, 1.246, -0.532, -3.275, -1.852, 1.245, -0.721, -1.561, 0.789, -1.487, 3.17, -0.884, 3.739, -1.163, 1.802, 1.091, -2.858, 1.401, -2.443, -1.44, -3.678, 0.512, -0.895, 0.348, -0.3, 1.2, 1.474, 2.419, -0.835, -2.989, -1.791, 2.176, -0.085, -1.29]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ec2500", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66], 
      "ysrc": "harry11733:104:3d5478", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324]
    }
  ], 
  "name": 66, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame68 = {
  "data": [
    {
      "xsrc": "harry11733:104:f7081b", 
      "x": [-3.074, -2.725, -0.061, -3.674, 0.213, -3.4, -3.193, -1.617, -1.408, -2.948, -0.363, -1.98, -2.854, -1.335, 0.61, -3.259, -0.159, -2.768, -1.66, -2.146, 0.287, -3.113, -2.832, -2.004, -1.579, -3.83, -1.935, -3.62, -2.478, -3.131, 0.499, -3.752, -2.899, -3.492, -2.586, -3.45, -2.448, -2.802, -2.7, -3.294, 2.097, -1.279, -0.226, -3.153, 0.561, -0.783, -2.719, -1.232, -0.304, -3.259], 
      "ysrc": "harry11733:104:813f9a", 
      "y": [0.354, 1.277, -2.225, -0.679, -2.919, 1.641, 1.971, 0.821, -0.218, 0.285, -1.29, -3.313, 3.391, -3.736, -2.88, -0.438, -0.197, 1.277, -0.804, -3.093, -1.757, 1.042, -0.796, -2.149, 0.67, -1.6, 3.703, -0.58, 3.771, -0.769, 2.129, 0.781, -2.573, 1.439, -2.622, -1.283, -3.6, 0.327, -1.39, 0.287, -0.464, 1.317, 1.243, 2.884, -0.434, -2.931, -2.205, 2.237, -0.231, -1.11]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f833e4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67], 
      "ysrc": "harry11733:104:7e831d", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372]
    }
  ], 
  "name": 67, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame69 = {
  "data": [
    {
      "xsrc": "harry11733:104:ec1f5c", 
      "x": [-2.947, -3.01, -0.179, -3.478, 0.196, -3.598, -2.893, -1.227, -1.183, -2.776, -0.707, -2.428, -2.437, -1.454, 0.716, -3.487, -0.157, -2.839, -1.21, -2.216, 0.27, -2.94, -3.004, -1.825, -1.365, -3.668, -1.886, -3.415, -2.974, -3.576, 1.0, -3.859, -2.622, -3.847, -2.669, -2.838, -2.34, -3.198, -3.139, -3.358, 1.879, -1.463, -0.32, -3.304, 0.64, -0.768, -3.247, -2.14, -0.026, -3.587], 
      "ysrc": "harry11733:104:8482f5", 
      "y": [0.142, 1.561, -2.243, -0.785, -3.162, 1.71, 1.397, 0.681, 0.06, 0.637, -1.289, -2.586, 3.177, -3.555, -3.041, -0.173, -0.469, 1.416, -0.516, -2.888, -1.508, 1.025, -0.756, -2.18, -0.188, -1.59, 3.501, -0.433, 3.759, -0.523, 2.292, 0.296, -2.846, 1.964, -2.988, -1.121, -3.543, -0.148, -1.239, 0.301, -0.52, 1.097, 0.746, 2.636, -0.425, -2.507, -2.278, 2.392, -0.457, -1.269]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e6016b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68], 
      "ysrc": "harry11733:104:c98754", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516]
    }
  ], 
  "name": 68, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame70 = {
  "data": [
    {
      "xsrc": "harry11733:104:e1408e", 
      "x": [-3.056, -2.874, 0.459, -3.683, 0.397, -3.58, -2.661, -1.421, -1.265, -3.027, 0.127, -2.439, -2.235, -1.648, 0.978, -3.51, 0.129, -2.918, -1.295, -2.417, 0.653, -2.624, -3.113, -1.504, -1.251, -3.329, -1.578, -3.783, -3.082, -3.352, 0.715, -3.809, -2.865, -3.546, -2.216, -3.343, -2.646, -3.38, -3.083, -3.591, 1.539, -1.333, 0.055, -3.513, 0.499, -0.712, -3.015, -2.647, 0.118, -3.121], 
      "ysrc": "harry11733:104:e5c74c", 
      "y": [0.508, 1.52, -1.972, -0.669, -3.153, 1.853, 1.356, 0.761, 0.236, 0.861, -1.11, -2.416, 3.396, -3.431, -3.341, 0.137, -0.22, 1.684, -0.319, -2.795, -1.308, 1.07, -1.119, -1.801, -0.489, -1.393, 3.074, -0.195, 3.811, -0.66, 2.051, 0.635, -2.626, 1.988, -2.548, -1.284, -3.358, -0.688, -1.72, -0.229, -0.622, 1.667, 1.14, 2.855, -0.574, -2.629, -2.425, 2.149, -0.644, -1.44]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:9854e9", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69], 
      "ysrc": "harry11733:104:2db3b8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664]
    }
  ], 
  "name": 69, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame71 = {
  "data": [
    {
      "xsrc": "harry11733:104:39434e", 
      "x": [-2.997, -2.956, 0.958, -2.721, -0.022, -3.809, -2.869, -1.315, -1.209, -2.997, 0.209, -2.062, -2.158, -2.064, 0.72, -2.897, 0.161, -2.642, -0.641, -2.576, 0.265, -2.611, -3.219, -1.649, -1.113, -3.444, -1.646, -3.495, -3.353, -3.464, 0.372, -3.255, -3.018, -2.864, -2.173, -3.783, -2.733, -3.682, -2.986, -3.468, 1.886, -1.128, -0.212, -3.437, 0.393, -1.394, -2.955, -2.523, 0.006, -3.396], 
      "ysrc": "harry11733:104:0fdb40", 
      "y": [0.251, 2.221, -1.977, -0.551, -3.293, 2.096, 1.176, 0.341, 0.692, 1.265, -0.934, -2.279, 2.93, -3.545, -3.842, -0.357, 0.132, 1.317, -0.322, -2.29, -0.954, 1.038, -0.983, -1.708, -0.446, -1.553, 3.339, -0.293, 3.57, -0.893, 1.878, 0.624, -2.912, 2.167, -2.212, -1.596, -2.932, -0.886, -2.117, -0.182, -1.273, 2.191, 0.982, 2.931, -0.746, -3.001, -2.303, 2.057, -0.597, -1.558]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:70b618", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70], 
      "ysrc": "harry11733:104:211edd", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776]
    }
  ], 
  "name": 70, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame72 = {
  "data": [
    {
      "xsrc": "harry11733:104:2357f0", 
      "x": [-1.936, -2.497, 1.303, -2.742, 0.26, -3.56, -2.686, -1.564, -1.182, -3.046, 0.622, -2.031, -2.119, -2.047, 0.836, -2.886, -0.322, -2.061, -0.583, -2.495, 0.825, -3.16, -3.314, -1.17, -1.043, -3.154, -1.503, -3.666, -2.684, -3.689, 1.01, -3.769, -3.14, -2.63, -1.755, -3.599, -2.392, -3.629, -2.763, -3.547, 1.785, -1.0, -0.623, -3.624, 0.416, -1.504, -3.197, -2.453, 0.177, -3.408], 
      "ysrc": "harry11733:104:834bd0", 
      "y": [0.198, 2.55, -1.73, 0.03, -3.279, 2.28, 0.931, 0.842, 0.592, 1.391, -0.884, -2.306, 3.012, -3.594, -3.86, -0.187, 0.197, 1.225, -0.664, -2.341, -0.967, 1.115, -0.79, -1.744, -0.644, -1.808, 3.073, -0.321, 3.756, -0.912, 1.734, 0.161, -2.899, 2.083, -2.084, -1.867, -2.731, -0.853, -1.7, -0.151, -1.159, 2.747, 0.727, 2.807, -0.62, -3.14, -2.528, 2.463, -0.799, -1.852]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ba219b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71], 
      "ysrc": "harry11733:104:6c1b90", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872]
    }
  ], 
  "name": 71, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame73 = {
  "data": [
    {
      "xsrc": "harry11733:104:1da293", 
      "x": [-1.797, -2.486, 1.584, -2.503, 0.061, -3.809, -2.723, -1.459, -1.031, -3.119, 0.093, -2.21, -2.421, -2.217, 1.552, -3.284, -0.528, -2.458, 0.073, -2.366, 0.429, -3.44, -3.65, -1.292, -0.799, -3.048, -1.629, -3.791, -2.539, -3.524, 0.267, -3.277, -3.073, -2.941, -1.606, -3.264, -2.332, -3.319, -2.939, -3.32, 1.046, -0.851, 0.015, -3.785, 0.366, -1.03, -2.865, -2.21, 0.633, -3.722], 
      "ysrc": "harry11733:104:4e543b", 
      "y": [0.09, 2.459, -1.179, 0.56, -2.968, 2.702, 1.132, 0.987, 0.538, 1.39, -0.857, -2.091, 2.986, -3.53, -3.675, -0.332, 0.307, 1.646, -0.525, -2.457, -1.417, 1.787, -0.755, -1.69, -1.034, -2.045, 2.809, -0.775, 3.492, -0.668, 1.382, -0.025, -3.093, 1.828, -2.346, -1.44, -2.792, -0.641, -1.784, -0.218, -1.456, 2.167, 0.776, 2.655, -0.165, -3.231, -2.661, 1.985, -0.761, -1.654]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:534ed0", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72], 
      "ysrc": "harry11733:104:1933fe", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904]
    }
  ], 
  "name": 72, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame74 = {
  "data": [
    {
      "xsrc": "harry11733:104:25070e", 
      "x": [-2.092, -2.466, 2.314, -1.897, -0.155, -3.648, -2.59, -1.909, -0.652, -3.442, 0.141, -2.09, -1.935, -1.995, 1.341, -3.425, -1.022, -2.692, 0.273, -2.336, 0.853, -3.643, -3.511, -0.813, -0.538, -2.672, -1.536, -3.626, -2.695, -3.782, 0.628, -2.942, -3.251, -3.021, -1.44, -3.523, -2.366, -3.046, -3.227, -3.157, 0.677, -0.627, -0.296, -3.847, 0.482, -0.995, -2.693, -2.129, 0.639, -3.551], 
      "ysrc": "harry11733:104:1f4ef3", 
      "y": [0.435, 1.978, -1.371, 0.01, -3.104, 2.955, 1.353, 0.934, 0.278, 0.985, -0.912, -2.229, 2.783, -3.314, -3.551, -0.391, 0.277, 1.639, -0.933, -2.575, -1.048, 1.714, -1.266, -3.009, -1.562, -2.293, 3.047, -0.211, 3.781, -0.528, 1.196, -0.015, -3.446, 1.95, -2.767, -1.715, -3.062, -0.274, -1.875, 0.124, -1.221, 2.278, 0.428, 2.226, -0.352, -3.287, -2.211, 2.225, -0.722, -1.202]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c40a72", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73], 
      "ysrc": "harry11733:104:c347af", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976]
    }
  ], 
  "name": 73, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame75 = {
  "data": [
    {
      "xsrc": "harry11733:104:c01aea", 
      "x": [-2.072, -2.624, 2.094, -1.721, -0.149, -3.356, -2.756, -1.684, -0.689, -3.851, 0.399, -1.946, -1.941, -1.366, 1.219, -2.917, -1.314, -3.075, 0.279, -2.692, 0.729, -3.294, -3.057, -1.375, -0.507, -2.447, -1.501, -3.591, -2.325, -3.611, 0.383, -2.423, -3.151, -3.094, -1.498, -3.379, -2.299, -3.021, -3.561, -2.777, 0.893, -0.875, -0.231, -2.979, 0.045, -1.187, -3.025, -2.345, 1.112, -3.516], 
      "ysrc": "harry11733:104:0e8aa0", 
      "y": [0.38, 1.905, -1.457, -0.229, -2.721, 3.086, 1.697, 1.057, 0.273, 0.624, -0.521, -2.666, 2.266, -3.058, -3.544, -0.628, -0.046, 1.565, -0.704, -2.143, -1.075, 1.957, -1.421, -3.102, -1.63, -2.17, 3.34, -0.061, 3.833, -1.076, 1.277, -0.173, -3.795, 2.061, -2.976, -1.251, -3.8, -0.081, -1.761, 0.184, -0.967, 2.36, 0.319, 2.066, -0.593, -2.787, -2.232, 2.306, -1.045, -1.093]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e30049", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74], 
      "ysrc": "harry11733:104:a50cc9", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072]
    }
  ], 
  "name": 74, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame76 = {
  "data": [
    {
      "xsrc": "harry11733:104:fad880", 
      "x": [-1.527, -2.418, 1.668, -1.747, -0.113, -3.168, -3.154, -1.846, -0.929, -3.719, 0.328, -2.151, -1.854, -0.845, 1.378, -2.81, -0.846, -2.61, -0.205, -2.941, 0.095, -3.063, -2.89, -1.705, -0.424, -2.44, -1.504, -2.844, -2.57, -3.842, 0.533, -2.383, -3.194, -2.954, -2.229, -3.545, -2.814, -2.816, -3.44, -2.669, 1.191, -0.512, -0.164, -3.071, -0.13, -1.323, -3.624, -2.162, 1.157, -3.62], 
      "ysrc": "harry11733:104:4759bd", 
      "y": [0.672, 2.125, -1.162, -0.195, -2.592, 3.841, 1.639, 0.755, 0.398, 1.091, -0.653, -3.132, 2.102, -3.168, -3.426, -0.705, -0.269, 1.901, -0.535, -2.205, -0.912, 2.261, -2.053, -2.914, -1.601, -2.048, 3.569, -0.001, 3.848, -0.419, 1.311, -0.041, -3.508, 1.767, -3.12, -1.166, -3.742, -0.207, -1.609, 0.489, -1.269, 2.017, 0.404, 2.252, -0.736, -2.529, -2.353, 2.316, -1.06, -1.007]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:63a48f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75], 
      "ysrc": "harry11733:104:f9e914", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072]
    }
  ], 
  "name": 75, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame77 = {
  "data": [
    {
      "xsrc": "harry11733:104:72f7bc", 
      "x": [-1.547, -1.881, 1.889, -2.103, -0.081, -3.126, -3.382, -1.746, -0.843, -3.758, 0.029, -2.329, -1.342, -1.318, 1.016, -3.206, -0.846, -2.868, -0.565, -2.828, 0.068, -3.054, -2.861, -2.124, -0.477, -2.055, -1.015, -3.006, -3.091, -3.771, 0.173, -1.926, -3.269, -3.19, -2.419, -3.767, -2.823, -2.959, -2.901, -2.847, 1.215, -0.311, -0.37, -3.105, -0.0, -0.918, -3.302, -2.502, 1.345, -3.805], 
      "ysrc": "harry11733:104:c1197a", 
      "y": [0.567, 1.794, -1.224, -0.343, -2.81, 3.676, 1.79, 1.045, 0.629, 1.575, -0.612, -3.358, 2.323, -3.531, -3.491, -0.663, -0.471, 1.658, -1.354, -1.517, -0.874, 2.261, -2.11, -2.428, -1.403, -2.096, 3.644, 0.592, 3.845, -0.645, 1.546, 0.114, -3.259, 1.249, -2.988, -0.959, -3.692, -0.368, -1.389, 0.058, -1.118, 1.818, 0.208, 2.369, -0.296, -2.651, -2.328, 2.545, -0.853, -1.025]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:5d16bf", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76], 
      "ysrc": "harry11733:104:a61bbe", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136]
    }
  ], 
  "name": 76, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame78 = {
  "data": [
    {
      "xsrc": "harry11733:104:3063d5", 
      "x": [-1.643, -1.876, 1.879, -2.379, -0.395, -3.731, -3.466, -1.935, -0.814, -3.478, 0.452, -2.287, -1.639, -0.789, 0.691, -3.442, -1.286, -3.782, -1.023, -2.628, -0.129, -3.22, -2.69, -1.87, -0.476, -2.22, -0.967, -2.686, -3.106, -3.11, 0.279, -1.793, -3.458, -3.229, -2.746, -3.702, -2.908, -2.632, -3.082, -2.961, 1.057, -0.068, -0.658, -2.748, 0.067, -0.53, -3.176, -2.337, 1.163, -3.584], 
      "ysrc": "harry11733:104:9118b1", 
      "y": [0.77, 1.95, -1.103, -0.553, -3.072, 3.501, 1.779, 0.715, 0.781, 1.191, 0.007, -3.563, 2.307, -3.352, -3.127, -1.295, -0.281, 1.379, -1.309, -1.847, -0.932, 2.546, -2.623, -2.482, -1.556, -2.208, 3.86, 0.665, 3.371, -0.254, 1.477, 0.316, -3.319, 1.252, -2.806, -0.915, -3.495, -0.525, -0.935, 0.654, -1.465, 1.562, 0.234, 2.431, 0.424, -2.588, -2.289, 2.753, -0.297, -0.384]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:594358", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77], 
      "ysrc": "harry11733:104:997d73", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228]
    }
  ], 
  "name": 77, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame79 = {
  "data": [
    {
      "xsrc": "harry11733:104:4773f8", 
      "x": [-1.521, -1.956, 2.155, -2.029, -0.431, -3.774, -3.48, -1.807, -0.215, -3.441, 0.433, -2.193, -1.407, -0.631, 0.456, -3.773, -1.302, -3.753, -0.741, -3.101, -0.309, -3.302, -2.438, -1.5, -0.41, -2.321, -0.989, -2.608, -3.12, -3.321, 0.705, -1.719, -3.452, -3.697, -2.527, -3.736, -2.524, -2.896, -2.87, -3.083, 1.419, 0.122, -0.459, -2.784, 0.063, -0.482, -3.125, -2.496, 0.824, -3.786], 
      "ysrc": "harry11733:104:8f3441", 
      "y": [1.003, 1.252, -1.194, -0.6, -3.172, 3.635, 1.494, 0.932, 0.542, 1.667, -0.631, -3.746, 2.245, -3.856, -2.837, -1.413, -0.369, 1.565, -1.534, -1.766, -1.252, 2.711, -2.292, -2.538, -2.11, -2.226, 3.774, 0.543, 3.078, -0.311, 1.884, 0.168, -3.2, 0.98, -2.782, -1.164, -3.047, -0.922, -0.478, 0.529, -1.504, 1.234, -0.019, 2.392, 0.253, -2.036, -1.914, 2.885, -0.141, -0.678]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:2baaa2", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78], 
      "ysrc": "harry11733:104:699d64", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324]
    }
  ], 
  "name": 78, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame80 = {
  "data": [
    {
      "xsrc": "harry11733:104:35a0a7", 
      "x": [-1.233, -1.939, 2.045, -2.242, -0.215, -3.523, -3.432, -1.742, -0.289, -2.924, 0.284, -2.668, -1.584, -0.519, 0.14, -3.7, -1.67, -3.788, -0.286, -3.258, -0.754, -3.174, -2.257, -0.949, -0.315, -2.486, -0.881, -2.225, -2.733, -3.612, 0.779, -1.638, -3.512, -3.767, -2.116, -3.626, -2.589, -3.038, -2.65, -3.674, 1.596, -0.836, -0.345, -2.937, 0.08, -0.219, -3.298, -2.557, 0.161, -3.76], 
      "ysrc": "harry11733:104:bcc14a", 
      "y": [0.697, 1.106, -0.875, 0.11, -3.201, 3.715, 1.711, 0.954, 0.217, 1.488, -0.635, -3.469, 2.24, -3.798, -3.01, -1.852, -0.548, 1.418, -1.683, -2.18, -0.757, 3.315, -2.552, -2.518, -1.501, -2.22, 3.609, 0.429, 3.264, -0.877, 1.86, 0.357, -3.665, 0.137, -2.93, -1.721, -3.073, -0.569, -0.178, 1.32, -1.612, 1.229, 0.435, 2.207, 0.533, -2.04, -2.13, 3.278, 0.113, 0.286]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4c8599", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79], 
      "ysrc": "harry11733:104:9dd7db", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424]
    }
  ], 
  "name": 79, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame81 = {
  "data": [
    {
      "xsrc": "harry11733:104:6d67dc", 
      "x": [-1.238, -1.92, 2.252, -2.357, -0.071, -3.144, -3.592, -1.863, -0.714, -2.84, 0.553, -2.9, -1.655, -0.474, 0.111, -3.354, -0.883, -3.834, -0.402, -3.527, -0.315, -2.89, -2.414, -0.9, -0.749, -2.505, -0.153, -2.496, -3.123, -3.835, 1.439, -1.748, -2.838, -3.567, -2.279, -3.744, -2.527, -3.288, -2.468, -3.058, 1.597, -0.826, -0.801, -2.615, 0.009, -0.096, -3.056, -1.672, 0.372, -3.686], 
      "ysrc": "harry11733:104:65faa2", 
      "y": [0.776, 1.124, -0.872, 0.194, -3.138, 3.778, 1.694, 0.598, 0.616, 1.243, -0.402, -3.219, 2.586, -3.448, -3.133, -2.073, -0.579, 1.573, -2.1, -2.05, -0.961, 3.257, -2.418, -2.503, -1.51, -2.153, 3.56, 0.438, 2.794, -0.89, 1.516, 0.646, -3.741, -0.529, -2.825, -1.885, -2.491, 0.032, -0.011, 1.202, -1.65, 1.017, 0.548, 1.432, 0.439, -1.838, -1.947, 2.822, -0.381, -0.034]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:11be89", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80], 
      "ysrc": "harry11733:104:4996b8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376]
    }
  ], 
  "name": 80, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame82 = {
  "data": [
    {
      "xsrc": "harry11733:104:c29cbe", 
      "x": [-1.522, -1.894, 2.657, -2.561, -0.017, -2.857, -3.842, -1.29, -1.015, -2.461, -0.184, -2.515, -1.421, -0.474, 0.416, -3.696, -0.49, -3.695, -0.335, -3.587, -0.253, -2.641, -2.481, -1.171, -1.002, -2.528, -0.484, -2.092, -3.324, -3.695, 1.169, -1.7, -2.991, -2.915, -2.002, -3.81, -2.472, -3.419, -2.325, -2.947, 1.423, -1.09, -1.281, -2.683, -0.112, 0.441, -3.139, -1.258, 0.161, -3.371], 
      "ysrc": "harry11733:104:b10243", 
      "y": [0.31, 1.024, -0.869, 0.112, -2.749, 3.714, 1.513, 0.739, 0.876, 1.222, -0.077, -3.515, 2.91, -3.36, -3.467, -1.497, -1.112, 1.741, -2.412, -2.177, -0.594, 2.775, -2.602, -3.115, -1.55, -1.921, 3.141, 0.018, 2.956, -0.808, 1.361, 0.696, -3.688, -0.261, -3.08, -1.843, -2.053, 0.478, 0.43, 0.872, -1.895, 1.024, 0.33, 1.332, 0.159, -1.507, -2.131, 2.869, 0.084, -0.514]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:7c266f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81], 
      "ysrc": "harry11733:104:1f21e2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464]
    }
  ], 
  "name": 81, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame83 = {
  "data": [
    {
      "xsrc": "harry11733:104:20d618", 
      "x": [-2.033, -1.758, 2.572, -3.2, 0.298, -3.352, -3.798, -1.265, -0.859, -2.485, -0.053, -2.195, -1.516, -0.38, 0.533, -3.558, -0.352, -3.606, 0.42, -3.481, -0.276, -2.278, -2.224, -1.448, -1.38, -1.897, -0.606, -1.827, -3.102, -3.809, 0.842, -1.476, -2.985, -2.763, -2.035, -3.77, -2.725, -3.376, -2.546, -2.621, 1.863, -1.108, -1.378, -3.298, -1.009, 0.514, -3.049, -1.272, 0.021, -3.222], 
      "ysrc": "harry11733:104:649f1a", 
      "y": [0.162, 1.349, -0.406, 0.354, -2.806, 3.403, 1.275, 0.936, 1.42, 1.573, -0.019, -3.318, 2.739, -2.847, -3.769, -0.938, -1.131, 2.012, -2.299, -1.712, -0.345, 2.662, -1.85, -3.036, -1.593, -1.761, 3.32, 0.341, 2.703, -1.385, 1.644, 1.23, -3.677, -0.5, -3.203, -1.789, -2.325, 0.403, 0.919, 1.319, -1.671, 0.405, 0.593, 1.487, 0.206, -1.822, -1.854, 2.495, 0.467, -0.288]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:34b9b6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82], 
      "ysrc": "harry11733:104:739e65", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488]
    }
  ], 
  "name": 82, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame84 = {
  "data": [
    {
      "xsrc": "harry11733:104:2d9a78", 
      "x": [-1.909, -1.527, 2.354, -3.342, 0.58, -3.618, -3.355, -1.049, -1.401, -2.124, -0.174, -2.399, -1.802, -0.759, 0.383, -3.48, 0.009, -3.612, -0.221, -3.188, -1.108, -2.19, -2.624, -1.592, -1.748, -1.755, -0.364, -2.091, -2.719, -3.604, 0.692, -1.691, -2.709, -2.721, -1.78, -3.758, -2.824, -3.816, -2.287, -2.733, 1.945, -1.012, -1.266, -2.87, -0.814, 0.776, -2.954, -1.473, 0.32, -2.522], 
      "ysrc": "harry11733:104:a8a4a4", 
      "y": [0.14, 1.442, -0.665, 0.592, -3.313, 3.778, 0.7, 1.667, 1.485, 1.521, -0.191, -3.06, 2.585, -2.977, -3.849, -0.656, -1.009, 1.741, -2.573, -1.62, 0.035, 2.638, -2.002, -3.148, -1.129, -1.566, 3.038, 0.756, 2.847, -1.413, 1.587, 1.261, -3.27, -0.022, -2.986, -1.881, -2.305, 0.466, 1.222, 1.078, -2.1, 1.101, 0.46, 1.394, 0.027, -1.292, -1.745, 2.496, 0.056, -0.094]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e760f3", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83], 
      "ysrc": "harry11733:104:711996", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364]
    }
  ], 
  "name": 83, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame85 = {
  "data": [
    {
      "xsrc": "harry11733:104:c6aa7a", 
      "x": [-2.665, -1.51, 2.179, -3.681, 0.696, -3.805, -3.113, -0.921, -1.461, -1.619, -0.507, -2.438, -1.616, -1.234, 0.66, -2.476, 0.336, -3.604, -0.113, -3.584, -0.68, -1.995, -2.73, -0.907, -1.321, -1.59, -0.458, -1.741, -2.041, -3.133, 0.196, -1.755, -2.825, -2.866, -2.193, -3.308, -2.655, -3.805, -2.585, -3.19, 1.717, -1.093, -1.642, -3.226, -0.745, 0.525, -2.857, -1.207, 0.269, -2.797], 
      "ysrc": "harry11733:104:19df0b", 
      "y": [0.072, 1.248, -1.039, 0.677, -3.09, 3.497, 1.26, 1.553, 1.567, 1.626, -0.44, -2.819, 2.702, -2.75, -3.819, -0.622, -0.721, 1.609, -2.568, -1.259, -0.283, 2.397, -1.651, -2.994, -1.199, -2.067, 3.177, 0.476, 2.723, -1.438, 1.607, 0.949, -3.142, 0.17, -2.914, -1.964, -1.852, 0.201, 0.879, 1.176, -1.964, 1.26, 0.331, 1.45, 0.471, -1.716, -2.086, 2.406, 0.207, -0.268]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0eb8e8", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84], 
      "ysrc": "harry11733:104:2e3b2a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648]
    }
  ], 
  "name": 84, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame86 = {
  "data": [
    {
      "xsrc": "harry11733:104:3dc2e4", 
      "x": [-2.752, -1.194, 2.039, -3.739, 0.928, -3.865, -2.767, -0.738, -1.275, -1.82, 0.015, -2.369, -2.071, -1.632, 0.94, -2.362, 0.562, -3.725, 0.526, -3.765, -0.784, -1.967, -2.745, -0.837, -1.306, -1.142, -0.053, -1.818, -2.168, -2.78, 0.576, -1.201, -2.695, -2.497, -2.744, -3.635, -2.86, -3.619, -3.335, -3.251, 1.845, -1.182, -1.452, -3.334, -0.667, 0.58, -3.517, -1.272, 0.896, -2.377], 
      "ysrc": "harry11733:104:717cb3", 
      "y": [-0.428, 1.28, -2.035, 0.722, -3.853, 3.752, 1.34, 1.645, 1.541, 1.419, -0.491, -2.394, 3.098, -2.533, -3.0, -0.642, -0.744, 1.651, -2.259, -1.017, -0.077, 2.801, -1.525, -3.02, -1.187, -2.219, 3.358, 0.746, 2.636, -1.542, 1.597, 1.068, -3.247, -0.313, -2.704, -1.438, -1.973, -0.268, 0.46, 1.097, -1.607, 1.825, 0.413, 1.099, 0.568, -1.626, -1.85, 2.976, 0.511, -0.127]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a7219a", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85], 
      "ysrc": "harry11733:104:503861", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772]
    }
  ], 
  "name": 85, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame87 = {
  "data": [
    {
      "xsrc": "harry11733:104:fc3748", 
      "x": [-2.833, -1.373, 2.108, -3.771, 0.821, -3.39, -2.862, -0.677, -1.203, -1.702, -0.053, -1.968, -1.941, -1.682, 0.953, -2.134, 0.353, -3.829, 0.222, -3.497, -0.609, -1.654, -2.1, -0.359, -1.154, -0.838, 0.138, -2.175, -1.966, -2.665, 1.041, -1.167, -2.947, -2.436, -2.67, -3.661, -2.385, -3.715, -3.68, -3.037, 2.15, -1.992, -1.108, -3.307, -0.961, 0.696, -3.77, -1.469, 1.016, -2.155], 
      "ysrc": "harry11733:104:9cb47a", 
      "y": [-0.362, 0.918, -2.214, 0.489, -3.482, 3.861, 1.515, 1.683, 1.822, 1.714, -0.656, -2.779, 2.806, -2.191, -3.255, -0.993, -0.5, 1.698, -2.075, -0.771, -0.046, 2.911, -1.584, -2.936, -0.924, -2.268, 3.446, 0.7, 2.796, -1.256, 1.605, 1.111, -3.5, -0.108, -2.264, -1.556, -1.963, -0.42, 0.109, 1.341, -1.35, 1.819, 0.199, 1.232, 0.83, -1.593, -2.482, 2.966, 0.25, 0.145]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:dd2f3e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86], 
      "ysrc": "harry11733:104:558457", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744]
    }
  ], 
  "name": 86, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame88 = {
  "data": [
    {
      "xsrc": "harry11733:104:506d50", 
      "x": [-3.051, -1.87, 2.073, -3.627, 1.046, -3.79, -2.718, -0.838, -1.263, -1.869, 0.117, -2.125, -1.528, -1.399, 1.677, -1.844, -0.611, -3.84, 0.485, -3.636, -0.425, -1.917, -2.218, -0.369, -1.064, -0.626, 0.344, -1.822, -1.559, -2.188, 0.537, -0.751, -2.703, -3.058, -2.331, -3.458, -2.631, -3.182, -3.642, -3.081, 1.938, -2.23, -1.205, -3.116, -1.141, 1.248, -3.809, -1.406, 0.674, -1.877], 
      "ysrc": "harry11733:104:190225", 
      "y": [-0.6, 0.982, -1.771, 0.414, -2.922, 3.448, 1.394, 1.88, 1.508, 1.625, -0.758, -2.652, 1.946, -2.016, -2.852, -1.349, -0.207, 1.436, -2.214, -0.923, -0.119, 3.256, -1.37, -2.64, -0.708, -2.764, 3.258, -0.121, 2.566, -1.237, 1.725, 1.163, -2.926, -0.228, -2.223, -1.52, -1.61, 0.036, 0.148, 1.92, -1.139, 1.883, 0.35, 1.478, 1.372, -1.659, -2.994, 3.44, -0.107, 0.899]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:981c4b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87], 
      "ysrc": "harry11733:104:d240eb", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792]
    }
  ], 
  "name": 87, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame89 = {
  "data": [
    {
      "xsrc": "harry11733:104:c199d8", 
      "x": [-3.224, -2.28, 1.774, -2.997, 0.896, -3.736, -2.37, -1.174, -1.072, -2.083, 0.224, -1.973, -1.352, -1.217, 2.008, -1.805, -0.706, -3.8, 0.541, -3.622, -1.153, -2.113, -2.44, -0.53, -1.072, -1.113, -0.278, -1.642, -1.687, -2.292, 0.224, -0.834, -2.566, -2.753, -2.78, -3.619, -3.193, -3.369, -3.553, -3.709, 1.391, -2.778, -1.239, -3.164, -1.436, 0.746, -3.724, -1.367, 0.726, -2.209], 
      "ysrc": "harry11733:104:767a4e", 
      "y": [-0.828, 0.832, -2.242, 0.541, -2.886, 2.813, 1.467, 1.645, 1.599, 1.334, -0.861, -2.139, 1.541, -2.228, -2.489, -0.958, -0.078, 1.693, -2.427, -0.713, -0.378, 3.429, -1.281, -2.614, -0.389, -2.917, 3.515, 0.1, 2.319, -0.991, 1.532, 1.348, -3.62, -0.766, -2.152, -1.274, -1.692, -0.626, -0.114, 1.939, -1.148, 1.815, 0.369, 0.94, 1.172, -1.369, -3.165, 3.637, 0.123, 1.342]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:732394", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88], 
      "ysrc": "harry11733:104:bd3f87", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828]
    }
  ], 
  "name": 88, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame90 = {
  "data": [
    {
      "xsrc": "harry11733:104:792b8c", 
      "x": [-2.803, -1.954, 1.857, -3.064, 0.874, -3.645, -2.657, -0.761, -0.568, -2.234, 0.131, -2.204, -1.086, -0.859, 2.535, -1.438, -0.365, -3.377, 0.796, -3.714, -0.815, -1.92, -2.079, -0.414, -1.317, -1.518, -0.375, -1.319, -2.046, -1.546, 0.182, -0.659, -2.019, -2.844, -3.072, -3.815, -3.29, -3.572, -3.486, -3.733, 1.27, -2.772, -1.42, -2.799, -1.538, 0.586, -3.776, -0.848, 0.524, -1.726], 
      "ysrc": "harry11733:104:374e12", 
      "y": [-0.693, 0.624, -2.136, 0.646, -2.659, 2.731, 1.273, 1.559, 1.762, 1.055, -0.827, -2.316, 1.272, -2.171, -2.733, -0.821, 0.018, 1.666, -2.692, -0.388, -0.757, 3.734, -1.701, -2.599, -0.432, -3.081, 3.645, 0.401, 1.914, -0.643, 1.573, 1.24, -3.507, -1.398, -2.238, -0.88, -1.867, -0.501, -0.356, 1.668, -1.364, 1.86, 0.328, 1.243, 1.212, -1.318, -2.799, 2.775, 0.387, 1.059]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e414fd", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89], 
      "ysrc": "harry11733:104:f9f8b6", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386]
    }
  ], 
  "name": 89, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame91 = {
  "data": [
    {
      "xsrc": "harry11733:104:935c13", 
      "x": [-2.802, -1.868, 1.688, -3.564, 1.22, -3.645, -3.178, -0.832, -0.042, -2.349, 0.314, -2.397, -1.01, -1.262, 2.504, -1.072, -0.392, -3.231, 0.598, -3.764, -0.671, -2.145, -1.776, -0.506, -1.147, -1.789, -0.57, -1.453, -1.867, -1.352, 0.219, -0.581, -1.988, -2.499, -2.709, -3.582, -2.715, -3.175, -3.563, -3.809, 1.448, -2.518, -1.627, -2.695, -1.389, 0.497, -3.587, -1.026, 0.401, -1.789], 
      "ysrc": "harry11733:104:6a7003", 
      "y": [-0.835, 0.497, -2.305, 0.317, -2.675, 2.588, 1.566, 1.681, 1.217, 1.251, -0.738, -2.271, 1.428, -2.254, -2.672, -0.867, -1.051, 1.714, -2.47, -0.3, -1.166, 3.033, -1.631, -2.616, -0.533, -2.982, 3.36, 0.425, 1.603, -0.488, 1.905, 0.825, -3.861, -0.843, -2.084, -0.956, -2.02, -0.754, -0.12, 1.309, -1.485, 2.403, 0.031, 1.23, 0.824, -1.456, -2.862, 2.92, 0.558, 1.352]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c29acc", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90], 
      "ysrc": "harry11733:104:6e88b1", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884]
    }
  ], 
  "name": 90, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame92 = {
  "data": [
    {
      "xsrc": "harry11733:104:14206b", 
      "x": [-3.102, -1.604, 1.828, -3.463, 1.513, -3.766, -3.124, -0.5, -0.253, -2.179, 0.353, -2.716, -1.181, -1.686, 2.917, -1.349, -0.389, -3.369, 0.472, -3.807, -0.811, -2.428, -1.868, -0.258, -0.995, -1.861, -0.585, -2.12, -1.493, -1.63, 0.337, -0.906, -1.529, -2.349, -2.582, -3.348, -3.024, -3.213, -3.675, -3.818, 1.182, -2.194, -1.446, -3.084, -1.213, 0.801, -3.408, -0.919, -0.149, -2.038], 
      "ysrc": "harry11733:104:49aad9", 
      "y": [-0.88, 0.363, -2.278, 0.274, -3.025, 2.764, 1.755, 2.118, 1.029, 1.451, -0.642, -2.252, 1.099, -2.023, -2.389, -0.71, -0.806, 1.417, -2.38, -0.402, -1.131, 3.18, -1.438, -2.338, -0.425, -2.585, 3.218, 0.388, 0.704, -0.02, 1.549, 0.617, -3.605, -1.019, -1.61, -0.582, -1.817, -1.064, 0.009, 1.268, -1.305, 2.355, 0.299, 1.084, 1.461, -1.232, -2.673, 2.863, 0.621, 1.217]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c651c5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91], 
      "ysrc": "harry11733:104:741a47", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948]
    }
  ], 
  "name": 91, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame93 = {
  "data": [
    {
      "xsrc": "harry11733:104:5d7439", 
      "x": [-2.581, -1.702, 1.903, -3.643, 1.674, -3.662, -3.464, -0.404, -0.254, -2.055, 0.405, -3.137, -0.977, -1.235, 3.266, -1.535, -0.535, -3.156, 0.62, -3.818, -0.967, -2.854, -1.815, -0.389, -1.07, -2.224, -0.463, -2.022, -1.394, -1.45, 0.633, -0.725, -1.597, -2.731, -2.453, -3.628, -3.16, -3.147, -3.773, -3.514, 1.495, -2.768, -1.635, -3.0, -1.957, 0.758, -3.769, -0.717, -0.831, -1.493], 
      "ysrc": "harry11733:104:5d2488", 
      "y": [-1.165, -0.009, -2.374, 0.044, -3.166, 2.521, 1.432, 2.046, 1.172, 1.524, -0.288, -2.049, 0.959, -2.041, -2.921, -0.336, -0.929, 1.99, -2.14, -0.379, -0.972, 3.338, -1.859, -2.684, -0.615, -2.445, 3.291, 0.531, 0.294, -0.342, 1.865, 0.641, -3.848, -1.067, -1.968, -0.639, -1.617, -1.104, 0.499, 1.189, -0.794, 1.925, -0.07, 1.055, 1.714, -1.046, -2.632, 3.065, 0.809, 1.368]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0b1cd7", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92], 
      "ysrc": "harry11733:104:cb89d1", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004]
    }
  ], 
  "name": 92, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame94 = {
  "data": [
    {
      "xsrc": "harry11733:104:3f42ed", 
      "x": [-2.485, -1.161, 2.014, -3.745, 1.886, -3.796, -3.824, 0.27, -0.353, -2.003, 0.961, -3.145, -0.768, -1.674, 3.771, -1.725, -0.706, -2.729, 0.693, -3.74, -1.06, -2.76, -1.486, -0.039, -0.975, -2.515, 0.012, -1.634, -1.947, -1.005, 0.554, -0.205, -1.414, -2.78, -3.011, -3.459, -3.637, -2.769, -3.777, -3.706, 2.075, -2.654, -1.446, -2.952, -2.01, 0.709, -3.777, -1.043, -0.559, -0.801], 
      "ysrc": "harry11733:104:f15c4b", 
      "y": [-0.81, -0.067, -1.763, 0.549, -3.164, 2.938, 1.56, 2.273, 0.954, 1.181, -0.246, -1.778, 1.075, -1.737, -2.687, -0.44, -1.348, 2.027, -2.43, -0.331, -1.574, 3.349, -1.631, -2.998, -0.638, -2.543, 2.802, 0.929, -0.569, -0.249, 1.912, 1.207, -3.252, -0.785, -1.717, -0.996, -1.203, -0.96, 0.102, 1.193, -0.664, 1.838, 0.075, 1.118, 2.176, -1.38, -2.539, 3.618, 0.749, 1.01]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:5a2f1a", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93], 
      "ysrc": "harry11733:104:dcd560", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402]
    }
  ], 
  "name": 93, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame95 = {
  "data": [
    {
      "xsrc": "harry11733:104:af84da", 
      "x": [-2.498, -1.176, 1.633, -3.555, 1.787, -3.861, -3.499, 0.116, -0.542, -2.249, 0.899, -2.965, -0.476, -1.027, 3.291, -2.191, -1.075, -2.713, 0.395, -3.762, -1.031, -2.66, -1.323, -0.067, -0.966, -2.252, -0.38, -1.8, -1.569, -1.762, 0.479, -0.074, -1.046, -2.859, -3.468, -3.477, -3.262, -2.84, -3.043, -3.588, 1.729, -2.919, -0.634, -2.711, -1.621, 0.863, -3.38, -0.638, -0.669, -0.716], 
      "ysrc": "harry11733:104:2dc0c4", 
      "y": [-0.936, -0.129, -1.751, 0.585, -3.62, 2.956, 1.225, 2.392, 0.986, 1.261, -0.323, -1.55, 1.257, -1.778, -2.901, -0.621, -1.277, 2.201, -2.288, 0.245, -1.809, 3.34, -1.39, -2.742, -0.876, -2.66, 3.157, 1.399, -0.879, 0.355, 1.556, 0.957, -3.258, -0.135, -2.079, -0.873, -1.747, -0.766, -0.115, 1.278, -0.873, 1.787, -0.127, 1.089, 1.86, -0.9, -2.865, 3.778, 0.251, 0.491]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c1f133", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94], 
      "ysrc": "harry11733:104:ffa768", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988]
    }
  ], 
  "name": 94, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame96 = {
  "data": [
    {
      "xsrc": "harry11733:104:917c2d", 
      "x": [-2.295, -0.597, 1.514, -3.556, 1.731, -3.844, -3.407, 0.068, -0.982, -2.291, 0.702, -3.022, -0.312, -0.676, 3.777, -2.166, -1.292, -2.887, 0.527, -3.75, -1.078, -2.748, -0.901, -0.114, -1.492, -2.165, -0.36, -1.783, -1.488, -2.457, 0.413, 0.057, -1.004, -3.114, -3.855, -3.33, -2.816, -3.281, -2.805, -3.715, 1.64, -3.216, -0.329, -2.878, -2.076, 0.543, -3.313, -0.902, 0.005, -0.972], 
      "ysrc": "harry11733:104:46f304", 
      "y": [-0.991, -0.059, -1.569, 0.768, -3.749, 2.548, 1.502, 2.571, 1.341, 1.906, -0.938, -1.227, 1.54, -1.507, -3.017, -0.043, -0.988, 2.799, -1.821, 0.304, -1.253, 3.395, -1.225, -2.516, -1.005, -2.83, 3.007, 1.146, -1.417, -0.141, 1.511, 0.712, -2.79, -0.63, -2.283, -1.15, -1.565, -0.959, -0.439, 1.693, -1.246, 1.264, -0.346, 0.905, 2.042, -1.176, -2.791, 3.739, 0.14, 0.357]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:d25aa4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95], 
      "ysrc": "harry11733:104:951a44", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072]
    }
  ], 
  "name": 95, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame97 = {
  "data": [
    {
      "xsrc": "harry11733:104:687382", 
      "x": [-1.823, -0.846, 1.098, -3.779, 2.033, -3.501, -2.939, 0.263, -1.002, -1.56, 0.904, -2.909, 0.212, -0.818, 3.755, -2.607, -1.713, -2.843, 0.484, -3.817, -0.893, -3.125, -0.465, -0.786, -1.759, -2.016, -0.259, -2.177, -1.629, -2.847, 0.279, 0.294, -1.016, -3.291, -3.812, -3.271, -3.025, -3.157, -2.885, -3.718, 1.36, -3.469, -0.369, -2.829, -2.097, 0.699, -2.239, -0.555, -0.571, -1.678], 
      "ysrc": "harry11733:104:975174", 
      "y": [-1.006, -0.106, -1.347, 0.355, -3.449, 2.707, 1.258, 2.352, 1.668, 2.261, -0.963, -1.355, 1.432, -1.74, -3.147, -0.391, -1.347, 2.712, -1.73, 0.286, -1.27, 3.212, -0.966, -2.766, -1.554, -3.08, 3.254, 1.46, -1.503, -0.23, 1.556, 0.835, -2.579, -0.685, -2.516, -0.909, -1.314, -0.571, -0.39, 1.682, -1.279, 1.069, -0.423, 0.518, 2.532, -1.0, -2.552, 3.83, 0.059, 0.106]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:2ae3d5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96], 
      "ysrc": "harry11733:104:f0496a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104]
    }
  ], 
  "name": 96, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame98 = {
  "data": [
    {
      "xsrc": "harry11733:104:650b4c", 
      "x": [-1.629, -0.922, 1.343, -3.505, 2.202, -3.767, -2.51, 0.601, -1.443, -1.229, 0.6, -3.39, 0.574, -0.639, 3.816, -2.529, -2.037, -3.138, 1.078, -3.296, -1.438, -3.718, -0.711, -0.639, -1.328, -1.766, -0.554, -1.931, -1.036, -2.761, -0.096, -0.011, -1.319, -3.148, -3.782, -3.364, -3.058, -3.6, -2.26, -3.659, 1.214, -3.35, -0.506, -3.152, -1.907, 0.336, -2.23, -1.074, -0.698, -1.153], 
      "ysrc": "harry11733:104:42f852", 
      "y": [-0.555, 0.098, -1.193, 0.317, -3.492, 3.057, 1.334, 2.292, 1.161, 2.586, -0.468, -1.424, 1.133, -1.237, -3.698, -1.048, -1.414, 2.874, -1.779, 0.172, -0.785, 3.21, -1.121, -2.4, -1.18, -3.441, 2.948, 1.301, -1.558, 0.089, 1.288, 1.111, -3.092, -0.674, -2.24, -0.872, -1.387, -0.684, -0.261, 1.439, -1.113, 1.446, -0.709, 0.486, 2.76, -1.417, -2.18, 3.525, 0.12, -0.216]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a59838", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97], 
      "ysrc": "harry11733:104:372b7f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168]
    }
  ], 
  "name": 97, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame99 = {
  "data": [
    {
      "xsrc": "harry11733:104:f878b6", 
      "x": [-1.345, -1.158, 1.679, -3.315, 2.07, -3.816, -2.732, 0.936, -1.463, -1.525, 1.014, -3.188, 0.739, -0.671, 3.354, -2.24, -2.485, -2.703, 1.207, -3.172, -1.337, -3.764, -0.819, -0.084, -1.31, -1.472, -1.033, -2.156, -0.776, -3.476, 0.009, -0.661, -1.458, -2.944, -3.587, -3.081, -3.294, -2.983, -2.263, -3.77, 0.941, -3.489, -0.517, -2.837, -1.461, 0.75, -1.762, -1.068, -0.411, -1.358], 
      "ysrc": "harry11733:104:4a81a2", 
      "y": [-0.461, 0.068, -1.17, 0.404, -3.567, 2.835, 1.304, 1.883, 0.803, 2.924, -0.702, -0.946, 0.688, -0.612, -3.484, -1.408, -1.042, 2.461, -1.728, -0.106, -0.407, 2.891, -0.842, -2.39, -1.365, -3.408, 2.899, 1.695, -1.479, -0.181, 1.544, 0.403, -3.178, -0.207, -2.184, -0.818, -1.353, -0.788, -0.499, 1.362, -1.453, 1.279, -0.536, 0.471, 2.82, -1.414, -2.151, 3.762, -0.353, -0.513]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:af212c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98], 
      "ysrc": "harry11733:104:d37e2a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236]
    }
  ], 
  "name": 98, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame100 = {
  "data": [
    {
      "xsrc": "harry11733:104:7b584b", 
      "x": [-1.134, -1.329, 2.282, -2.901, 2.228, -3.745, -2.486, 1.419, -1.553, -1.837, 1.353, -3.212, 0.476, -0.703, 3.57, -2.286, -2.863, -2.614, 0.945, -3.31, -1.699, -3.71, -0.082, -0.125, -1.833, -1.551, -0.813, -1.842, -1.082, -3.212, -0.556, -0.378, -1.719, -2.886, -2.769, -2.908, -3.539, -3.095, -2.862, -3.257, 1.187, -3.294, -0.681, -2.955, -1.346, 1.154, -2.34, -0.936, -0.705, -1.343], 
      "ysrc": "harry11733:104:e44400", 
      "y": [-0.441, 0.321, -1.539, 0.676, -3.239, 3.204, 1.752, 1.804, 0.159, 2.609, -0.75, -1.641, 0.921, -0.055, -3.122, -1.208, -1.123, 2.806, -1.622, -0.353, -0.749, 2.754, -0.649, -2.222, -1.469, -3.334, 2.903, 1.504, -1.532, -0.377, 1.909, 0.139, -3.076, 0.107, -2.379, -0.819, -1.514, -0.785, -0.942, 1.283, -1.064, 1.493, -0.438, 0.445, 2.408, -0.402, -2.367, 3.851, 0.015, -0.796]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:13657c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99], 
      "ysrc": "harry11733:104:b9a5b7", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316]
    }
  ], 
  "name": 99, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame101 = {
  "data": [
    {
      "xsrc": "harry11733:104:4ba166", 
      "x": [-0.93, -1.237, 2.128, -3.196, 2.455, -3.551, -3.273, 1.609, -1.657, -1.489, 1.366, -3.52, 0.716, -0.765, 3.354, -2.381, -2.998, -2.505, 1.148, -2.928, -1.457, -3.831, 0.366, -0.099, -1.697, -1.686, -1.01, -1.829, -1.011, -3.289, -0.837, -0.656, -1.89, -2.969, -3.02, -3.005, -3.554, -3.665, -3.133, -3.072, 1.422, -3.295, -0.739, -3.226, -1.372, 0.602, -2.439, -1.09, -0.902, -0.926], 
      "ysrc": "harry11733:104:6255f7", 
      "y": [-0.233, 0.257, -2.099, 1.155, -3.711, 3.06, 1.419, 1.563, 0.683, 2.087, -0.854, -1.737, 1.128, -0.294, -3.487, -1.725, -0.587, 2.926, -1.846, -0.329, -0.784, 2.507, -0.913, -2.617, -1.907, -2.933, 2.674, 1.269, -0.592, -0.337, 1.814, 0.05, -2.898, 0.085, -2.255, -0.284, -0.601, -0.42, -1.776, 0.949, -1.589, 1.188, -0.522, 0.375, 2.436, -0.639, -2.666, 3.627, -0.021, -0.997]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b20232", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
      "ysrc": "harry11733:104:15cbb2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428]
    }
  ], 
  "name": 100, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame102 = {
  "data": [
    {
      "xsrc": "harry11733:104:74eab4", 
      "x": [-0.224, -1.337, 2.204, -2.916, 2.334, -3.452, -3.053, 1.968, -1.268, -1.219, 1.48, -3.061, 0.667, -0.899, 3.242, -2.242, -2.831, -2.525, 0.937, -2.973, -1.294, -3.828, 0.093, -0.541, -1.603, -1.912, -1.103, -1.577, -0.878, -2.963, -0.705, -0.891, -1.632, -2.132, -3.157, -3.484, -3.809, -3.732, -3.004, -2.664, 2.106, -3.276, -0.028, -3.029, -1.827, 0.753, -2.13, -0.911, -0.556, -1.181], 
      "ysrc": "harry11733:104:36628e", 
      "y": [-0.272, 0.08, -1.769, 0.885, -3.754, 2.821, 1.408, 1.493, 0.638, 2.129, -0.847, -1.772, 1.087, -0.303, -3.173, -1.638, -0.641, 2.802, -1.516, -0.747, -0.906, 2.304, -1.101, -2.463, -2.019, -3.359, 2.62, 1.13, -0.495, -1.082, 1.857, -0.277, -2.748, 0.035, -2.259, 0.408, -1.078, -0.522, -2.086, 0.373, -1.844, 1.268, -0.139, 0.488, 2.573, -0.535, -2.609, 3.821, 0.087, -0.603]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:126b8c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101], 
      "ysrc": "harry11733:104:f02620", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332]
    }
  ], 
  "name": 101, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame103 = {
  "data": [
    {
      "xsrc": "harry11733:104:2c2fa8", 
      "x": [-0.25, -1.511, 2.262, -3.228, 2.317, -3.356, -3.309, 1.479, -1.427, -1.386, 1.536, -3.09, 0.868, -0.833, 3.47, -2.402, -2.318, -2.212, 1.008, -2.473, -0.57, -3.608, -0.06, 0.442, -1.63, -2.151, -1.031, -1.421, -0.501, -2.884, -1.093, -0.947, -1.876, -2.382, -3.333, -3.856, -3.708, -3.421, -2.859, -2.834, 2.187, -3.429, 0.016, -2.735, -1.302, 0.428, -1.588, -1.056, -0.721, -1.622], 
      "ysrc": "harry11733:104:a4f108", 
      "y": [-0.806, 0.58, -2.461, 1.135, -3.637, 2.929, 1.331, 0.973, 0.602, 2.237, -0.683, -1.756, 0.794, -0.081, -3.328, -1.227, -0.728, 2.962, -1.433, -0.658, -0.99, 2.267, -0.55, -2.694, -2.294, -3.383, 2.486, 0.963, -1.269, -1.62, 1.62, -0.875, -2.986, 0.392, -1.93, 0.193, -1.06, -0.703, -1.738, 0.248, -1.525, 1.361, -0.368, 0.788, 2.27, -0.351, -2.244, 3.519, -0.015, -0.591]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4aa28c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102], 
      "ysrc": "harry11733:104:f4b332", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364]
    }
  ], 
  "name": 102, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame104 = {
  "data": [
    {
      "xsrc": "harry11733:104:347e00", 
      "x": [-0.187, -1.725, 1.757, -3.617, 1.967, -2.941, -3.55, 1.385, -1.816, -1.267, 1.43, -3.484, 0.692, -1.006, 3.626, -2.018, -2.22, -2.795, 1.146, -2.191, -1.01, -3.235, -0.092, 0.501, -1.535, -2.566, -1.339, -1.736, -1.249, -3.212, -1.4, -0.847, -1.33, -2.181, -3.577, -3.746, -3.559, -3.228, -2.672, -3.082, 2.589, -3.741, 0.065, -2.929, -1.624, -0.104, -1.715, -1.538, -0.795, -1.747], 
      "ysrc": "harry11733:104:2297cc", 
      "y": [-0.36, 0.684, -2.62, 1.32, -3.436, 2.657, 0.892, 1.261, 0.468, 2.034, -0.529, -1.649, 0.658, -0.183, -3.405, -1.006, -0.288, 3.403, -1.499, -0.513, -1.14, 3.15, -0.798, -2.746, -1.881, -3.185, 1.893, 1.426, -1.032, -1.527, 1.433, -0.627, -2.747, 0.436, -2.546, -0.107, -0.764, -0.709, -1.962, 0.798, -0.97, 1.143, -0.874, 0.322, 2.151, -0.312, -2.218, 3.397, -0.153, -0.697]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:7bca4e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103], 
      "ysrc": "harry11733:104:8f9a30", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412]
    }
  ], 
  "name": 103, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame105 = {
  "data": [
    {
      "xsrc": "harry11733:104:1e973c", 
      "x": [0.103, -1.395, 1.757, -3.439, 2.025, -2.716, -3.278, 1.435, -1.68, -1.727, 1.602, -3.447, 0.583, -1.055, 3.144, -2.227, -2.009, -3.27, 1.749, -2.059, -0.866, -2.948, 0.857, 0.404, -1.365, -2.65, -1.544, -2.027, -1.458, -3.709, -1.439, -1.143, -1.442, -2.627, -3.458, -3.425, -3.637, -3.394, -3.264, -2.838, 3.323, -3.553, 0.105, -3.178, -1.678, 0.02, -1.891, -1.31, -0.398, -2.092], 
      "ysrc": "harry11733:104:520ec5", 
      "y": [-0.536, 0.378, -2.672, 1.7, -3.586, 2.9, 0.949, 0.804, 0.796, 2.518, -0.184, -1.805, 0.583, -0.357, -3.526, -1.128, -0.647, 3.029, -2.25, -0.646, -1.332, 2.973, -0.761, -2.58, -1.361, -3.358, 2.111, 0.667, -0.594, -1.372, 1.531, -0.904, -2.891, 0.577, -2.661, 0.246, -0.347, -0.261, -1.88, 0.192, -0.866, 1.529, -0.691, 0.44, 1.691, -0.408, -2.375, 3.527, -0.065, -0.303]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ab5631", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104], 
      "ysrc": "harry11733:104:e707e4", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484]
    }
  ], 
  "name": 104, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame106 = {
  "data": [
    {
      "xsrc": "harry11733:104:b16839", 
      "x": [0.343, -1.29, 1.341, -3.737, 2.264, -2.327, -3.502, 1.46, -1.53, -1.887, 1.531, -3.336, 0.341, -0.384, 3.634, -2.067, -1.53, -3.195, 1.813, -1.702, -0.745, -3.306, 0.844, 0.695, -0.731, -2.815, -1.549, -2.012, -1.133, -3.609, -1.247, -1.226, -1.458, -2.999, -3.811, -3.433, -3.771, -3.184, -3.457, -2.947, 3.798, -3.72, 0.027, -3.12, -1.191, 0.527, -2.648, -0.858, -0.378, -1.749], 
      "ysrc": "harry11733:104:f71511", 
      "y": [-0.87, 0.212, -2.418, 1.61, -3.676, 2.4, 1.498, 0.326, 0.97, 2.268, -0.172, -2.03, 1.278, -0.283, -3.328, -1.024, 0.012, 3.751, -2.782, -0.565, -0.874, 3.1, -0.723, -2.647, -1.461, -3.277, 2.404, 0.535, -0.536, -1.941, 1.712, -1.391, -3.023, 0.29, -2.709, 0.081, -0.665, 0.449, -1.856, 0.432, -0.316, 1.823, -0.648, 0.341, 1.189, -0.355, -1.758, 3.688, -0.417, -0.011]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:bd8c69", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105], 
      "ysrc": "harry11733:104:31b594", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508]
    }
  ], 
  "name": 105, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame107 = {
  "data": [
    {
      "xsrc": "harry11733:104:06ac17", 
      "x": [0.348, -0.395, 1.709, -3.614, 1.857, -2.456, -3.403, 1.264, -1.361, -1.823, 1.439, -3.488, 0.77, -1.005, 3.723, -2.125, -1.701, -3.038, 1.35, -1.378, -1.086, -3.379, 1.015, 0.905, -0.246, -2.774, -1.689, -1.55, -0.73, -3.424, -1.828, -1.407, -1.728, -2.745, -3.772, -3.677, -3.851, -2.95, -2.866, -2.864, 3.851, -3.196, -0.181, -3.536, -1.284, 1.331, -2.849, -0.184, -0.819, -1.531], 
      "ysrc": "harry11733:104:58cf71", 
      "y": [-1.061, 0.083, -2.196, 1.913, -2.718, 2.067, 2.111, 0.499, 0.825, 2.296, -0.566, -1.825, 1.186, -0.425, -3.161, -0.903, 0.475, 3.851, -3.146, -0.608, -1.083, 2.927, -0.727, -2.553, -1.872, -3.573, 2.12, 0.599, 0.119, -2.288, 2.206, -1.415, -2.38, -0.152, -3.17, 0.247, -0.861, 0.264, -2.162, 0.336, 0.025, 2.572, -0.817, 0.385, 0.903, 0.203, -2.369, 3.788, -0.129, -0.632]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4c5c70", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106], 
      "ysrc": "harry11733:104:02334f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596]
    }
  ], 
  "name": 106, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame108 = {
  "data": [
    {
      "xsrc": "harry11733:104:50ac5c", 
      "x": [0.772, -0.529, 1.694, -3.465, 2.34, -2.636, -3.393, 1.439, -1.353, -1.611, 1.396, -3.104, 1.028, -1.261, 3.767, -2.574, -2.18, -3.202, 1.129, -1.636, -0.652, -3.757, 0.828, 0.85, -0.407, -2.377, -2.01, -1.387, -0.383, -3.194, -2.137, -1.481, -1.852, -3.213, -3.639, -3.836, -3.8, -3.201, -3.121, -2.657, 3.86, -3.202, -0.209, -3.353, -0.626, 1.492, -2.36, 0.348, -0.499, -1.899], 
      "ysrc": "harry11733:104:bf7432", 
      "y": [-1.514, -0.188, -1.807, 2.025, -2.577, 2.049, 2.024, 0.669, 0.717, 2.955, -0.553, -2.339, 1.869, -0.92, -3.476, -0.805, 0.551, 3.805, -3.465, -0.577, -1.061, 2.995, -0.714, -2.392, -2.342, -3.596, 1.769, 0.256, 0.088, -2.387, 1.953, -2.039, -2.101, -0.123, -3.474, 0.09, -1.15, 0.016, -2.284, 0.245, -0.374, 2.791, -0.532, 0.469, 1.156, 0.331, -2.255, 3.262, -0.134, -0.578]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:bc7719", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107], 
      "ysrc": "harry11733:104:20a60a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684]
    }
  ], 
  "name": 107, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame109 = {
  "data": [
    {
      "xsrc": "harry11733:104:f4918b", 
      "x": [0.961, -0.578, 1.558, -3.504, 1.582, -3.227, -3.039, 1.595, -1.319, -1.422, 1.411, -2.505, 0.727, -1.361, 3.723, -2.77, -2.458, -3.184, 0.7, -1.617, -0.585, -3.583, 0.694, 0.613, -0.731, -2.344, -1.827, -1.512, -0.301, -3.494, -2.959, -1.538, -2.018, -3.148, -3.724, -3.617, -3.779, -3.063, -3.149, -2.622, 3.485, -3.063, 0.091, -3.484, -0.325, 1.572, -2.038, 0.932, -1.071, -1.895], 
      "ysrc": "harry11733:104:fb0ed3", 
      "y": [-1.827, 0.25, -1.766, 1.799, -2.72, 2.041, 1.614, 0.472, 0.516, 3.1, -0.384, -2.894, 1.942, -0.603, -3.3, -0.068, 0.801, 3.653, -3.29, -0.159, -1.403, 3.238, -0.653, -2.698, -2.257, -3.634, 2.176, 0.567, -0.088, -2.471, 2.243, -1.978, -1.986, 0.251, -3.566, 0.793, -0.812, 0.562, -2.681, 0.028, -0.561, 2.927, -1.023, 0.808, 1.462, 0.513, -2.086, 3.756, -0.193, -0.435]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ae6e50", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108], 
      "ysrc": "harry11733:104:db96d1", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468]
    }
  ], 
  "name": 108, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame110 = {
  "data": [
    {
      "xsrc": "harry11733:104:cf4f69", 
      "x": [1.18, -0.482, 1.649, -3.756, 0.926, -3.426, -2.962, 1.413, -1.753, -1.583, 1.154, -2.971, 0.867, -0.931, 3.814, -3.274, -2.631, -2.924, 0.946, -1.673, -1.17, -3.292, 0.695, 0.804, -0.581, -2.436, -1.137, -1.414, -0.494, -3.79, -3.177, -1.049, -1.938, -3.455, -3.392, -3.667, -3.645, -3.236, -3.15, -2.32, 2.848, -3.145, -0.239, -2.96, -0.426, 1.648, -1.884, 0.834, -0.254, -1.686], 
      "ysrc": "harry11733:104:ec63ff", 
      "y": [-1.786, 0.435, -1.686, 1.52, -3.158, 2.194, 2.01, 0.965, 0.661, 3.529, 0.185, -2.745, 1.967, -0.5, -3.047, -0.461, 0.639, 3.134, -3.571, 0.306, -1.2, 3.761, -0.387, -2.457, -1.607, -3.829, 2.569, 1.071, -0.084, -2.147, 2.741, -2.501, -2.132, -0.168, -3.374, 1.068, -0.805, 1.318, -2.803, -0.153, -0.756, 2.775, -0.819, 0.849, 1.367, 0.714, -1.728, 3.612, -0.183, -0.608]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:487e81", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109], 
      "ysrc": "harry11733:104:273e6b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732]
    }
  ], 
  "name": 109, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame111 = {
  "data": [
    {
      "xsrc": "harry11733:104:a1f5bc", 
      "x": [1.074, 0.092, 1.324, -3.829, 1.258, -3.57, -3.043, 1.179, -2.038, -2.161, 1.334, -3.263, 0.889, -0.785, 3.795, -3.532, -2.987, -2.542, 0.624, -2.141, -1.362, -3.115, 0.521, 0.589, -0.118, -2.332, -1.453, -1.515, -0.475, -3.52, -3.286, -1.001, -1.952, -3.161, -3.561, -3.472, -3.638, -3.109, -3.304, -2.591, 2.973, -3.654, -0.323, -2.473, -0.532, 0.973, -1.943, -0.102, -0.168, -1.916], 
      "ysrc": "harry11733:104:ae62ba", 
      "y": [-2.082, -0.095, -2.013, 1.16, -3.403, 1.907, 2.253, 0.372, 0.614, 3.746, 0.072, -2.729, 2.318, -0.338, -3.036, -1.093, 0.687, 3.586, -3.57, -0.504, -2.07, 3.602, -0.93, -2.419, -1.066, -3.616, 2.41, 1.324, -0.32, -2.637, 2.463, -2.638, -2.564, 0.219, -2.963, 0.8, -0.733, 1.373, -3.529, -0.165, -1.082, 2.616, -0.553, 0.539, 1.016, 1.099, -1.597, 3.456, -0.295, -0.782]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a95130", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110], 
      "ysrc": "harry11733:104:9b3dc2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792]
    }
  ], 
  "name": 110, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame112 = {
  "data": [
    {
      "xsrc": "harry11733:104:28a075", 
      "x": [0.986, 0.188, 1.132, -3.47, 1.753, -3.385, -3.124, 1.889, -1.892, -2.356, 1.484, -3.407, 0.366, -0.789, 3.828, -2.899, -2.713, -2.883, 0.762, -1.854, -1.014, -3.265, 0.474, 0.686, 0.267, -2.55, -1.524, -1.387, -0.29, -3.73, -3.312, -1.278, -2.366, -2.78, -3.095, -2.994, -3.316, -2.746, -3.735, -2.924, 3.12, -3.607, -0.739, -2.541, -0.765, 1.387, -1.707, -0.364, -0.213, -2.368], 
      "ysrc": "harry11733:104:2863cf", 
      "y": [-2.327, -0.469, -2.425, 1.175, -3.535, 1.87, 2.742, 0.571, 0.678, 3.674, -0.922, -3.1, 2.297, -0.554, -3.273, -1.331, 1.161, 3.477, -3.732, -0.851, -2.062, 3.597, -1.427, -2.774, -0.876, -3.747, 2.663, 0.613, -0.371, -2.877, 2.478, -2.428, -3.189, 0.27, -2.875, 1.228, -0.5, 1.903, -3.632, -0.378, -1.07, 2.498, -0.106, 0.681, 0.404, 1.559, -1.424, 3.509, -0.03, -0.854]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:97b227", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111], 
      "ysrc": "harry11733:104:396df7", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792]
    }
  ], 
  "name": 111, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame113 = {
  "data": [
    {
      "xsrc": "harry11733:104:87fa9f", 
      "x": [0.863, 0.151, 1.486, -3.227, 1.908, -3.232, -3.15, 1.572, -1.799, -2.456, 1.329, -3.166, 0.09, -0.857, 3.341, -3.091, -2.587, -2.65, 0.641, -1.779, -1.321, -2.932, -0.117, 0.635, -0.131, -2.61, -2.064, -1.489, -0.315, -3.79, -2.597, -1.468, -2.294, -2.8, -3.14, -3.248, -3.535, -2.455, -3.703, -2.304, 3.124, -3.521, -0.503, -2.398, -0.899, 1.256, -1.507, -0.223, -0.37, -2.585], 
      "ysrc": "harry11733:104:3e47b8", 
      "y": [-1.727, -0.919, -2.646, 1.254, -3.354, 1.445, 2.782, 0.373, 0.463, 3.441, -0.822, -3.298, 2.377, -0.515, -3.461, -1.114, 1.025, 3.147, -3.216, -1.131, -1.72, 3.866, -1.15, -2.527, -0.623, -3.632, 2.834, 0.427, -0.472, -2.837, 2.308, -3.145, -3.236, -0.206, -2.749, 1.186, -0.556, 1.484, -3.185, -0.54, -0.988, 2.918, -0.258, 0.829, 0.587, 1.752, -1.293, 3.847, 0.525, -0.821]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ae213d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112], 
      "ysrc": "harry11733:104:6496a8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844]
    }
  ], 
  "name": 112, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame114 = {
  "data": [
    {
      "xsrc": "harry11733:104:1ded00", 
      "x": [1.806, 0.111, 1.219, -2.993, 1.826, -3.608, -3.346, 1.492, -1.25, -2.259, 1.131, -3.101, 0.326, -1.209, 3.739, -2.468, -2.603, -2.993, 0.866, -1.815, -1.382, -2.632, -0.21, 1.024, 0.029, -2.83, -1.322, -1.612, -0.341, -3.752, -2.338, -0.967, -2.305, -3.363, -2.79, -3.677, -3.675, -2.565, -3.714, -2.273, 3.511, -3.524, -0.806, -2.622, -0.941, 0.939, -0.935, -0.646, -0.665, -2.879], 
      "ysrc": "harry11733:104:63a20d", 
      "y": [-1.98, -1.385, -2.918, 1.298, -3.593, 1.824, 3.129, 0.14, 0.207, 3.222, -0.461, -3.626, 2.446, -0.553, -3.327, -1.378, 1.615, 3.302, -2.971, -0.794, -1.201, 3.716, -1.152, -3.116, -0.949, -3.699, 2.004, 0.224, -0.379, -2.855, 2.383, -3.243, -3.84, 0.525, -2.407, 1.904, -0.215, 0.79, -2.535, -0.744, -0.732, 3.038, -0.301, 0.419, 0.203, 2.178, -1.081, 3.429, 0.06, -0.642]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:3b8057", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113], 
      "ysrc": "harry11733:104:24ba7a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484]
    }
  ], 
  "name": 113, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame115 = {
  "data": [
    {
      "xsrc": "harry11733:104:5b7f9c", 
      "x": [1.718, 0.566, 1.456, -2.402, 2.035, -3.802, -3.012, 1.588, -1.35, -1.973, 1.147, -3.533, 1.125, -1.237, 3.273, -2.315, -2.328, -3.148, 1.007, -2.231, -1.799, -3.146, -0.431, 0.904, -0.018, -3.523, -1.026, -1.431, -0.185, -3.695, -2.955, -0.704, -2.349, -3.715, -2.705, -3.785, -3.591, -2.242, -3.849, -2.254, 3.772, -3.553, -0.697, -2.815, -1.146, 0.29, -1.181, -0.533, -0.09, -2.778], 
      "ysrc": "harry11733:104:b4ffe5", 
      "y": [-1.253, -1.515, -2.486, 1.265, -3.389, 2.188, 3.396, -0.373, 0.331, 3.171, -0.582, -3.685, 2.441, -0.056, -3.349, -1.318, 1.516, 3.23, -2.821, -1.286, -1.302, 3.731, -1.16, -3.38, -0.788, -3.804, 1.919, 0.318, -0.391, -3.163, 2.957, -3.056, -3.639, 0.552, -2.252, 2.294, -0.379, 0.428, -2.96, -0.343, -1.459, 3.186, -0.65, 0.151, 0.592, 2.047, -1.515, 3.451, 0.557, -0.277]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b574f1", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114], 
      "ysrc": "harry11733:104:6b1cba", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992]
    }
  ], 
  "name": 114, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame116 = {
  "data": [
    {
      "xsrc": "harry11733:104:0a583c", 
      "x": [1.719, 0.739, 1.52, -2.281, 2.278, -3.658, -3.022, 1.427, -1.841, -2.077, 1.049, -3.505, 1.204, -1.137, 3.023, -2.328, -2.395, -2.849, 0.799, -2.46, -1.162, -3.074, -0.62, 0.755, 0.147, -3.795, -1.06, -1.619, -0.287, -3.441, -2.905, -0.604, -2.553, -3.522, -2.307, -3.843, -3.334, -2.15, -3.787, -2.696, 3.595, -3.782, -0.55, -3.275, -1.046, 0.368, -1.085, -0.534, -0.401, -2.779], 
      "ysrc": "harry11733:104:cd36d4", 
      "y": [-1.208, -1.874, -2.497, 0.97, -3.372, 1.62, 3.21, 0.251, 0.572, 2.732, -1.086, -3.812, 2.613, 0.079, -3.188, -1.201, 1.545, 3.376, -2.69, -1.646, -1.021, 3.602, -0.859, -2.829, -1.483, -3.72, 1.933, 0.228, -0.562, -3.156, 2.606, -3.264, -3.674, 1.15, -1.755, 1.913, -0.207, 0.443, -3.089, -0.77, -1.334, 2.839, -0.581, 0.48, -0.246, 2.299, -1.437, 2.95, 1.23, 0.019]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:acc887", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115], 
      "ysrc": "harry11733:104:c7b9ad", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036]
    }
  ], 
  "name": 115, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame117 = {
  "data": [
    {
      "xsrc": "harry11733:104:4e1736", 
      "x": [1.412, 0.76, 1.628, -2.689, 2.247, -3.852, -3.09, 1.875, -1.822, -1.953, 1.297, -3.493, 1.194, -1.348, 3.097, -2.065, -2.785, -3.093, 0.551, -2.688, -0.74, -2.613, -1.003, 0.81, 0.133, -3.74, -0.983, -1.208, 0.103, -3.5, -2.885, -0.615, -2.138, -3.467, -2.28, -2.948, -3.312, -2.186, -3.705, -2.238, 3.86, -3.769, -0.174, -3.599, -1.452, 0.708, -1.516, -0.096, -0.49, -2.73], 
      "ysrc": "harry11733:104:98ab66", 
      "y": [-1.341, -2.257, -2.419, 1.011, -3.501, 1.559, 3.809, 0.141, 0.567, 2.489, -1.319, -3.469, 2.119, -0.54, -3.475, -1.508, 1.468, 3.674, -2.629, -2.114, -0.951, 3.784, -1.244, -3.596, -1.3, -3.388, 1.964, 0.806, -0.922, -3.167, 3.022, -2.727, -3.725, 1.346, -1.794, 1.791, -0.06, 0.16, -3.832, -0.519, -0.903, 2.94, -0.487, 0.449, -0.166, 2.097, -1.495, 3.46, 0.636, 0.272]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e4970b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116], 
      "ysrc": "harry11733:104:3abecb", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028]
    }
  ], 
  "name": 116, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame118 = {
  "data": [
    {
      "xsrc": "harry11733:104:23a5e6", 
      "x": [1.61, 0.456, 1.926, -2.293, 2.426, -3.392, -3.599, 1.509, -2.195, -2.04, 0.897, -3.349, 1.034, -1.311, 3.211, -2.163, -2.945, -3.077, 0.08, -2.109, -0.623, -2.362, -0.989, 0.524, 0.009, -3.694, -0.379, -1.197, 0.556, -3.839, -3.433, -0.121, -2.568, -3.829, -2.352, -2.798, -3.774, -2.594, -3.825, -2.33, 3.789, -3.691, -0.524, -3.345, -1.52, 0.964, -1.802, 0.007, -0.425, -2.955], 
      "ysrc": "harry11733:104:d3176e", 
      "y": [-1.35, -1.899, -2.271, 1.715, -3.801, 2.228, 3.684, 0.338, 0.583, 2.645, -1.509, -2.947, 2.344, -0.272, -3.631, -1.313, 0.947, 2.923, -2.305, -1.778, -0.82, 3.682, -1.151, -3.742, -1.381, -3.691, 2.459, 0.648, -0.781, -3.178, 3.253, -2.543, -3.797, 1.862, -1.591, 1.595, -0.016, 0.356, -3.452, -1.07, -0.442, 3.381, -0.821, 0.119, -0.603, 2.018, -1.446, 3.459, 0.864, 1.175]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:150ac6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117], 
      "ysrc": "harry11733:104:736935", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036]
    }
  ], 
  "name": 117, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame119 = {
  "data": [
    {
      "xsrc": "harry11733:104:e288ea", 
      "x": [2.038, 0.249, 2.129, -2.369, 2.389, -3.673, -3.699, 1.323, -2.119, -2.264, 0.807, -3.107, 1.097, -1.254, 2.939, -2.336, -2.795, -2.993, 0.58, -1.959, -0.714, -3.1, -0.927, 0.512, -0.02, -3.359, -0.233, -1.175, 0.435, -3.731, -3.607, -0.307, -2.526, -3.839, -2.321, -3.052, -3.654, -2.78, -3.768, -2.382, 3.557, -3.76, -0.597, -3.317, -1.632, 1.21, -1.941, 0.331, -0.508, -2.339], 
      "ysrc": "harry11733:104:e9f6dc", 
      "y": [-1.039, -2.026, -2.337, 1.676, -3.788, 2.27, 3.864, 0.253, 0.536, 2.774, -1.344, -2.682, 2.442, -0.173, -3.785, -1.408, 0.588, 3.717, -1.758, -1.383, -0.745, 3.635, -0.579, -3.516, -1.315, -3.599, 2.402, 0.188, -0.508, -3.257, 2.434, -2.622, -3.454, 1.695, -1.717, 1.803, -0.201, 0.702, -3.548, -1.293, -0.531, 3.686, -0.33, -0.71, -0.688, 2.439, -1.493, 3.651, 0.776, 0.863]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4637c3", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118], 
      "ysrc": "harry11733:104:2b320a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152]
    }
  ], 
  "name": 118, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame120 = {
  "data": [
    {
      "xsrc": "harry11733:104:37ac82", 
      "x": [1.47, 0.429, 1.718, -2.466, 2.87, -3.749, -3.467, 1.106, -2.114, -2.197, -0.038, -3.171, 1.179, -1.159, 3.485, -2.217, -3.032, -3.252, 0.201, -1.995, -0.813, -3.016, -0.984, 0.315, 0.449, -3.74, 0.114, -1.237, 0.278, -3.607, -3.534, -0.125, -2.961, -3.835, -1.763, -3.036, -3.587, -2.513, -3.791, -1.906, 3.309, -3.499, -0.478, -3.55, -1.452, 0.929, -1.794, 0.048, -0.891, -2.215], 
      "ysrc": "harry11733:104:c88f99", 
      "y": [-0.561, -1.931, -2.4, 1.308, -3.587, 2.55, 3.856, 0.078, -0.188, 2.48, -1.785, -2.519, 2.409, 0.153, -3.611, -1.355, 0.392, 3.696, -2.242, -1.608, -0.621, 3.828, -0.917, -3.751, -0.715, -3.544, 2.159, 0.827, -0.386, -3.523, 2.704, -2.992, -3.29, 1.379, -1.203, 2.076, 0.48, 0.538, -3.293, -1.183, -1.009, 3.638, -0.112, -0.69, -0.636, 2.387, -1.589, 3.823, 1.261, 0.627]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c4a855", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119], 
      "ysrc": "harry11733:104:727309", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064]
    }
  ], 
  "name": 119, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame121 = {
  "data": [
    {
      "xsrc": "harry11733:104:beba6a", 
      "x": [1.73, 0.551, 2.169, -2.953, 3.03, -3.736, -3.407, 1.447, -2.607, -2.152, -0.159, -3.731, 0.933, -1.355, 3.535, -2.219, -3.027, -3.408, 0.466, -2.8, -1.21, -3.446, -0.594, -0.142, 0.581, -3.391, -0.264, -1.1, 0.204, -3.769, -3.394, -0.322, -3.578, -3.668, -1.847, -2.627, -3.449, -2.688, -3.589, -1.866, 3.371, -3.714, -0.312, -3.344, -1.579, 0.586, -1.482, -0.578, -1.438, -1.941], 
      "ysrc": "harry11733:104:9914ef", 
      "y": [-0.935, -1.737, -2.214, 0.889, -3.324, 2.178, 3.538, 0.142, -0.266, 2.78, -1.505, -2.619, 2.298, 0.153, -3.246, -1.456, 0.837, 3.226, -2.124, -1.706, -0.173, 3.691, -1.212, -3.022, -0.791, -3.464, 2.622, 1.129, -0.22, -3.177, 2.229, -3.241, -3.852, 1.671, -1.888, 2.128, 0.17, 0.518, -3.567, -1.636, -0.814, 3.796, -0.487, -0.818, -1.019, 2.647, -2.105, 3.683, 0.859, 0.592]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:bc0816", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120], 
      "ysrc": "harry11733:104:5f2827", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512]
    }
  ], 
  "name": 120, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame122 = {
  "data": [
    {
      "xsrc": "harry11733:104:0e24fa", 
      "x": [2.352, 0.37, 2.083, -2.942, 2.819, -3.273, -3.231, 2.042, -2.257, -2.39, -0.647, -3.73, 1.12, -1.139, 3.475, -1.424, -2.768, -3.683, 0.736, -2.589, -0.792, -3.22, 0.024, 0.018, 0.943, -2.94, -0.824, -1.016, -0.034, -3.713, -3.436, -0.543, -3.376, -3.674, -1.867, -3.445, -3.61, -2.744, -3.735, -1.604, 3.457, -3.823, -0.457, -2.993, -2.246, 0.352, -1.451, -0.534, -1.297, -1.794], 
      "ysrc": "harry11733:104:512c66", 
      "y": [-0.709, -1.351, -2.779, 0.825, -3.203, 2.525, 3.422, 0.548, -0.398, 2.041, -1.754, -3.066, 2.544, 0.368, -3.337, -1.325, 1.092, 2.991, -2.227, -1.634, -0.04, 3.357, -0.965, -2.494, -0.428, -3.195, 2.702, 1.212, -0.264, -2.434, 2.121, -3.694, -3.623, 1.529, -1.77, 1.931, 0.241, 0.544, -3.811, -1.24, -0.263, 3.608, -0.526, -0.539, -0.734, 2.517, -2.315, 3.133, 0.926, 1.484]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:87de29", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121], 
      "ysrc": "harry11733:104:de8a7b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196]
    }
  ], 
  "name": 121, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame123 = {
  "data": [
    {
      "xsrc": "harry11733:104:a13ff0", 
      "x": [2.555, -0.135, 2.053, -2.931, 2.259, -3.718, -3.169, 2.408, -2.489, -2.511, -0.365, -3.613, 0.95, -1.322, 3.601, -1.357, -2.197, -3.222, 1.021, -2.882, -0.939, -3.005, -0.248, 0.486, 1.016, -2.969, -0.767, -0.418, 0.017, -3.113, -3.005, -0.769, -3.552, -3.812, -1.516, -3.307, -3.835, -2.98, -3.459, -1.785, 3.761, -3.652, -0.858, -3.389, -2.202, 0.193, -1.422, -0.973, -1.027, -2.076], 
      "ysrc": "harry11733:104:e38894", 
      "y": [-1.052, -1.466, -3.202, 0.832, -3.305, 2.159, 3.606, 0.778, -0.872, 2.663, -2.288, -3.418, 2.484, 0.337, -3.424, -0.926, 1.067, 2.53, -2.625, -1.407, 0.37, 3.197, -0.858, -2.375, -0.211, -3.109, 2.79, 1.444, -0.261, -2.324, 1.686, -3.828, -3.079, 1.545, -1.722, 1.901, 0.799, 0.909, -3.654, -0.985, -0.369, 3.545, -1.149, -0.469, -0.77, 2.842, -2.371, 3.211, 1.675, 1.641]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:85ba0e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122], 
      "ysrc": "harry11733:104:6fcaec", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312]
    }
  ], 
  "name": 122, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame124 = {
  "data": [
    {
      "xsrc": "harry11733:104:0cc35e", 
      "x": [2.936, -0.353, 2.445, -2.542, 1.954, -3.238, -3.467, 1.999, -2.672, -2.497, -0.509, -3.481, 0.636, -1.726, 3.635, -1.617, -2.069, -3.359, 1.392, -3.137, -1.228, -2.498, -0.221, -0.237, 0.471, -2.769, -0.838, -0.223, 0.209, -3.522, -2.994, -0.481, -3.637, -3.605, -1.85, -3.676, -3.848, -3.336, -3.288, -1.494, 3.702, -3.847, -1.222, -3.5, -2.152, 0.535, -1.555, -0.949, -1.207, -2.21], 
      "ysrc": "harry11733:104:114682", 
      "y": [-0.772, -1.755, -3.319, 0.703, -3.18, 1.861, 3.6, 0.381, -0.84, 2.607, -2.461, -2.961, 2.438, 0.21, -3.424, -1.168, 1.278, 2.876, -2.527, -1.527, 0.45, 3.407, -0.998, -2.152, 0.346, -3.391, 2.948, 1.949, -0.271, -2.406, 1.968, -3.62, -2.954, 1.913, -1.75, 1.938, 0.919, 1.27, -3.752, -1.138, -0.158, 3.305, -0.955, 0.032, -1.185, 3.221, -2.036, 3.161, 1.987, 2.04]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c23f72", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123], 
      "ysrc": "harry11733:104:fe5076", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216]
    }
  ], 
  "name": 123, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame125 = {
  "data": [
    {
      "xsrc": "harry11733:104:26323b", 
      "x": [2.994, 0.134, 2.629, -2.876, 1.834, -3.698, -3.404, 1.815, -2.701, -1.79, -0.611, -3.327, 0.073, -1.186, 3.832, -1.421, -1.715, -3.414, 1.659, -3.087, -1.442, -3.143, -0.231, -0.291, 1.231, -2.784, -0.969, 0.202, 0.861, -3.819, -3.221, -0.698, -3.388, -2.92, -1.679, -3.507, -3.5, -2.788, -2.878, -1.398, 3.812, -3.806, -1.072, -3.654, -2.225, 0.655, -1.794, -0.862, -0.778, -1.926], 
      "ysrc": "harry11733:104:7f2641", 
      "y": [-0.319, -1.401, -3.387, 0.445, -3.01, 2.145, 3.602, 0.145, -0.633, 2.59, -3.045, -3.037, 2.357, 0.256, -3.423, -0.804, 1.147, 2.912, -2.519, -1.26, 0.316, 3.018, -1.064, -2.328, 0.176, -3.744, 2.817, 1.596, -0.327, -2.3, 2.23, -3.854, -2.942, 1.872, -0.954, 2.056, 0.978, 1.546, -3.759, -1.308, 0.181, 3.049, -0.887, -0.02, -1.688, 3.351, -1.753, 3.134, 2.096, 2.057]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:20cd99", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124], 
      "ysrc": "harry11733:104:e7fd5b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432]
    }
  ], 
  "name": 124, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame126 = {
  "data": [
    {
      "xsrc": "harry11733:104:461104", 
      "x": [2.776, 0.146, 2.436, -2.748, 1.815, -3.635, -3.432, 1.513, -2.933, -2.263, -0.459, -3.712, 0.077, -1.415, 3.722, -1.145, -1.722, -3.842, 1.906, -3.229, -1.768, -3.286, -0.417, -0.431, 1.433, -3.15, -1.139, 0.273, 0.691, -3.568, -3.045, -1.136, -3.286, -3.191, -2.163, -3.516, -3.512, -2.384, -2.89, -1.452, 3.847, -3.364, -0.947, -3.795, -1.681, 0.721, -1.789, -0.872, -0.001, -1.818], 
      "ysrc": "harry11733:104:2bdca4", 
      "y": [-0.496, -1.271, -2.673, 0.385, -3.608, 2.594, 3.27, 0.207, -0.858, 2.064, -3.199, -2.979, 1.825, 0.857, -3.5, -0.138, 1.479, 2.58, -2.678, -1.071, 0.362, 2.952, -0.282, -2.178, 0.79, -3.481, 2.6, 1.882, -0.645, -2.928, 2.305, -3.619, -2.605, 1.619, -1.184, 2.062, 1.367, 2.12, -3.437, -1.041, 0.09, 2.641, -0.956, -0.267, -2.326, 3.564, -2.083, 3.23, 2.117, 1.946]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:eabde8", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125], 
      "ysrc": "harry11733:104:22634f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428]
    }
  ], 
  "name": 125, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame127 = {
  "data": [
    {
      "xsrc": "harry11733:104:51ade8", 
      "x": [2.817, 0.102, 2.344, -2.862, 1.902, -3.667, -3.653, 1.682, -2.687, -2.12, -0.695, -3.765, 0.095, -1.254, 3.485, -1.127, -1.041, -3.732, 1.586, -3.083, -1.85, -3.568, -0.428, -0.777, 1.142, -3.679, -1.414, 0.607, 1.228, -3.592, -3.169, -1.577, -3.262, -3.097, -2.002, -3.651, -3.199, -1.844, -2.65, -1.707, 3.726, -3.539, -0.908, -3.78, -1.665, 0.203, -1.422, -1.208, 0.285, -2.004], 
      "ysrc": "harry11733:104:29f314", 
      "y": [-0.088, -2.458, -2.644, 0.533, -3.852, 2.75, 3.245, 0.026, -1.128, 2.323, -3.071, -3.117, 1.668, 0.704, -3.776, 0.321, 1.225, 2.579, -2.644, -1.234, 0.585, 2.909, -0.108, -2.592, 0.531, -3.292, 2.596, 1.849, -0.909, -2.294, 2.368, -3.542, -2.901, 1.505, -0.644, 1.934, 1.284, 2.181, -3.458, -0.526, 0.446, 2.662, -1.215, -0.516, -2.368, 2.948, -2.347, 3.159, 1.942, 1.827]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:236e82", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126], 
      "ysrc": "harry11733:104:691b25", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444]
    }
  ], 
  "name": 126, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame128 = {
  "data": [
    {
      "xsrc": "harry11733:104:1b9e99", 
      "x": [3.264, 0.665, 2.279, -3.15, 2.387, -3.697, -2.978, 1.573, -2.51, -1.563, -0.623, -3.022, 0.423, -1.346, 3.382, -0.844, -0.79, -3.62, 1.432, -3.337, -1.903, -3.148, -0.363, -0.478, 1.425, -3.561, -1.546, 0.185, 1.155, -3.135, -3.084, -1.529, -3.646, -3.481, -1.684, -2.881, -3.571, -2.136, -2.655, -1.691, 3.771, -3.368, -0.994, -3.644, -1.625, 0.36, -1.382, -1.08, -0.066, -1.798], 
      "ysrc": "harry11733:104:869d6d", 
      "y": [0.452, -1.695, -2.91, 0.608, -3.848, 2.672, 3.637, 0.068, -0.818, 2.124, -3.267, -3.228, 2.344, 0.512, -3.107, 0.151, 0.946, 2.069, -2.312, -1.13, 0.333, 3.404, 0.182, -2.657, 0.456, -2.569, 2.903, 1.579, -0.785, -2.323, 2.55, -3.571, -2.953, 1.083, -1.009, 1.886, 0.821, 2.229, -3.535, -1.022, 0.07, 2.214, -1.185, -0.307, -2.313, 2.874, -2.249, 3.669, 1.523, 1.546]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:cb22ca", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127], 
      "ysrc": "harry11733:104:7d6420", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492]
    }
  ], 
  "name": 127, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame129 = {
  "data": [
    {
      "xsrc": "harry11733:104:e83e01", 
      "x": [2.885, 1.153, 1.903, -3.183, 2.299, -3.264, -2.844, 1.962, -1.836, -1.402, -0.639, -2.849, 0.925, -1.29, 3.653, -1.188, -1.125, -3.768, 1.8, -3.4, -2.104, -3.595, -0.304, -0.319, 1.717, -3.464, -1.681, 0.473, 0.647, -3.702, -2.811, -1.416, -3.166, -3.355, -1.696, -3.044, -3.861, -2.31, -2.868, -1.661, 3.561, -3.383, -0.255, -3.86, -1.565, 0.485, -1.141, -1.11, -0.253, -2.071], 
      "ysrc": "harry11733:104:200145", 
      "y": [0.513, -1.595, -3.065, 1.344, -3.684, 2.341, 3.675, 0.236, -0.693, 2.203, -3.746, -3.181, 1.753, 0.252, -3.488, 0.521, 0.337, 2.058, -2.542, -1.06, 0.141, 3.176, -0.355, -2.683, 0.342, -2.739, 2.822, 1.478, -0.72, -2.34, 2.07, -3.459, -2.815, 1.406, -1.185, 1.769, 0.949, 1.764, -3.612, -1.023, -0.159, 2.844, -1.361, -0.591, -2.606, 2.566, -1.996, 3.406, 1.157, 1.402]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:72be9d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128], 
      "ysrc": "harry11733:104:d15b98", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564]
    }
  ], 
  "name": 128, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame130 = {
  "data": [
    {
      "xsrc": "harry11733:104:688747", 
      "x": [3.057, 0.53, 2.217, -3.338, 1.805, -3.0, -3.041, 1.724, -2.311, -1.403, -0.22, -3.427, 0.723, -1.564, 3.663, -0.743, -0.819, -3.684, 1.66, -3.823, -2.153, -3.633, -0.781, -0.224, 1.527, -3.478, -2.383, 0.472, 0.422, -3.578, -2.514, -1.356, -2.604, -3.521, -1.36, -3.406, -3.428, -2.117, -3.394, -1.635, 3.04, -3.183, -0.334, -3.838, -1.491, 0.944, -1.422, -1.247, -0.073, -1.883], 
      "ysrc": "harry11733:104:a30a80", 
      "y": [0.322, -1.229, -3.342, 1.293, -3.561, 2.43, 3.83, 0.445, -0.367, 2.296, -3.835, -3.08, 1.751, -0.003, -3.19, 1.104, 0.482, 2.193, -2.209, -1.126, 0.497, 2.693, -0.225, -2.421, 0.284, -2.807, 3.293, 2.004, -0.945, -2.579, 2.256, -2.832, -2.751, 0.909, -1.188, 2.344, 0.614, 1.438, -3.669, -0.537, -0.026, 2.487, -1.256, -0.232, -3.017, 2.581, -2.297, 2.914, 1.326, 0.919]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e50370", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129], 
      "ysrc": "harry11733:104:135215", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612]
    }
  ], 
  "name": 129, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame131 = {
  "data": [
    {
      "xsrc": "harry11733:104:3eb5dc", 
      "x": [3.303, 0.895, 1.927, -3.454, 1.962, -2.737, -2.746, 1.68, -1.889, -1.127, -0.674, -3.785, 0.658, -1.437, 3.822, -1.215, -0.435, -3.014, 1.784, -3.506, -2.786, -3.555, -0.508, -0.018, 1.452, -3.354, -2.176, 0.148, 0.055, -3.566, -2.468, -1.552, -2.156, -3.536, -0.388, -3.319, -3.652, -2.276, -3.444, -2.092, 3.188, -3.426, -0.514, -3.4, -1.615, 1.35, -1.957, -1.265, -0.0, -1.654], 
      "ysrc": "harry11733:104:ed977e", 
      "y": [0.327, -0.995, -3.256, 1.159, -3.841, 2.364, 3.775, 0.509, -0.476, 2.652, -3.722, -2.986, 2.058, 0.475, -3.293, 1.045, 0.094, 2.501, -2.381, -1.235, 0.765, 2.438, 0.051, -2.6, 0.088, -2.591, 3.497, 2.032, -0.767, -2.585, 2.839, -3.077, -2.177, 1.37, -1.222, 2.169, 0.408, 1.196, -3.434, -0.645, -0.33, 2.432, -1.246, 0.468, -2.731, 2.619, -2.108, 3.222, 1.069, 1.042]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:8433fc", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130], 
      "ysrc": "harry11733:104:0db043", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558]
    }
  ], 
  "name": 130, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame132 = {
  "data": [
    {
      "xsrc": "harry11733:104:ef0f2e", 
      "x": [3.303, 1.863, 2.329, -3.314, 1.684, -3.042, -2.841, 1.062, -2.089, -1.562, -0.728, -3.8, 0.693, -1.431, 3.568, -1.36, 0.081, -2.819, 1.553, -3.438, -2.934, -3.269, -0.273, 0.077, 1.559, -3.166, -2.381, 0.001, -0.126, -3.174, -2.646, -2.045, -2.503, -3.28, 0.164, -3.385, -3.634, -2.524, -3.794, -2.178, 2.762, -3.424, -0.235, -3.388, -0.881, 1.375, -1.497, -1.793, 0.18, -1.493], 
      "ysrc": "harry11733:104:1ed1f7", 
      "y": [0.178, -0.909, -3.152, 2.049, -3.804, 1.736, 3.646, 0.288, -0.604, 2.265, -3.367, -2.6, 1.914, 0.874, -3.177, 0.942, 0.328, 2.172, -2.204, -1.576, 1.257, 2.869, 0.105, -2.357, 0.23, -1.953, 3.03, 2.105, -0.111, -2.665, 2.702, -3.066, -2.812, 1.258, -1.189, 2.663, -0.232, 1.0, -3.682, -0.975, -0.377, 2.306, -1.842, 0.754, -2.86, 2.687, -1.846, 3.391, 1.049, 1.074]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:73ff8c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131], 
      "ysrc": "harry11733:104:f4c504", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688]
    }
  ], 
  "name": 131, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame133 = {
  "data": [
    {
      "xsrc": "harry11733:104:3b2867", 
      "x": [2.849, 2.178, 2.42, -3.068, 2.047, -3.303, -2.858, 1.422, -2.245, -1.995, -0.459, -3.854, 0.712, -1.452, 3.71, -1.787, 0.143, -2.952, 1.997, -3.175, -2.925, -3.75, -0.012, -0.047, 1.101, -2.846, -2.666, 0.232, 0.158, -2.594, -2.651, -1.833, -3.081, -3.138, 0.042, -3.79, -3.71, -2.86, -3.715, -1.818, 2.771, -3.107, -0.138, -3.607, -1.116, 2.302, -1.024, -2.034, -0.094, -1.791], 
      "ysrc": "harry11733:104:62a351", 
      "y": [0.339, -0.634, -2.695, 2.338, -3.649, 1.597, 3.417, 0.634, -0.248, 2.382, -3.654, -2.807, 1.687, 0.741, -2.837, 1.352, 0.405, 2.406, -2.192, -2.034, 0.505, 2.712, 0.389, -2.85, -0.431, -2.658, 3.341, 2.445, 0.074, -2.362, 2.279, -3.605, -3.128, 0.911, -1.772, 3.109, -0.09, 1.37, -3.757, -1.329, -0.183, 2.524, -1.952, 0.464, -2.841, 2.179, -2.174, 3.466, 0.777, 1.568]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:1ecb99", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132], 
      "ysrc": "harry11733:104:e41630", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696]
    }
  ], 
  "name": 132, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame134 = {
  "data": [
    {
      "xsrc": "harry11733:104:d45ff4", 
      "x": [3.059, 2.527, 2.63, -3.253, 1.814, -3.089, -2.361, 1.429, -2.358, -2.081, -0.518, -3.865, 0.591, -1.266, 3.684, -1.612, 0.625, -2.932, 1.166, -2.892, -3.209, -3.771, 0.011, 0.035, 0.861, -3.184, -2.119, -0.292, 0.087, -2.854, -2.537, -1.927, -2.877, -3.093, 0.053, -3.855, -3.758, -3.055, -3.771, -1.693, 2.457, -3.377, -0.152, -3.602, -1.037, 2.452, -1.212, -2.167, -0.049, -1.777], 
      "ysrc": "harry11733:104:9b8f0c", 
      "y": [0.022, -0.708, -2.386, 2.463, -3.62, 1.965, 3.205, 0.862, 0.155, 3.065, -3.177, -2.943, 1.922, 0.762, -2.717, 1.368, 0.144, 1.768, -1.715, -1.755, -0.029, 3.239, -0.047, -2.97, 0.179, -2.803, 3.338, 2.76, 0.516, -1.809, 2.162, -3.789, -3.032, 0.912, -2.277, 3.198, -0.048, 1.3, -3.544, -1.5, -0.476, 2.778, -1.592, -0.014, -2.683, 2.047, -2.166, 3.45, 1.083, 1.337]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:2abe21", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133], 
      "ysrc": "harry11733:104:c9ec47", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688]
    }
  ], 
  "name": 133, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame135 = {
  "data": [
    {
      "xsrc": "harry11733:104:e3bafd", 
      "x": [2.742, 2.861, 2.639, -3.333, 2.025, -2.582, -2.275, 1.392, -2.419, -2.242, -0.802, -3.689, 1.057, -1.049, 3.58, -1.981, 0.839, -2.632, 1.338, -2.496, -3.02, -3.621, -0.133, -0.151, 0.985, -3.028, -2.366, 0.182, 0.361, -2.767, -2.393, -2.233, -2.604, -2.835, 0.16, -3.423, -3.798, -3.392, -3.688, -1.062, 2.533, -3.759, -0.141, -3.639, -0.468, 2.839, -1.48, -2.278, 0.016, -1.505], 
      "ysrc": "harry11733:104:6cc177", 
      "y": [0.116, -0.726, -1.948, 2.308, -3.797, 1.668, 2.997, 0.705, 0.388, 3.121, -3.038, -2.775, 1.917, 0.731, -2.481, 1.357, 0.08, 1.64, -1.972, -1.303, 0.162, 3.32, -0.221, -2.838, 0.323, -3.162, 2.966, 2.894, 0.867, -1.139, 2.512, -3.723, -2.834, 0.568, -2.781, 3.817, -0.44, 1.465, -3.688, -1.505, -0.301, 3.101, -1.63, -0.105, -3.017, 2.369, -2.229, 3.462, 0.88, 1.004]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:90730c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134], 
      "ysrc": "harry11733:104:223411", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728]
    }
  ], 
  "name": 134, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame136 = {
  "data": [
    {
      "xsrc": "harry11733:104:956f31", 
      "x": [3.146, 2.973, 3.059, -3.804, 1.742, -1.933, -2.166, 1.373, -2.253, -2.603, -0.546, -3.658, 0.583, -1.108, 3.713, -1.964, 0.618, -2.524, 1.596, -2.554, -3.276, -3.753, -0.298, -0.266, 1.092, -2.734, -2.126, 0.557, -0.091, -2.656, -2.858, -2.117, -2.346, -2.105, -0.152, -3.258, -3.322, -3.334, -3.857, -0.879, 2.119, -3.856, 0.145, -3.436, -0.342, 2.165, -1.314, -2.447, 0.101, -1.711], 
      "ysrc": "harry11733:104:d62f5f", 
      "y": [-0.093, -0.763, -2.099, 1.992, -3.801, 1.515, 3.262, 0.575, 0.497, 2.834, -3.213, -2.897, 2.401, 1.1, -2.193, 1.616, 0.015, 2.115, -2.038, -1.191, 0.026, 3.619, 0.281, -3.525, 0.324, -2.895, 2.807, 3.283, 1.266, -0.937, 1.877, -3.571, -3.354, 1.079, -2.93, 3.632, -0.869, 0.974, -3.516, -1.87, -0.174, 3.704, -0.859, 0.168, -3.066, 2.529, -2.1, 3.488, 1.038, 1.121]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e43935", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135], 
      "ysrc": "harry11733:104:456840", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792]
    }
  ], 
  "name": 135, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame137 = {
  "data": [
    {
      "xsrc": "harry11733:104:252717", 
      "x": [2.581, 2.938, 3.339, -3.519, 1.569, -2.213, -2.386, 1.251, -2.036, -2.262, 0.142, -3.495, 0.565, -1.11, 3.814, -2.073, 0.254, -2.561, 1.673, -2.177, -2.838, -3.564, -0.189, -0.296, 0.715, -1.745, -2.514, 0.333, -0.397, -3.26, -3.119, -1.496, -2.838, -2.382, 0.407, -3.403, -2.991, -3.71, -3.866, -0.962, 2.092, -3.539, 0.042, -3.736, -0.612, 2.218, -0.93, -2.541, 0.224, -1.238], 
      "ysrc": "harry11733:104:43ceab", 
      "y": [-0.647, -0.562, -1.806, 1.801, -3.788, 1.625, 3.066, 1.058, 0.229, 2.665, -3.31, -2.804, 2.779, 1.227, -2.456, 2.26, 0.285, 1.545, -1.521, -1.615, 0.249, 3.565, -0.077, -3.53, -0.17, -3.047, 2.542, 3.559, 1.418, -0.38, 2.108, -3.586, -3.683, 1.223, -3.411, 3.84, -0.63, 1.042, -3.569, -1.642, -0.387, 3.419, -1.724, 0.361, -3.136, 2.435, -2.311, 3.321, 0.959, 0.993]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:6873e6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136], 
      "ysrc": "harry11733:104:ef0eb3", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788]
    }
  ], 
  "name": 136, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame138 = {
  "data": [
    {
      "xsrc": "harry11733:104:8c5319", 
      "x": [2.559, 3.076, 3.311, -3.71, 1.379, -2.304, -2.089, 1.499, -2.333, -2.015, 0.683, -3.787, 0.323, -1.333, 3.673, -1.979, -0.602, -2.215, 1.314, -2.201, -2.941, -3.847, 0.037, -0.218, 0.8, -1.581, -2.444, 0.052, -0.43, -3.079, -3.082, -1.342, -2.962, -1.75, 0.669, -3.73, -2.672, -3.81, -3.706, -1.051, 2.115, -3.312, 0.118, -3.594, -0.9, 2.503, -0.859, -2.458, 0.296, -0.906], 
      "ysrc": "harry11733:104:bad83b", 
      "y": [-0.3, -0.362, -1.467, 1.375, -3.704, 1.542, 3.03, 1.098, 0.326, 2.194, -3.815, -2.586, 3.482, 0.954, -2.628, 2.778, 0.124, 1.828, -1.607, -1.482, 0.111, 3.635, -0.221, -3.478, 0.094, -3.019, 2.549, 3.854, 1.327, -0.426, 1.952, -3.741, -3.125, 1.109, -3.48, 3.26, -0.509, 0.98, -3.365, -1.644, -0.562, 3.238, -1.601, 0.54, -3.133, 2.785, -2.113, 3.308, 1.214, 0.996]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ac1ca6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137], 
      "ysrc": "harry11733:104:c54f0b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586]
    }
  ], 
  "name": 137, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame139 = {
  "data": [
    {
      "xsrc": "harry11733:104:001a0a", 
      "x": [2.655, 3.654, 3.143, -3.8, 1.161, -2.879, -2.123, 1.347, -3.001, -2.088, 0.252, -3.811, 0.178, -1.151, 3.393, -1.566, -0.87, -1.771, 1.02, -2.157, -2.936, -3.742, 0.027, -0.133, 1.047, -1.475, -2.453, 0.563, -0.624, -3.103, -2.955, -1.861, -2.791, -2.067, 0.598, -3.287, -2.433, -3.466, -3.447, -1.427, 2.296, -3.54, 0.241, -3.42, -1.225, 2.616, -0.539, -2.12, -0.195, -1.43], 
      "ysrc": "harry11733:104:da5b7c", 
      "y": [-0.32, -1.018, -2.243, 1.725, -3.36, 1.777, 2.971, 1.026, 0.326, 2.34, -3.624, -2.455, 3.741, 1.626, -2.619, 2.932, 0.707, 1.901, -1.549, -0.84, 0.107, 3.842, -0.432, -3.227, -0.438, -3.121, 2.791, 3.769, 1.317, -0.384, 1.601, -3.687, -3.743, 1.355, -3.639, 2.895, -0.637, 1.06, -3.134, -1.976, -0.55, 3.041, -1.65, 0.944, -3.585, 2.722, -1.972, 3.414, 1.294, 1.171]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:7a4e3f", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138], 
      "ysrc": "harry11733:104:21c27e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832]
    }
  ], 
  "name": 138, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame140 = {
  "data": [
    {
      "xsrc": "harry11733:104:bc9920", 
      "x": [2.073, 3.728, 3.134, -3.516, 1.081, -2.723, -1.965, 1.083, -3.049, -2.039, 0.269, -3.834, 0.255, -1.173, 3.68, -1.656, -0.612, -1.576, 0.875, -2.056, -2.964, -3.48, 0.513, 0.088, 0.928, -1.581, -2.331, -0.219, -0.653, -3.202, -2.913, -1.274, -3.209, -2.031, 0.874, -3.709, -2.362, -3.866, -3.555, -1.015, 2.316, -3.741, 0.139, -3.435, -1.759, 2.617, -0.861, -1.487, -0.639, -1.631], 
      "ysrc": "harry11733:104:f8dee7", 
      "y": [0.354, -0.773, -2.297, 1.437, -3.228, 1.246, 3.364, 0.619, 0.18, 1.999, -3.336, -2.365, 3.58, 1.695, -3.259, 2.252, 0.694, 1.632, -1.507, -0.542, -0.459, 3.373, -0.629, -3.187, -0.463, -3.139, 3.054, 3.755, 1.046, -0.601, 1.578, -3.378, -3.727, 1.673, -3.767, 3.211, -0.226, 1.35, -2.467, -2.168, -0.601, 2.786, -1.628, 1.511, -3.65, 3.109, -1.812, 3.107, 1.451, 0.718]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b352fc", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139], 
      "ysrc": "harry11733:104:a82e2b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796]
    }
  ], 
  "name": 139, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame141 = {
  "data": [
    {
      "xsrc": "harry11733:104:529328", 
      "x": [2.1, 3.858, 3.595, -3.306, 1.087, -2.583, -1.816, 1.222, -2.706, -2.563, 0.514, -3.859, 0.372, -1.311, 3.42, -1.132, -0.543, -1.313, 0.583, -2.206, -2.658, -3.652, 0.523, 0.422, 0.532, -1.641, -2.708, -0.103, -0.629, -3.036, -2.725, -1.587, -2.808, -1.631, 0.939, -3.581, -2.397, -3.502, -3.486, -1.057, 2.406, -3.657, 0.173, -3.629, -1.741, 2.638, -0.742, -1.319, -0.713, -1.492], 
      "ysrc": "harry11733:104:ae26c9", 
      "y": [0.25, -0.046, -2.97, 1.729, -3.125, 1.537, 3.442, 0.58, 0.745, 2.372, -3.604, -2.011, 3.351, 1.703, -2.917, 2.055, 0.572, 1.611, -1.743, -0.638, -0.986, 3.22, -0.756, -3.149, -0.038, -3.079, 3.559, 3.829, 1.137, -0.781, 1.577, -3.141, -3.585, 1.758, -3.597, 2.962, 0.31, 1.209, -2.325, -1.768, -0.5, 3.064, -1.5, 1.215, -3.187, 3.296, -1.816, 3.347, 1.505, 0.701]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b9bee5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140], 
      "ysrc": "harry11733:104:044c97", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58]
    }
  ], 
  "name": 140, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame142 = {
  "data": [
    {
      "xsrc": "harry11733:104:a5c668", 
      "x": [2.075, 3.804, 3.57, -3.784, 1.091, -2.506, -1.637, 1.34, -2.542, -2.442, 0.602, -3.751, 0.51, -1.262, 3.798, -1.584, -0.395, -1.391, 0.539, -2.216, -2.441, -3.787, 0.701, 0.707, 0.568, -2.082, -2.135, -0.202, -1.023, -2.902, -2.609, -2.151, -3.15, -1.749, 0.544, -3.427, -3.315, -3.689, -3.693, -1.0, 2.274, -3.803, 0.362, -3.771, -1.143, 2.3, -0.653, -1.803, -1.078, -1.296], 
      "ysrc": "harry11733:104:86de0c", 
      "y": [-0.187, 0.119, -2.958, 1.576, -3.129, 1.08, 3.654, 0.966, 0.777, 2.309, -3.342, -2.178, 3.456, 1.677, -3.268, 2.323, 0.362, 1.472, -1.242, -0.598, -1.021, 3.377, -0.456, -3.691, 0.083, -2.918, 3.352, 3.827, 1.726, -1.242, 1.825, -3.435, -3.546, 1.859, -3.531, 3.476, 0.635, 1.424, -2.466, -1.241, -0.126, 2.944, -1.202, 0.731, -2.917, 3.128, -1.72, 3.263, 1.76, 0.817]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0b8969", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141], 
      "ysrc": "harry11733:104:2c9275", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578]
    }
  ], 
  "name": 141, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame143 = {
  "data": [
    {
      "xsrc": "harry11733:104:9fe583", 
      "x": [1.942, 3.756, 3.168, -3.43, 0.85, -2.405, -1.652, 1.549, -2.243, -2.618, -0.038, -3.65, -0.186, -0.968, 3.786, -1.771, -0.485, -2.09, 0.258, -1.611, -1.947, -3.747, 0.667, 0.689, 0.522, -1.963, -2.043, -0.187, -0.638, -3.234, -2.395, -2.233, -3.277, -1.272, 1.007, -3.707, -3.404, -3.318, -3.501, -0.944, 2.846, -3.859, 0.223, -3.488, -0.893, 2.41, -0.646, -2.088, -0.783, -1.91], 
      "ysrc": "harry11733:104:49bdd6", 
      "y": [-0.217, 0.026, -3.234, 1.439, -3.059, 0.494, 3.769, 1.259, 1.018, 2.382, -3.29, -2.54, 3.541, 1.239, -3.311, 2.091, 0.538, 1.523, -1.167, -0.435, -1.264, 3.113, -0.479, -3.693, -0.031, -3.525, 3.468, 3.355, 1.714, -0.999, 1.944, -3.456, -3.696, 2.29, -3.634, 3.368, 0.903, 1.463, -2.871, -0.537, -0.706, 2.628, -0.818, 1.001, -2.359, 3.418, -1.933, 3.092, 1.897, 0.874]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:1035c4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142], 
      "ysrc": "harry11733:104:7ab0e3", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836]
    }
  ], 
  "name": 142, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame144 = {
  "data": [
    {
      "xsrc": "harry11733:104:b66bee", 
      "x": [1.863, 3.298, 3.313, -3.476, 0.502, -2.03, -1.202, 2.015, -2.351, -2.495, 0.21, -3.619, -0.017, -0.678, 3.819, -1.571, -0.06, -1.714, 0.248, -2.077, -1.902, -3.81, 0.413, 0.681, 0.845, -1.439, -2.504, 0.125, -0.346, -2.651, -2.509, -2.694, -3.139, -1.022, 0.945, -3.74, -3.33, -3.176, -3.075, -0.328, 2.753, -3.839, 0.538, -3.046, -0.646, 2.592, -0.302, -1.913, -0.764, -2.141], 
      "ysrc": "harry11733:104:6a130c", 
      "y": [-0.347, 0.2, -3.23, 1.657, -3.07, 1.035, 3.431, 1.51, 1.022, 2.892, -3.603, -2.463, 3.73, 1.652, -3.465, 2.114, 0.37, 1.67, -1.745, -0.585, -0.94, 2.993, -0.1, -3.324, 0.236, -3.753, 3.227, 3.378, 2.087, -0.396, 1.706, -3.533, -3.652, 2.657, -3.775, 2.987, 1.017, 1.318, -3.405, -1.137, -0.182, 2.821, -1.08, 1.596, -2.268, 2.799, -1.879, 3.266, 1.561, 0.721]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:beb652", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143], 
      "ysrc": "harry11733:104:8dc6f9", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594]
    }
  ], 
  "name": 143, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame145 = {
  "data": [
    {
      "xsrc": "harry11733:104:760bfa", 
      "x": [2.314, 3.672, 3.348, -3.677, 0.445, -1.888, -1.729, 2.32, -1.905, -2.328, 0.212, -3.453, -0.197, -0.877, 3.697, -1.159, -0.547, -1.801, 0.373, -2.571, -2.28, -3.505, 0.932, 0.567, 0.6, -1.394, -2.493, 0.275, -0.606, -2.672, -2.225, -2.22, -3.364, -0.822, 1.041, -3.757, -3.337, -3.426, -3.137, -0.219, 3.265, -3.591, 0.522, -3.232, -0.625, 2.227, -0.498, -2.345, -0.725, -2.384], 
      "ysrc": "harry11733:104:0e43d6", 
      "y": [0.197, 0.352, -3.066, 1.818, -3.4, 1.348, 3.224, 1.472, 0.986, 2.211, -3.349, -2.448, 3.8, 2.077, -3.243, 1.717, 0.549, 1.593, -1.593, -0.7, -0.793, 3.061, 0.183, -3.122, 0.129, -3.858, 3.607, 3.101, 2.335, -0.546, 1.74, -3.506, -3.301, 2.638, -3.865, 2.957, 0.353, 0.832, -3.334, -1.323, -0.416, 2.664, -1.282, 1.334, -1.645, 2.882, -2.087, 3.719, 1.785, 0.882]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e78183", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144], 
      "ysrc": "harry11733:104:210c6a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888]
    }
  ], 
  "name": 144, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame146 = {
  "data": [
    {
      "xsrc": "harry11733:104:acb276", 
      "x": [2.528, 3.638, 3.499, -3.32, 0.409, -1.473, -1.783, 2.23, -1.807, -2.005, 0.301, -3.576, -0.337, -0.481, 3.574, -0.425, -0.512, -1.59, 0.877, -2.691, -2.394, -3.368, 1.141, 0.246, 0.437, -1.497, -2.583, 0.177, -0.365, -2.664, -2.261, -2.017, -3.155, -0.455, 0.775, -3.148, -3.311, -3.262, -3.018, -0.664, 3.036, -3.746, 0.337, -3.433, -0.534, 2.2, -0.402, -2.433, -1.439, -2.435], 
      "ysrc": "harry11733:104:a40293", 
      "y": [-0.191, 0.654, -2.984, 1.915, -3.308, 1.596, 3.134, 2.129, 1.459, 2.646, -3.239, -2.107, 3.803, 2.113, -3.256, 2.372, 0.601, 1.558, -1.485, -1.069, -0.804, 2.977, 0.038, -2.625, -0.068, -3.652, 3.807, 2.633, 2.678, -0.494, 1.773, -3.527, -3.356, 2.362, -3.672, 3.121, 0.486, 0.288, -3.465, -0.697, -0.09, 3.014, -1.07, 1.522, -1.496, 2.521, -2.08, 3.864, 1.507, 0.836]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:65c388", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145], 
      "ysrc": "harry11733:104:e97a94", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976]
    }
  ], 
  "name": 145, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame147 = {
  "data": [
    {
      "xsrc": "harry11733:104:a50275", 
      "x": [2.154, 3.651, 3.583, -3.515, -0.271, -1.023, -1.977, 1.924, -1.279, -1.287, 0.456, -3.555, -0.075, -0.519, 3.113, -0.159, -0.95, -1.743, 1.375, -2.624, -2.296, -3.482, 0.846, 0.296, 0.417, -1.782, -2.822, -0.333, -0.113, -2.678, -2.994, -1.306, -3.083, -0.452, 0.433, -3.161, -3.407, -2.916, -3.521, -0.6, 2.963, -3.734, -0.079, -3.232, -0.387, 2.056, 0.222, -2.472, -0.966, -2.312], 
      "ysrc": "harry11733:104:9807c1", 
      "y": [-0.116, 0.698, -2.992, 1.976, -3.43, 1.423, 3.011, 2.119, 1.501, 2.379, -3.19, -2.242, 3.549, 1.441, -3.119, 2.043, 1.005, 1.726, -1.139, -0.364, -1.259, 2.658, 0.378, -2.594, -0.206, -3.201, 3.862, 2.061, 2.715, 0.061, 1.671, -3.32, -3.346, 2.298, -3.668, 3.277, 0.367, 0.399, -3.522, -0.447, -0.433, 3.119, -1.251, 1.672, -1.56, 2.534, -2.531, 3.715, 1.782, 0.16]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:1f9d2e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146], 
      "ysrc": "harry11733:104:735bed", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028]
    }
  ], 
  "name": 146, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame148 = {
  "data": [
    {
      "xsrc": "harry11733:104:c2b3ca", 
      "x": [1.808, 3.413, 3.708, -3.851, -0.024, -0.637, -1.963, 2.133, -1.61, -1.582, 0.632, -3.5, -0.268, -0.211, 3.276, -0.065, -1.012, -1.943, 1.515, -2.653, -2.374, -3.661, 0.701, -0.256, 0.28, -1.896, -2.761, -0.124, -0.094, -2.499, -3.109, -1.516, -3.016, -0.709, 1.033, -3.665, -2.865, -2.732, -3.543, -0.044, 2.947, -3.827, 0.036, -3.012, -0.897, 2.46, 0.219, -2.631, -0.935, -2.173], 
      "ysrc": "harry11733:104:93f62d", 
      "y": [-0.067, 0.233, -3.05, 2.02, -3.541, 1.554, 3.34, 2.192, 1.583, 2.477, -3.352, -2.036, 3.835, 1.513, -3.439, 2.546, 1.184, 1.978, -1.396, -0.64, -1.018, 2.127, 0.329, -2.802, -0.583, -3.595, 3.819, 1.609, 2.774, 0.166, 1.235, -3.177, -3.586, 2.094, -3.767, 2.919, 0.69, 0.276, -3.308, -0.233, -0.33, 2.995, -1.626, 1.578, -1.611, 2.113, -2.321, 3.821, 2.191, 0.614]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:37e968", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147], 
      "ysrc": "harry11733:104:c0de29", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088]
    }
  ], 
  "name": 147, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame149 = {
  "data": [
    {
      "xsrc": "harry11733:104:f923b4", 
      "x": [1.298, 3.852, 3.432, -3.581, 0.571, 0.081, -1.231, 2.027, -1.408, -1.775, 0.56, -3.571, -0.323, 0.146, 3.492, -0.105, -0.925, -2.159, 1.819, -2.42, -1.934, -3.336, 0.822, 0.114, 0.674, -1.411, -3.152, -0.268, 0.23, -2.903, -3.829, -1.56, -2.759, -0.568, 0.57, -3.445, -3.223, -2.469, -3.27, 0.105, 2.605, -3.847, 0.184, -3.025, -1.056, 2.748, -0.058, -2.258, -1.067, -2.166], 
      "ysrc": "harry11733:104:86fca4", 
      "y": [0.25, -0.356, -3.383, 2.226, -3.65, 1.104, 3.679, 2.636, 1.22, 2.427, -3.556, -2.632, 3.223, 1.853, -3.279, 2.458, 1.108, 2.235, -1.152, -0.026, -1.052, 2.156, 0.088, -2.709, -0.645, -3.533, 3.776, 1.503, 2.38, 0.35, 0.614, -2.453, -3.816, 2.282, -3.427, 3.166, 1.085, 0.475, -3.194, -0.659, -0.475, 2.89, -1.779, 1.565, -1.751, 1.999, -1.831, 3.599, 2.25, 0.654]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:fe66cc", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148], 
      "ysrc": "harry11733:104:7f566a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012]
    }
  ], 
  "name": 148, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame150 = {
  "data": [
    {
      "xsrc": "harry11733:104:64cf17", 
      "x": [1.746, 3.465, 3.858, -3.723, 0.584, 0.647, -1.32, 2.049, -1.535, -1.813, 0.423, -3.323, -1.091, 0.124, 2.873, -0.193, -1.169, -1.721, 1.47, -2.552, -1.864, -3.211, 0.462, 0.214, -0.381, -1.367, -3.137, -0.182, -0.075, -3.633, -3.726, -1.12, -2.766, -0.479, 0.897, -3.14, -3.504, -2.379, -3.685, -0.114, 2.663, -3.779, -0.317, -3.091, -0.972, 2.355, 0.368, -2.298, -1.059, -1.922], 
      "ysrc": "harry11733:104:9dd133", 
      "y": [-0.073, 0.061, -2.924, 2.542, -3.656, 0.884, 3.654, 2.86, 1.336, 2.484, -3.333, -2.822, 3.2, 1.815, -2.864, 2.743, 1.133, 2.198, -1.359, 0.257, -0.77, 2.46, -0.143, -2.609, -0.018, -3.506, 3.809, 0.782, 1.738, 0.446, 0.574, -2.605, -3.682, 2.835, -3.083, 3.518, 0.676, 0.802, -3.118, -0.29, -0.312, 2.821, -2.187, 1.934, -1.692, 2.3, -1.821, 3.777, 2.516, 0.829]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:caf4d4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149], 
      "ysrc": "harry11733:104:a50799", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056]
    }
  ], 
  "name": 149, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame151 = {
  "data": [
    {
      "xsrc": "harry11733:104:2c210e", 
      "x": [1.852, 3.188, 3.66, -3.785, 0.578, 0.317, -0.983, 2.127, -1.614, -2.53, 0.658, -3.167, -1.321, -0.232, 3.202, -0.335, -1.211, -2.09, 1.484, -2.837, -2.323, -2.718, 0.592, -0.305, 0.049, -0.959, -2.99, -0.158, 0.35, -3.442, -3.06, -0.991, -2.251, 0.162, 0.669, -3.487, -3.309, -2.717, -3.489, -0.047, 2.37, -3.544, 0.272, -3.078, -1.094, 2.153, 0.102, -2.408, -1.031, -1.808], 
      "ysrc": "harry11733:104:8bf4c3", 
      "y": [0.061, 0.458, -2.573, 2.21, -3.604, 1.21, 3.611, 2.933, 1.691, 2.328, -3.67, -3.076, 3.019, 2.482, -3.072, 2.329, 0.435, 2.275, -1.058, -0.157, -1.362, 1.99, -0.398, -3.026, -0.46, -3.153, 3.725, 0.954, 1.573, 0.708, 0.78, -2.898, -3.173, 2.638, -2.549, 3.603, 0.44, 0.325, -3.436, -0.046, -0.349, 2.614, -1.987, 1.847, -1.826, 2.265, -1.524, 3.646, 2.48, 0.983]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:19e6dd", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150], 
      "ysrc": "harry11733:104:4be030", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148]
    }
  ], 
  "name": 150, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame152 = {
  "data": [
    {
      "xsrc": "harry11733:104:1e2359", 
      "x": [2.083, 3.259, 3.794, -3.8, 0.843, 0.246, -1.163, 2.044, -1.677, -2.704, 0.968, -3.259, -1.15, -0.837, 3.382, -0.188, -1.369, -1.631, 1.709, -2.723, -2.532, -2.7, 0.614, 0.163, 0.332, -0.596, -2.519, -0.409, 0.331, -3.619, -2.854, -1.316, -1.931, -0.569, 0.83, -3.594, -3.751, -3.225, -3.491, -0.529, 2.349, -3.449, 0.393, -2.977, -1.17, 1.393, 0.227, -2.601, -0.421, -1.836], 
      "ysrc": "harry11733:104:affe16", 
      "y": [0.021, 0.547, -2.657, 2.067, -3.377, 1.053, 3.625, 3.165, 1.561, 2.14, -3.664, -2.812, 3.801, 2.982, -3.073, 2.188, 0.453, 2.479, -1.458, 0.188, -1.071, 2.182, -0.596, -3.123, -0.461, -2.844, 3.84, 1.334, 1.149, 0.905, 0.457, -2.89, -2.751, 2.73, -2.938, 3.152, 0.441, 0.375, -3.574, -0.035, -0.352, 2.484, -2.012, 1.58, -2.077, 1.579, -1.306, 3.494, 2.266, 1.082]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:66881d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151], 
      "ysrc": "harry11733:104:df0149", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084]
    }
  ], 
  "name": 151, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame153 = {
  "data": [
    {
      "xsrc": "harry11733:104:903ae0", 
      "x": [2.405, 2.624, 3.861, -3.729, 0.807, 0.299, -0.978, 2.333, -1.776, -2.465, 0.866, -3.18, -1.005, -0.937, 3.46, -0.089, -1.451, -1.501, 1.858, -2.271, -2.691, -2.592, 0.436, 0.245, 0.25, -0.327, -3.0, -0.707, 0.282, -3.831, -3.125, -1.137, -2.023, -0.666, 0.693, -3.785, -3.842, -2.954, -3.422, 0.267, 2.437, -3.663, 0.183, -2.765, -1.052, 1.396, 0.291, -2.56, -0.337, -1.977], 
      "ysrc": "harry11733:104:5319d4", 
      "y": [0.381, 0.32, -2.493, 2.046, -3.513, 1.136, 3.709, 3.416, 2.206, 1.327, -3.832, -3.449, 3.763, 3.389, -2.856, 1.927, 0.674, 2.397, -2.103, 0.453, -1.35, 2.159, -0.58, -3.191, 0.016, -2.394, 3.467, 0.973, 0.8, 1.057, 0.315, -2.572, -2.702, 2.036, -2.622, 3.305, 0.908, 0.345, -3.254, 0.477, 0.171, 2.517, -1.798, 1.396, -1.971, 0.941, -1.377, 3.223, 2.41, 1.186]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f29e28", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152], 
      "ysrc": "harry11733:104:9212c0", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614]
    }
  ], 
  "name": 152, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame154 = {
  "data": [
    {
      "xsrc": "harry11733:104:34f807", 
      "x": [2.318, 3.036, 3.817, -3.409, 0.733, 0.255, -1.024, 2.51, -1.708, -2.437, 1.182, -3.08, -1.268, -0.764, 3.591, -0.309, -1.236, -1.716, 1.652, -2.407, -2.903, -1.849, 0.213, 0.394, 0.293, -0.166, -2.985, -0.895, 1.217, -3.778, -3.304, -1.069, -2.042, -1.315, 0.514, -3.778, -3.808, -2.714, -3.656, 0.036, 2.547, -3.6, 0.151, -3.064, -0.982, 1.241, 0.197, -3.032, -0.381, -2.477], 
      "ysrc": "harry11733:104:432d96", 
      "y": [0.443, 0.418, -2.576, 1.93, -3.214, 1.259, 3.664, 3.797, 2.227, 1.107, -3.463, -3.225, 3.834, 3.644, -3.786, 2.033, 0.567, 2.865, -1.929, 0.72, -1.616, 2.142, -0.715, -2.527, 0.181, -3.322, 3.261, 1.093, 0.218, 0.978, 0.276, -2.634, -2.34, 1.368, -2.582, 3.726, 0.924, -0.153, -3.039, 0.688, 0.255, 2.307, -1.552, 1.354, -2.019, 1.149, -1.405, 3.298, 2.165, 1.052]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:3d6657", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153], 
      "ysrc": "harry11733:104:6f1f1a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616]
    }
  ], 
  "name": 153, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame155 = {
  "data": [
    {
      "xsrc": "harry11733:104:a13a1c", 
      "x": [1.714, 3.24, 3.765, -3.116, 0.784, -0.238, -1.675, 2.455, -1.725, -2.957, 1.574, -3.099, -0.883, -0.947, 3.462, -0.085, -0.908, -1.619, 1.225, -2.295, -3.031, -2.301, -0.055, -0.328, 0.181, -0.596, -2.503, -0.657, 1.48, -3.563, -3.529, -1.353, -2.091, -1.682, 0.07, -3.762, -3.709, -2.233, -3.463, 0.297, 2.476, -3.705, 0.92, -3.197, -1.088, 1.287, 0.949, -3.092, -0.13, -2.035], 
      "ysrc": "harry11733:104:94a54d", 
      "y": [0.412, 0.349, -2.258, 2.036, -3.395, 1.21, 3.799, 3.631, 1.923, 0.73, -3.649, -3.493, 3.648, 3.736, -3.221, 1.509, 0.394, 2.791, -1.753, 0.662, -0.878, 2.31, -0.41, -2.375, -0.165, -3.016, 3.039, 0.864, -0.056, 1.003, 0.393, -2.972, -1.999, 1.596, -2.902, 3.802, 0.547, -0.14, -2.787, 0.427, 0.387, 2.473, -1.538, 1.391, -1.889, 0.7, -1.185, 3.592, 2.371, 1.124]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:70d7e1", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154], 
      "ysrc": "harry11733:104:dbb983", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204]
    }
  ], 
  "name": 154, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame156 = {
  "data": [
    {
      "xsrc": "harry11733:104:d6d9ee", 
      "x": [2.366, 2.903, 3.752, -3.32, 0.739, -0.256, -1.815, 2.328, -1.883, -3.151, 1.155, -2.809, -0.468, -1.296, 3.422, -0.037, -0.682, -1.878, 1.067, -2.566, -2.973, -2.403, 0.125, -0.124, 0.461, -1.052, -2.6, -0.753, 1.755, -3.484, -3.476, -2.011, -1.523, -1.871, -0.41, -3.595, -3.23, -2.078, -3.666, -0.069, 2.579, -3.314, 0.601, -2.922, -0.887, 1.506, 1.156, -3.602, -0.422, -1.281], 
      "ysrc": "harry11733:104:4ead04", 
      "y": [0.232, 0.734, -2.663, 1.941, -3.144, 0.977, 3.791, 3.789, 2.149, 0.921, -3.646, -3.35, 3.322, 3.328, -3.051, 1.564, 0.75, 2.866, -2.01, 0.249, -0.628, 2.369, -0.492, -1.971, -0.54, -2.778, 2.985, 0.97, -0.532, 0.404, 0.699, -2.501, -1.828, 1.828, -2.695, 3.502, 0.555, 0.012, -3.147, 0.42, 0.1, 2.395, -1.218, 1.009, -2.082, 0.385, -1.586, 3.75, 2.581, 1.613]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:45150c", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155], 
      "ysrc": "harry11733:104:fb477b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248]
    }
  ], 
  "name": 155, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame157 = {
  "data": [
    {
      "xsrc": "harry11733:104:17f5f9", 
      "x": [3.201, 3.161, 3.408, -3.093, 0.974, -0.412, -1.549, 2.072, -1.944, -2.983, 1.03, -3.503, -0.406, -1.149, 3.008, -0.282, -0.897, -1.558, 1.096, -1.846, -2.864, -2.574, -0.149, -0.484, 0.213, -1.036, -3.114, -0.563, 1.73, -3.69, -3.533, -1.91, -1.136, -1.52, -0.702, -3.749, -3.797, -2.038, -3.718, 0.134, 2.775, -3.65, 0.666, -3.0, -0.738, 1.404, 1.364, -3.368, -0.006, -1.254], 
      "ysrc": "harry11733:104:510485", 
      "y": [0.194, 0.478, -2.326, 2.097, -3.307, 0.925, 3.438, 3.747, 2.204, 0.632, -3.65, -2.945, 2.867, 3.717, -2.991, 1.479, 0.726, 2.696, -1.663, 0.374, -0.664, 2.099, -0.614, -2.239, -0.612, -2.931, 3.167, 1.324, -0.162, 0.422, 0.791, -2.436, -1.736, 1.406, -2.533, 3.84, 0.814, -0.001, -2.701, 0.135, 0.054, 2.45, -0.942, 0.991, -1.647, 0.783, -1.558, 3.853, 2.529, 1.611]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:163cb5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156], 
      "ysrc": "harry11733:104:a30c49", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256]
    }
  ], 
  "name": 156, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame158 = {
  "data": [
    {
      "xsrc": "harry11733:104:e4c90c", 
      "x": [3.318, 3.097, 3.144, -3.443, 1.175, -0.223, -1.709, 1.894, -1.686, -2.514, 1.199, -3.403, -0.301, -1.022, 3.494, -0.781, -0.421, -1.191, 1.205, -1.314, -2.826, -2.998, 0.555, -0.399, 0.467, -0.952, -3.361, -0.678, 2.001, -3.844, -2.978, -1.967, -1.018, -2.12, -1.163, -3.673, -3.78, -2.237, -2.981, -0.324, 2.245, -3.07, 1.37, -3.26, -0.551, 1.569, 1.114, -2.87, -0.258, -1.21], 
      "ysrc": "harry11733:104:234d15", 
      "y": [-0.016, 0.903, -2.575, 2.039, -3.36, 1.13, 3.497, 3.575, 1.778, 0.106, -3.712, -2.834, 3.13, 3.688, -2.844, 0.974, 0.66, 2.385, -1.183, 0.847, -0.686, 2.399, -0.372, -1.869, -0.319, -2.703, 2.862, 1.39, -0.504, 0.164, 0.938, -2.736, -1.545, 1.754, -2.546, 3.792, 0.648, -0.07, -2.712, 0.322, -0.028, 2.232, -0.838, 1.078, -1.682, 1.521, -1.6, 3.539, 2.271, 1.309]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f61ccc", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157], 
      "ysrc": "harry11733:104:05b665", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392]
    }
  ], 
  "name": 157, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame159 = {
  "data": [
    {
      "xsrc": "harry11733:104:5e3a75", 
      "x": [3.423, 3.163, 3.246, -3.725, 1.025, -0.521, -1.224, 1.58, -2.269, -2.425, 1.464, -3.435, 0.324, -1.056, 3.552, -1.091, -0.138, -0.916, 1.227, -1.09, -2.537, -2.744, 0.175, -0.331, 0.251, -0.802, -2.99, -1.235, 1.922, -3.827, -3.396, -2.266, -0.947, -1.399, -0.946, -3.686, -3.74, -2.383, -3.027, -0.085, 2.344, -3.068, 0.904, -3.604, -0.882, 1.58, 1.19, -2.949, 0.162, -1.311], 
      "ysrc": "harry11733:104:61a401", 
      "y": [0.333, 1.007, -2.491, 1.438, -3.52, 0.834, 3.507, 3.663, 1.75, -0.481, -3.62, -2.494, 3.29, 3.654, -3.304, 0.659, 0.597, 2.182, -1.316, 0.987, -1.746, 2.435, -0.769, -2.142, -0.71, -2.713, 2.944, 1.301, -0.538, 0.048, 1.166, -3.499, -1.349, 2.076, -2.342, 3.563, 0.552, -0.45, -2.248, 0.856, 0.275, 2.759, -0.606, 0.728, -1.617, 1.798, -1.576, 3.621, 2.584, 1.842]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f6d8d4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158], 
      "ysrc": "harry11733:104:f45e09", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368]
    }
  ], 
  "name": 158, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame160 = {
  "data": [
    {
      "xsrc": "harry11733:104:f2fc63", 
      "x": [3.725, 2.605, 3.349, -3.781, 0.468, -0.573, -1.278, 1.641, -2.35, -2.152, 1.4, -3.392, -0.087, -1.364, 3.853, -0.896, -0.078, -0.702, 1.522, -1.423, -2.804, -2.267, 0.111, -0.363, 0.283, -0.993, -3.603, -1.597, 2.103, -3.73, -3.441, -2.24, -1.228, -1.633, -0.729, -3.83, -3.792, -2.382, -3.392, -0.161, 2.745, -2.993, 0.931, -3.535, -0.847, 1.338, 1.294, -3.184, -0.548, -1.384], 
      "ysrc": "harry11733:104:c2ec02", 
      "y": [0.215, 1.168, -2.087, 1.52, -3.846, 1.302, 3.288, 3.803, 1.591, -0.176, -3.329, -2.665, 3.354, 3.722, -3.343, 0.791, 0.966, 2.232, -1.509, 1.088, -2.725, 2.451, -0.991, -2.031, -0.707, -3.02, 2.926, 1.618, -0.918, 0.328, 1.344, -3.37, -0.729, 2.613, -2.302, 3.758, 0.428, -0.061, -2.227, 0.984, 0.666, 3.209, -0.461, 0.739, -1.87, 1.735, -1.581, 3.576, 2.61, 2.094]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:dec2a6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159], 
      "ysrc": "harry11733:104:193e7e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392]
    }
  ], 
  "name": 159, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame161 = {
  "data": [
    {
      "xsrc": "harry11733:104:b46b52", 
      "x": [3.774, 2.494, 3.452, -3.782, 0.225, -0.208, -1.048, 2.094, -2.559, -1.836, 1.08, -3.085, -0.928, -1.568, 3.139, -1.054, -0.054, -0.684, 1.874, -1.358, -2.467, -2.239, 0.094, -0.562, 0.481, -1.252, -3.029, -2.366, 1.969, -3.369, -3.508, -1.927, -0.692, -1.685, -0.868, -3.829, -3.578, -2.47, -3.36, -0.136, 2.764, -3.222, 1.014, -3.408, -0.943, 1.786, 0.979, -3.515, -0.623, -1.262], 
      "ysrc": "harry11733:104:87b433", 
      "y": [0.649, 0.5, -2.156, 1.572, -3.826, 1.217, 3.184, 3.657, 1.76, -0.317, -3.385, -2.504, 2.857, 3.54, -2.996, -0.109, 0.903, 2.129, -1.188, 1.416, -2.572, 2.606, -1.339, -2.325, -0.773, -3.184, 2.506, 1.472, -0.504, 0.862, 1.168, -3.814, -0.841, 3.04, -2.215, 3.584, 0.038, 0.175, -2.366, 1.574, 0.615, 3.561, -0.307, 1.103, -1.757, 2.02, -1.809, 3.86, 2.809, 2.091]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:78c8c1", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160], 
      "ysrc": "harry11733:104:b56611", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484]
    }
  ], 
  "name": 160, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame162 = {
  "data": [
    {
      "xsrc": "harry11733:104:bc313e", 
      "x": [3.838, 2.147, 3.014, -3.801, 0.418, -0.018, -0.676, 1.895, -2.782, -1.91, 0.708, -2.948, -1.258, -1.88, 3.17, -0.781, 0.214, -0.836, 2.344, -1.469, -2.714, -2.256, -0.245, -0.558, 0.847, -1.084, -2.896, -2.33, 1.703, -3.3, -3.631, -1.872, -0.52, -1.247, -0.566, -3.621, -3.548, -3.008, -3.217, 0.191, 2.738, -3.287, 0.981, -3.363, -0.753, 1.366, 0.965, -3.45, -0.255, -1.181], 
      "ysrc": "harry11733:104:04231d", 
      "y": [0.394, 0.761, -1.965, 1.782, -3.742, 1.14, 3.473, 3.417, 1.85, -0.322, -3.818, -2.553, 2.532, 3.275, -2.928, -0.416, 0.35, 2.633, -1.307, 1.243, -2.372, 2.706, -1.122, -2.83, -0.209, -3.636, 2.487, 1.528, -0.22, 0.827, 1.278, -3.694, -0.273, 3.388, -2.809, 3.705, 0.19, -0.148, -2.162, 1.595, 0.799, 3.552, -0.119, 0.422, -1.577, 2.016, -2.315, 3.544, 2.409, 1.97]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:be5980", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161], 
      "ysrc": "harry11733:104:7e3891", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404]
    }
  ], 
  "name": 161, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame163 = {
  "data": [
    {
      "xsrc": "harry11733:104:2f58f8", 
      "x": [3.718, 2.195, 2.585, -3.467, 0.168, -0.467, -0.69, 1.867, -2.942, -2.293, 0.722, -2.463, -1.348, -2.011, 3.772, -1.198, 0.606, -0.254, 2.349, -1.465, -2.513, -2.255, 0.006, -1.183, 0.714, -0.675, -3.18, -2.26, 1.273, -3.385, -3.735, -1.412, -0.635, -1.195, -0.153, -3.541, -3.24, -2.422, -3.052, 0.007, 2.888, -3.469, 1.426, -3.231, -0.802, 1.816, 1.133, -3.589, -0.159, -1.094], 
      "ysrc": "harry11733:104:0bef80", 
      "y": [0.473, 0.911, -2.114, 2.005, -3.587, 1.351, 3.794, 3.76, 1.643, 0.02, -3.392, -2.188, 2.611, 3.356, -2.766, -0.089, 0.348, 2.671, -1.395, 0.839, -2.149, 3.023, -1.033, -2.717, -0.08, -3.634, 2.479, 1.221, -0.478, 0.878, 1.335, -3.736, -0.358, 3.431, -2.442, 3.717, 0.094, -0.456, -1.354, 1.609, 1.014, 3.41, -0.274, 0.506, -1.484, 1.902, -2.536, 3.374, 2.681, 1.669]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:f4a9fe", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162], 
      "ysrc": "harry11733:104:bdefdc", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444]
    }
  ], 
  "name": 162, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame164 = {
  "data": [
    {
      "xsrc": "harry11733:104:cee9a9", 
      "x": [3.731, 2.234, 2.535, -3.401, 0.246, -0.598, -0.635, 1.578, -3.133, -2.876, 0.773, -2.858, -1.091, -2.045, 3.775, -1.234, 1.406, -0.038, 1.774, -1.315, -2.344, -2.316, 0.388, -1.471, 0.775, -1.271, -3.048, -2.262, 0.997, -3.579, -3.793, -1.151, -0.641, -1.431, -0.148, -3.11, -3.059, -2.316, -2.992, -0.256, 2.85, -3.614, 1.368, -3.019, -0.541, 1.58, 1.064, -3.698, -0.05, -0.918], 
      "ysrc": "harry11733:104:06cd31", 
      "y": [-0.085, 1.288, -2.789, 2.19, -2.803, 1.559, 3.716, 3.65, 2.005, -0.185, -3.519, -2.242, 2.011, 3.451, -2.245, -0.218, 1.25, 2.176, -1.619, 0.858, -2.158, 3.197, -0.971, -2.689, -0.004, -3.727, 2.521, 1.334, -0.576, 0.342, 1.336, -3.81, -0.101, 3.645, -2.502, 3.494, 0.081, -0.311, -0.873, 1.669, 1.227, 3.176, -1.038, 0.923, -1.959, 2.131, -2.255, 3.642, 2.378, 1.907]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:7a4fe5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163], 
      "ysrc": "harry11733:104:c8268b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584]
    }
  ], 
  "name": 163, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame165 = {
  "data": [
    {
      "xsrc": "harry11733:104:c4b4a0", 
      "x": [3.668, 2.267, 2.419, -3.313, 0.276, -0.892, -0.542, 1.46, -3.154, -2.905, 1.165, -2.828, -1.029, -1.56, 3.756, -1.393, 1.463, -0.149, 1.795, -0.946, -2.236, -2.299, -0.128, -2.105, 1.14, -1.511, -3.408, -2.566, 1.175, -3.515, -3.741, -0.922, -0.173, -1.5, -0.726, -2.755, -3.28, -2.61, -3.465, -0.688, 3.253, -3.653, 1.745, -2.324, -0.243, 1.797, 0.665, -3.269, -0.28, -0.893], 
      "ysrc": "harry11733:104:6e5490", 
      "y": [0.043, 1.529, -3.095, 2.155, -3.407, 1.356, 3.797, 3.409, 2.132, -0.278, -3.003, -2.048, 2.579, 3.437, -2.564, -0.169, 1.082, 2.638, -1.594, 0.621, -2.067, 3.018, -1.469, -2.789, 0.133, -3.755, 2.616, 1.191, -0.309, 0.425, 1.482, -3.863, 0.484, 3.34, -2.722, 3.428, 0.024, -0.11, -0.831, 1.534, 1.051, 3.012, -0.763, 0.845, -2.006, 2.449, -2.037, 3.449, 2.228, 1.709]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:801c8e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164], 
      "ysrc": "harry11733:104:a74197", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664]
    }
  ], 
  "name": 164, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame166 = {
  "data": [
    {
      "xsrc": "harry11733:104:233a71", 
      "x": [3.616, 2.042, 2.09, -3.394, 0.366, -0.401, -0.984, 1.432, -3.303, -3.248, 0.985, -3.155, -1.191, -1.956, 3.813, -1.375, 1.752, -0.143, 1.978, -0.967, -2.467, -2.918, -0.841, -2.347, 1.225, -1.248, -2.721, -3.451, 1.139, -3.308, -3.459, -1.049, -0.324, -0.926, -0.584, -3.33, -3.474, -2.479, -3.699, -0.974, 2.833, -3.394, 1.395, -1.995, 0.26, 1.412, 0.194, -3.238, -0.325, -0.543], 
      "ysrc": "harry11733:104:41c8fb", 
      "y": [-0.298, 1.534, -3.409, 2.217, -2.886, 1.87, 3.785, 3.36, 1.948, 0.394, -3.242, -1.645, 2.812, 3.301, -2.32, 0.002, 1.452, 2.548, -1.307, 0.507, -2.277, 2.321, -1.962, -2.332, 0.179, -3.75, 3.082, 1.588, -0.269, 0.482, 1.595, -3.769, 0.209, 3.512, -2.776, 3.474, -0.224, -0.266, -0.869, 1.556, 0.871, 3.462, -0.764, 0.795, -2.328, 2.548, -2.027, 3.741, 2.158, 1.584]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:e53ba4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165], 
      "ysrc": "harry11733:104:6a17e6", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644]
    }
  ], 
  "name": 165, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame167 = {
  "data": [
    {
      "xsrc": "harry11733:104:78cc21", 
      "x": [3.514, 1.593, 1.838, -3.311, 0.148, 0.112, -0.598, 1.128, -3.331, -2.682, 0.89, -3.022, -1.24, -2.174, 3.28, -1.204, 1.474, 0.026, 1.979, -0.685, -2.282, -2.687, -1.021, -2.716, 1.038, -0.692, -2.695, -3.293, 1.011, -3.372, -3.699, -1.263, -0.501, -1.239, -0.739, -3.276, -3.351, -2.651, -3.575, -0.97, 2.84, -3.643, 1.792, -2.4, -0.223, 1.112, 0.12, -3.016, -0.072, -0.395], 
      "ysrc": "harry11733:104:dea852", 
      "y": [0.195, 1.436, -3.523, 1.849, -3.573, 1.762, 3.812, 3.749, 1.973, 0.734, -3.209, -1.414, 2.947, 3.522, -2.121, -0.392, 1.42, 3.065, -1.011, 0.432, -2.107, 2.106, -1.957, -1.602, 0.279, -3.469, 2.987, 1.683, -0.139, 0.607, 2.004, -3.788, 0.156, 3.751, -2.732, 3.218, -0.177, -0.117, -0.577, 1.593, 0.929, 3.28, -0.686, 0.149, -2.319, 2.772, -1.828, 3.635, 1.896, 1.471]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:2b3fc2", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166], 
      "ysrc": "harry11733:104:1b8a91", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656]
    }
  ], 
  "name": 166, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame168 = {
  "data": [
    {
      "xsrc": "harry11733:104:b6c4d4", 
      "x": [3.321, 1.818, 2.078, -3.298, 0.392, 0.138, -0.284, 0.644, -3.444, -2.377, 0.685, -2.966, -1.187, -1.766, 3.61, -1.88, 1.452, 0.044, 1.96, -1.16, -2.331, -2.555, -0.643, -2.667, 1.448, -1.098, -2.799, -3.22, 1.429, -3.712, -3.439, -1.219, -0.678, -1.121, -0.652, -2.743, -3.365, -2.555, -3.716, -1.206, 3.389, -3.844, 1.591, -2.28, -0.085, 1.254, 0.496, -3.03, 0.004, 0.123], 
      "ysrc": "harry11733:104:b88c0a", 
      "y": [0.33, 2.002, -3.645, 1.815, -3.846, 1.666, 3.763, 3.177, 2.013, 0.915, -2.533, -1.254, 2.665, 3.543, -2.071, -0.406, 1.144, 2.882, -0.977, 0.359, -1.948, 2.58, -1.74, -1.871, 0.466, -2.974, 2.812, 1.081, -0.184, 0.384, 1.724, -3.804, -0.184, 3.511, -3.034, 3.63, -0.36, -0.219, -1.274, 2.187, 0.964, 3.582, -0.627, 0.273, -2.684, 3.096, -2.413, 3.79, 1.712, 1.932]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:11a1d1", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167], 
      "ysrc": "harry11733:104:1ab5a8", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628]
    }
  ], 
  "name": 167, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame169 = {
  "data": [
    {
      "xsrc": "harry11733:104:cce219", 
      "x": [3.504, 2.183, 1.831, -3.393, 0.438, -0.033, -0.641, 0.267, -2.922, -2.692, 0.927, -3.033, -1.466, -2.133, 3.688, -2.277, 2.154, 0.278, 1.706, -0.78, -1.727, -2.361, -1.156, -2.565, 1.868, -1.574, -2.801, -3.329, 1.877, -3.766, -2.68, -1.006, -0.446, -1.263, -0.379, -2.708, -3.247, -2.456, -3.545, -1.097, 3.855, -3.556, 1.859, -2.382, -0.093, 1.013, 0.503, -3.167, 0.248, 0.005], 
      "ysrc": "harry11733:104:39e662", 
      "y": [-0.01, 1.125, -3.677, 2.146, -3.762, 1.79, 3.826, 3.09, 1.715, 0.686, -2.387, -1.258, 2.876, 3.674, -2.427, -0.646, 0.97, 2.921, -1.376, -0.017, -2.295, 2.36, -1.656, -1.432, 0.214, -2.684, 2.824, 1.163, 0.1, 0.348, 1.908, -3.496, -0.417, 3.585, -3.023, 3.186, -0.633, -0.074, -0.792, 1.757, 0.708, 3.799, -0.445, 0.23, -2.858, 3.277, -2.323, 3.628, 1.986, 2.369]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4db10d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168], 
      "ysrc": "harry11733:104:a0b372", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654]
    }
  ], 
  "name": 168, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame170 = {
  "data": [
    {
      "xsrc": "harry11733:104:b64a01", 
      "x": [3.588, 2.187, 2.085, -3.411, -0.068, 0.141, -0.493, 0.163, -3.375, -2.632, 0.937, -3.0, -1.585, -2.633, 3.835, -2.873, 2.14, 0.424, 1.489, -0.499, -1.694, -1.602, -0.967, -2.68, 2.065, -1.904, -2.168, -3.117, 1.745, -3.817, -2.665, -0.948, -0.168, -1.653, -0.175, -2.427, -3.161, -2.62, -3.495, -1.362, 3.784, -3.695, 1.888, -2.067, 0.019, 1.034, 0.277, -3.379, 0.171, -0.582], 
      "ysrc": "harry11733:104:0e3661", 
      "y": [-0.257, 0.995, -3.775, 1.72, -3.652, 1.851, 3.781, 3.111, 1.634, 1.163, -1.829, -1.248, 3.316, 3.684, -2.609, -0.23, 0.59, 2.821, -1.137, -0.072, -2.149, 2.238, -2.014, -1.568, -0.197, -2.563, 2.919, 1.197, -0.233, 1.307, 1.894, -3.048, -0.282, 3.586, -3.008, 3.265, -0.889, -0.027, -0.751, 1.776, 0.506, 3.733, -0.621, 0.549, -2.955, 3.087, -2.099, 3.377, 1.712, 1.944]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:899a1e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169], 
      "ysrc": "harry11733:104:94bd9e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672]
    }
  ], 
  "name": 169, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame171 = {
  "data": [
    {
      "xsrc": "harry11733:104:c7b145", 
      "x": [3.63, 2.068, 2.05, -3.392, -0.294, 0.407, -0.239, 0.04, -3.487, -1.818, 1.229, -3.304, -1.967, -2.525, 3.777, -2.272, 2.283, 0.104, 1.067, -0.784, -1.732, -1.576, -1.276, -2.643, 1.921, -1.784, -2.41, -3.247, 1.754, -3.64, -2.594, -0.612, -0.042, -1.782, -0.578, -2.467, -3.246, -2.607, -3.168, -1.31, 3.33, -3.636, 1.721, -2.42, 0.266, 1.069, 0.159, -3.403, 0.465, -0.209], 
      "ysrc": "harry11733:104:f91bce", 
      "y": [-0.36, 0.847, -3.435, 1.664, -3.683, 2.065, 3.348, 3.253, 1.983, 1.038, -2.017, -0.929, 3.291, 3.834, -2.739, 0.024, 0.496, 2.922, -1.213, -0.334, -1.913, 2.985, -1.848, -1.432, -0.494, -2.713, 2.766, 0.435, -0.31, 1.58, 2.336, -2.395, -0.492, 3.334, -2.856, 2.972, -0.693, -0.298, -1.294, 1.076, 0.406, 3.261, -0.435, 1.369, -2.692, 3.026, -2.254, 3.411, 1.566, 1.584]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:9ec6ac", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170], 
      "ysrc": "harry11733:104:3408d2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764]
    }
  ], 
  "name": 170, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame172 = {
  "data": [
    {
      "xsrc": "harry11733:104:face94", 
      "x": [3.808, 1.887, 2.138, -3.779, -0.53, 0.453, -0.164, -0.186, -2.744, -2.331, 1.501, -3.574, -2.275, -1.769, 3.78, -2.631, 2.182, -0.363, 1.151, -0.779, -1.36, -1.498, -0.829, -2.735, 1.798, -1.748, -2.566, -3.066, 1.347, -3.8, -2.249, -0.395, 0.133, -1.995, -0.869, -1.783, -3.452, -2.347, -2.928, -0.76, 3.633, -3.221, 1.886, -1.787, 0.023, 0.86, 0.479, -3.561, 0.329, -0.474], 
      "ysrc": "harry11733:104:c50565", 
      "y": [-0.502, 0.232, -3.727, 2.003, -3.283, 1.517, 3.138, 3.28, 1.883, 0.988, -2.402, -1.118, 3.3, 3.61, -3.02, 0.446, 0.749, 3.0, -1.349, -0.179, -1.631, 3.068, -2.165, -1.304, -0.476, -2.711, 3.219, 0.371, -0.292, 1.129, 2.25, -2.365, -0.383, 3.566, -2.746, 2.86, -0.388, -0.188, -1.142, 0.967, 0.346, 3.254, -0.271, 1.653, -3.039, 3.49, -2.151, 3.409, 1.669, 1.661]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:455ded", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171], 
      "ysrc": "harry11733:104:ccc506", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678]
    }
  ], 
  "name": 171, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame173 = {
  "data": [
    {
      "xsrc": "harry11733:104:43029f", 
      "x": [3.822, 2.041, 1.842, -3.313, -0.91, 0.268, -0.33, -0.078, -2.745, -2.17, 0.915, -3.774, -2.535, -2.027, 3.26, -2.808, 2.188, -1.023, 1.2, -0.816, -1.181, -1.392, -1.139, -3.18, 2.091, -1.74, -2.599, -2.964, 1.335, -3.782, -1.848, -0.194, -0.103, -2.167, -0.2, -1.914, -3.363, -2.53, -3.032, -0.572, 3.005, -2.931, 2.667, -1.551, -0.337, 0.759, 0.56, -3.348, -0.42, -0.568], 
      "ysrc": "harry11733:104:54bac5", 
      "y": [-0.669, 0.695, -3.391, 1.98, -3.5, 1.113, 2.962, 2.719, 2.224, 1.32, -2.485, -0.442, 3.447, 3.756, -3.349, 0.397, 0.615, 3.481, -1.441, -0.006, -1.936, 3.059, -2.268, -1.05, -0.88, -2.785, 3.553, 0.72, -0.664, 1.016, 2.223, -2.756, -0.534, 3.789, -2.73, 2.507, -0.657, -0.239, -1.98, 0.244, 0.178, 3.397, 0.09, 1.691, -2.532, 3.723, -2.598, 3.004, 1.549, 2.025]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:6c52e7", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172], 
      "ysrc": "harry11733:104:0d370e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682]
    }
  ], 
  "name": 172, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame174 = {
  "data": [
    {
      "xsrc": "harry11733:104:dd8358", 
      "x": [3.647, 2.203, 1.425, -2.937, -1.407, 0.096, -0.417, -0.25, -3.087, -2.017, 0.651, -3.812, -1.737, -1.582, 3.706, -2.665, 2.054, -1.437, 1.108, -0.461, -0.658, -1.411, -0.777, -2.575, 1.973, -2.19, -2.551, -2.946, 1.681, -3.555, -1.703, -0.623, -0.249, -1.788, 0.244, -1.775, -3.789, -2.666, -2.422, -0.709, 3.836, -3.379, 2.34, -1.936, -0.962, 1.029, 0.983, -3.366, -0.652, -0.795], 
      "ysrc": "harry11733:104:a25bfe", 
      "y": [-0.457, 0.197, -3.354, 1.569, -3.191, 1.379, 2.886, 2.823, 2.452, 1.627, -2.774, -0.046, 3.849, 3.576, -2.795, 0.364, 0.618, 3.816, -0.903, 0.336, -2.368, 2.84, -2.465, -1.145, -0.736, -2.915, 3.375, 0.375, -0.629, 1.006, 2.49, -3.077, -0.461, 3.757, -2.183, 2.881, -0.933, -0.617, -1.894, 0.731, -0.111, 3.407, -0.066, 1.426, -2.996, 3.864, -2.363, 3.119, 1.474, 2.316]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:650ef9", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173], 
      "ysrc": "harry11733:104:8475bf", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804]
    }
  ], 
  "name": 173, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame175 = {
  "data": [
    {
      "xsrc": "harry11733:104:ffed4a", 
      "x": [3.549, 2.622, 2.331, -3.031, -1.004, 0.048, -0.476, -0.277, -3.069, -2.248, 1.003, -3.748, -1.637, -1.247, 3.612, -2.523, 2.254, -1.795, 0.84, 0.041, -0.669, -1.452, -0.626, -2.703, 2.828, -2.622, -2.258, -2.756, 1.844, -3.779, -1.723, -0.457, -0.167, -1.171, -0.228, -1.924, -3.693, -3.14, -2.507, -0.914, 3.628, -3.572, 2.155, -1.99, -0.147, 0.813, 0.615, -3.847, -0.584, -0.621], 
      "ysrc": "harry11733:104:8ca181", 
      "y": [-0.726, -0.0, -3.733, 1.244, -2.797, 1.937, 2.687, 3.032, 2.303, 1.525, -2.542, 0.58, 3.866, 3.512, -2.048, 0.37, 1.245, 3.222, -0.885, 0.877, -2.181, 3.025, -1.701, -1.424, -0.723, -3.21, 3.302, 0.826, -0.361, 1.619, 2.426, -3.014, -0.567, 3.808, -1.939, 3.075, -0.248, -1.178, -1.448, 0.806, -0.109, 3.245, -0.206, 1.814, -3.647, 3.671, -2.689, 3.087, 1.676, 2.01]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:643130", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174], 
      "ysrc": "harry11733:104:f4d920", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864]
    }
  ], 
  "name": 174, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame176 = {
  "data": [
    {
      "xsrc": "harry11733:104:ee1ac1", 
      "x": [3.532, 2.334, 2.419, -2.614, -1.33, -0.13, -0.183, -0.134, -3.292, -1.962, 0.866, -3.695, -1.819, -2.022, 3.294, -2.581, 2.281, -1.963, 0.968, -0.585, -0.775, -1.995, -0.317, -3.07, 2.708, -2.406, -2.174, -2.724, 2.339, -3.269, -0.977, -0.054, 0.108, -1.034, 0.073, -1.722, -3.769, -3.275, -2.497, -0.537, 3.437, -3.808, 1.938, -2.095, -0.24, 0.888, 1.51, -3.727, -0.151, -0.948], 
      "ysrc": "harry11733:104:0e86cb", 
      "y": [-1.523, 0.14, -3.457, 1.53, -2.78, 2.525, 2.735, 2.608, 2.429, 1.443, -2.412, 0.204, 3.801, 3.472, -2.074, 0.362, 0.679, 3.157, -0.571, 0.993, -2.658, 2.761, -1.473, -1.555, -0.859, -3.783, 2.984, 0.443, -0.918, 1.284, 2.749, -3.055, -0.899, 3.864, -1.801, 2.979, -0.517, -0.8, -1.453, 0.887, -0.299, 3.589, -0.06, 1.775, -3.477, 3.77, -2.888, 3.452, 1.285, 2.27]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0af21d", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175], 
      "ysrc": "harry11733:104:727e07", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69]
    }
  ], 
  "name": 175, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame177 = {
  "data": [
    {
      "xsrc": "harry11733:104:d068b3", 
      "x": [3.842, 2.379, 2.47, -2.939, -1.767, -0.403, -0.225, 0.013, -2.839, -2.836, 0.659, -3.556, -2.009, -1.972, 3.282, -2.874, 2.33, -2.205, 0.878, -0.512, -0.677, -2.013, -0.193, -3.267, 2.773, -2.4, -2.314, -2.734, 2.308, -3.048, -1.239, -0.262, 0.849, -0.719, 0.055, -1.968, -3.83, -3.341, -2.806, -0.352, 3.09, -3.439, 2.24, -1.901, -0.364, 1.081, 1.445, -3.24, -0.064, -0.951], 
      "ysrc": "harry11733:104:80b406", 
      "y": [-1.122, 0.222, -3.443, 1.785, -3.011, 2.122, 2.327, 3.032, 2.594, 1.537, -2.407, 0.298, 3.668, 3.372, -2.364, 0.248, -0.282, 3.354, -0.194, 1.023, -2.398, 2.448, -1.543, -1.493, -0.986, -3.655, 2.66, 0.853, -0.877, 1.025, 2.824, -2.949, -0.366, 3.475, -1.628, 3.034, -0.398, 0.033, -1.79, 0.447, -0.923, 3.31, 0.441, 1.731, -3.792, 3.554, -3.116, 3.727, 1.47, 2.573]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:df311b", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176], 
      "ysrc": "harry11733:104:9b99af", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872]
    }
  ], 
  "name": 176, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame178 = {
  "data": [
    {
      "xsrc": "harry11733:104:b6c414", 
      "x": [3.496, 2.036, 2.638, -3.072, -1.864, -0.165, -0.47, 0.684, -2.675, -2.175, 0.54, -3.319, -2.021, -2.239, 3.248, -2.688, 1.914, -1.92, 0.837, -0.416, -0.793, -2.0, 0.281, -3.347, 2.621, -2.478, -2.207, -2.739, 2.26, -2.531, -1.036, 0.088, 0.828, -0.599, 0.496, -2.34, -3.814, -2.863, -2.548, -0.244, 3.288, -3.225, 2.011, -2.16, -0.512, 1.13, 1.41, -2.826, -0.158, -0.702], 
      "ysrc": "harry11733:104:3dfdc2", 
      "y": [-1.03, 0.685, -3.45, 2.017, -3.105, 2.304, 2.454, 2.749, 2.729, 1.66, -2.522, 0.279, 3.777, 3.76, -2.828, 0.424, -0.434, 3.64, -0.049, 1.236, -2.648, 2.4, -1.681, -1.501, -0.31, -3.813, 2.366, 1.225, -0.579, 1.6, 2.721, -3.274, 0.281, 3.435, -1.645, 3.449, -0.045, 0.048, -1.647, 0.852, -1.068, 3.18, 0.711, 1.669, -3.842, 3.347, -2.84, 3.721, 1.845, 2.412]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:bfddeb", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177], 
      "ysrc": "harry11733:104:6e2746", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844]
    }
  ], 
  "name": 177, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame179 = {
  "data": [
    {
      "xsrc": "harry11733:104:ccb631", 
      "x": [3.793, 1.925, 2.727, -3.483, -1.726, -0.265, 0.27, 0.918, -2.974, -2.504, 0.947, -3.237, -2.379, -2.195, 3.771, -2.803, 2.622, -2.257, 1.26, -0.578, -1.044, -2.262, 0.269, -3.471, 2.551, -2.833, -2.06, -2.574, 2.473, -2.583, -0.759, 0.352, 1.138, -0.527, 0.068, -2.55, -3.694, -2.952, -2.554, -0.615, 2.936, -2.748, 2.57, -2.72, 0.143, 1.34, 1.552, -2.327, -0.312, -0.554], 
      "ysrc": "harry11733:104:c2e0a9", 
      "y": [-1.275, 0.958, -3.601, 1.97, -3.133, 2.032, 2.004, 2.706, 2.876, 1.911, -2.498, 0.428, 3.694, 3.856, -2.928, 0.323, -0.462, 3.564, 0.107, 1.274, -2.901, 3.032, -2.125, -1.117, -0.166, -3.38, 2.372, 1.42, -0.71, 1.839, 2.221, -3.304, -0.065, 3.553, -1.558, 3.031, -0.466, 0.395, -1.346, 0.98, -1.289, 3.439, 0.312, 1.23, -3.803, 2.913, -3.144, 3.663, 1.274, 2.898]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:165c47", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178], 
      "ysrc": "harry11733:104:269342", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896]
    }
  ], 
  "name": 178, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame180 = {
  "data": [
    {
      "xsrc": "harry11733:104:aa2b0d", 
      "x": [3.847, 2.138, 2.673, -3.366, -1.743, -0.294, 0.401, 0.709, -2.553, -3.093, 0.902, -2.766, -2.388, -2.413, 3.865, -2.858, 2.967, -2.198, 0.8, -0.11, -1.214, -2.698, 0.124, -3.395, 2.128, -2.763, -1.873, -2.622, 2.418, -2.816, -0.5, 0.41, 1.111, -0.493, -0.107, -2.316, -3.859, -2.99, -2.738, -0.654, 2.528, -2.915, 2.623, -2.303, 0.861, 0.95, 1.321, -2.579, -0.388, -0.552], 
      "ysrc": "harry11733:104:a4507f", 
      "y": [-0.704, 1.198, -3.191, 2.195, -3.016, 1.997, 1.336, 2.531, 3.087, 2.212, -2.32, 0.46, 3.47, 3.745, -2.789, 0.549, -0.542, 3.652, -0.288, 1.422, -2.827, 2.933, -1.611, -1.388, -0.663, -3.692, 2.354, 1.288, -0.544, 2.048, 2.234, -3.74, 0.316, 3.653, -1.493, 2.166, -0.358, 0.701, -1.137, 1.327, -1.674, 3.655, 0.751, 1.487, -3.453, 2.191, -2.849, 3.47, 1.292, 2.58]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:9fd330", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179], 
      "ysrc": "harry11733:104:c900a2", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944]
    }
  ], 
  "name": 179, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame181 = {
  "data": [
    {
      "xsrc": "harry11733:104:2d1810", 
      "x": [3.86, 2.514, 2.814, -3.028, -1.775, 0.049, 0.738, 1.268, -2.538, -2.923, 0.825, -2.302, -2.131, -2.742, 3.676, -3.148, 3.414, -2.406, 1.151, 0.594, -1.495, -2.949, -0.023, -3.53, 2.294, -3.214, -1.729, -2.777, 1.868, -3.001, -0.142, 0.576, 1.068, -0.272, -0.227, -2.604, -3.812, -2.969, -2.798, 0.077, 2.788, -2.944, 2.631, -2.261, 0.676, 0.755, 1.129, -2.925, -0.548, -0.359], 
      "ysrc": "harry11733:104:e14619", 
      "y": [-0.484, 0.643, -3.084, 2.198, -3.08, 2.233, 1.899, 2.148, 3.019, 2.262, -2.471, 0.719, 3.752, 3.845, -2.68, 0.123, -0.4, 3.796, -0.524, 1.575, -3.003, 2.482, -1.515, -1.689, -0.694, -3.352, 2.702, 1.295, -0.103, 2.012, 2.378, -3.836, 0.374, 3.761, -1.148, 2.755, -0.547, 0.829, -1.012, 2.083, -1.85, 3.724, 0.841, 1.946, -3.57, 2.193, -3.333, 3.603, 1.242, 2.67]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a2fbd0", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180], 
      "ysrc": "harry11733:104:390717", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972]
    }
  ], 
  "name": 180, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame182 = {
  "data": [
    {
      "xsrc": "harry11733:104:701175", 
      "x": [3.731, 2.595, 2.656, -3.019, -1.844, -0.09, 0.646, 1.007, -2.725, -3.475, 0.894, -2.62, -1.798, -2.719, 3.51, -2.809, 3.754, -2.153, 1.401, 0.29, -1.239, -3.074, -0.495, -3.467, 1.981, -3.346, -1.752, -2.67, 1.803, -3.443, 0.079, 0.667, 1.456, -0.343, 0.204, -1.767, -3.786, -2.851, -2.638, 0.049, 3.007, -2.774, 2.957, -2.294, 0.855, 0.645, 1.061, -2.983, -0.611, -0.177], 
      "ysrc": "harry11733:104:90bd49", 
      "y": [0.236, 0.22, -3.283, 1.755, -3.357, 2.464, 1.716, 2.184, 2.876, 2.169, -2.389, 1.238, 3.463, 3.82, -2.685, 0.143, 0.081, 3.467, -0.311, 1.642, -2.302, 2.319, -1.214, -1.806, -0.957, -3.307, 2.164, 1.787, -0.048, 1.996, 2.557, -3.82, 0.397, 3.861, -1.197, 2.762, -0.195, 0.152, -1.985, 2.474, -1.454, 3.704, 0.759, 1.673, -3.442, 2.087, -2.986, 3.158, 1.264, 3.025]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:229649", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181], 
      "ysrc": "harry11733:104:8e10d3", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988]
    }
  ], 
  "name": 181, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame183 = {
  "data": [
    {
      "xsrc": "harry11733:104:fc9403", 
      "x": [3.824, 2.435, 2.604, -2.708, -2.085, -0.068, 0.294, 1.153, -3.292, -3.453, 0.836, -2.768, -1.236, -2.94, 3.782, -2.704, 3.846, -2.269, 2.023, 0.681, -1.184, -2.727, -0.813, -3.842, 1.177, -3.449, -1.831, -2.831, 1.835, -3.851, 0.498, 0.44, 1.361, -0.25, -0.25, -1.47, -3.392, -3.182, -2.834, 0.45, 3.155, -2.781, 2.574, -1.831, 0.906, 0.61, 0.682, -3.11, -0.51, -0.004], 
      "ysrc": "harry11733:104:ab330b", 
      "y": [0.585, -0.13, -3.537, 2.371, -2.971, 1.847, 1.887, 1.896, 2.73, 2.844, -2.46, 1.273, 3.304, 3.499, -2.319, -0.172, 0.041, 3.618, -0.805, 1.692, -2.524, 1.94, -1.167, -1.587, -0.931, -3.603, 1.735, 1.679, -0.049, 1.875, 2.309, -3.809, 0.752, 3.829, -1.205, 2.241, -0.244, -0.222, -2.19, 2.383, -1.647, 3.676, 0.845, 1.146, -3.77, 1.954, -2.79, 3.107, 1.459, 2.921]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:6cccb3", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182], 
      "ysrc": "harry11733:104:eea424", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702]
    }
  ], 
  "name": 182, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame184 = {
  "data": [
    {
      "xsrc": "harry11733:104:cbfcfd", 
      "x": [3.779, 2.514, 2.751, -3.064, -1.654, 0.151, 0.347, 1.533, -2.7, -2.763, 0.698, -2.719, -1.354, -3.076, 3.222, -2.731, 3.855, -1.564, 2.398, 0.486, -1.272, -2.882, -1.475, -3.154, 1.029, -3.68, -2.186, -2.947, 2.063, -3.657, 0.811, 0.459, 2.077, -0.261, -0.719, -1.424, -2.732, -3.586, -2.491, 0.407, 3.124, -3.136, 2.984, -2.38, 0.894, 0.694, 0.908, -3.1, -0.839, -0.074], 
      "ysrc": "harry11733:104:2bfedc", 
      "y": [0.586, 0.262, -3.328, 2.039, -2.708, 1.848, 1.85, 1.833, 3.08, 2.76, -2.206, 0.849, 3.03, 3.58, -2.731, -0.091, -0.165, 3.335, -1.374, 1.591, -2.515, 1.663, -1.449, -1.686, -0.828, -3.495, 1.582, 1.567, 0.294, 1.793, 2.419, -3.861, 0.886, 3.711, -0.895, 2.215, -0.392, -0.012, -2.058, 2.716, -1.838, 3.646, 1.289, 1.39, -3.717, 2.521, -2.788, 3.026, 1.806, 2.665]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:a3bbe8", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183], 
      "ysrc": "harry11733:104:192798", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116]
    }
  ], 
  "name": 183, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame185 = {
  "data": [
    {
      "xsrc": "harry11733:104:fc3aaf", 
      "x": [3.651, 2.356, 2.393, -3.212, -1.71, 0.168, 0.571, 1.651, -3.167, -2.749, 1.062, -3.025, -1.208, -2.808, 3.558, -2.614, 3.608, -1.703, 2.664, 0.568, -1.122, -2.966, -1.708, -3.194, 1.104, -3.491, -2.217, -2.988, 2.392, -3.649, 0.435, 0.245, 2.008, 0.116, -1.038, -1.203, -2.242, -3.662, -1.932, 0.736, 3.394, -2.777, 3.014, -2.236, 0.397, 0.805, 1.159, -3.473, -1.466, 0.078], 
      "ysrc": "harry11733:104:f02577", 
      "y": [0.384, 0.258, -2.722, 1.85, -2.21, 2.159, 2.235, 1.947, 2.919, 3.374, -2.25, 0.19, 3.352, 3.415, -2.261, 0.11, -0.66, 3.319, -1.623, 0.86, -2.778, 2.068, -1.299, -1.137, -0.829, -3.486, 1.27, 1.696, 0.466, 2.01, 2.236, -3.854, 1.042, 3.273, -0.684, 2.187, -0.6, -0.132, -2.115, 2.8, -2.082, 3.557, 1.811, 1.531, -3.752, 2.529, -3.038, 3.101, 1.844, 2.457]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:4128c6", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184], 
      "ysrc": "harry11733:104:2b93cf", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116]
    }
  ], 
  "name": 184, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame186 = {
  "data": [
    {
      "xsrc": "harry11733:104:cf5747", 
      "x": [3.724, 2.158, 2.132, -3.622, -1.308, -0.038, 0.346, 1.139, -3.134, -2.475, 1.446, -3.383, -1.174, -3.062, 3.107, -2.824, 3.327, -1.483, 2.59, 0.255, -0.875, -2.841, -1.343, -3.121, 0.902, -3.54, -2.571, -2.759, 2.644, -3.734, 0.05, 0.183, 2.386, 0.545, -0.834, -1.53, -2.445, -3.806, -1.805, 0.948, 3.373, -3.122, 3.2, -1.835, 0.333, 0.777, 0.653, -3.749, -1.425, 0.086], 
      "ysrc": "harry11733:104:7a931b", 
      "y": [0.556, 0.525, -2.607, 1.732, -1.927, 1.437, 2.224, 2.139, 3.203, 3.352, -1.944, -0.062, 3.227, 2.729, -1.635, 0.132, -1.047, 3.043, -0.72, 0.858, -2.469, 1.623, -2.093, -1.599, -0.679, -3.718, 1.636, 1.541, 0.668, 1.783, 1.965, -3.806, 1.17, 3.039, -0.917, 2.455, -0.803, -0.562, -1.777, 3.032, -2.087, 3.613, 1.772, 1.186, -3.179, 2.322, -2.914, 3.061, 1.969, 2.248]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:792c65", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185], 
      "ysrc": "harry11733:104:b31807", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128]
    }
  ], 
  "name": 185, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame187 = {
  "data": [
    {
      "xsrc": "harry11733:104:2df548", 
      "x": [3.519, 2.054, 2.01, -3.517, -0.543, 0.183, 0.375, 0.982, -2.733, -1.986, 1.602, -3.417, -0.755, -3.213, 2.917, -3.446, 3.052, -1.474, 1.747, -0.026, -1.143, -3.087, -1.229, -3.073, 1.237, -3.1, -2.738, -2.929, 2.9, -3.375, -0.113, 0.509, 2.416, 0.377, -1.359, -1.536, -2.47, -3.738, -2.42, 0.38, 3.611, -3.084, 3.094, -1.825, 0.799, 0.653, 0.905, -3.606, -1.429, 0.622], 
      "ysrc": "harry11733:104:37acb7", 
      "y": [-0.007, 0.766, -2.582, 1.527, -1.907, 1.772, 2.412, 2.387, 3.212, 3.364, -2.393, 0.308, 3.042, 3.115, -1.985, 0.114, -1.434, 3.304, -0.803, 0.574, -2.331, 1.767, -1.955, -1.174, -1.207, -3.815, 1.281, 1.552, 0.309, 1.907, 1.423, -3.853, 0.94, 2.972, -0.885, 2.797, -1.183, -0.215, -2.289, 3.2, -2.085, 3.726, 1.273, 1.342, -3.234, 1.994, -3.332, 2.986, 2.84, 2.077]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:ef4d76", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186], 
      "ysrc": "harry11733:104:265d08", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144]
    }
  ], 
  "name": 186, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame188 = {
  "data": [
    {
      "xsrc": "harry11733:104:31ae47", 
      "x": [3.742, 1.716, 2.197, -3.515, -0.792, 0.244, 0.141, 1.209, -2.721, -2.315, 1.526, -3.597, -0.919, -2.79, 2.854, -3.679, 3.423, -1.979, 1.488, 0.167, -0.675, -3.46, -1.099, -2.721, 1.338, -3.203, -2.093, -2.556, 3.271, -3.086, 0.167, 0.081, 2.354, 0.457, -1.282, -2.307, -2.667, -3.689, -2.745, 0.19, 3.577, -3.394, 2.831, -1.544, 0.509, 0.735, 1.178, -3.536, -1.675, 0.259], 
      "ysrc": "harry11733:104:a7fb72", 
      "y": [0.123, 0.523, -3.002, 1.622, -1.585, 2.102, 2.738, 2.354, 3.698, 2.961, -2.003, 0.597, 3.23, 2.793, -2.182, 0.483, -1.377, 3.84, -0.241, 0.401, -2.784, 1.526, -1.79, -0.889, -1.761, -3.434, 1.107, 1.824, 0.428, 2.131, 1.195, -3.657, 0.54, 2.911, -0.726, 3.286, -1.376, -0.383, -2.126, 3.547, -2.235, 3.494, 1.416, 1.304, -3.358, 1.829, -3.292, 3.151, 2.56, 2.344]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:691db9", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187], 
      "ysrc": "harry11733:104:b3bb4f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104]
    }
  ], 
  "name": 187, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame189 = {
  "data": [
    {
      "xsrc": "harry11733:104:f469eb", 
      "x": [3.703, 2.271, 1.882, -3.37, -1.067, -0.019, 0.002, 1.522, -2.792, -2.477, 1.762, -3.585, -1.322, -2.929, 2.771, -3.592, 3.178, -1.499, 1.575, -0.189, -0.557, -2.969, -1.312, -2.547, 1.476, -3.408, -2.344, -2.625, 3.209, -2.788, 0.149, 0.176, 2.413, 0.515, -2.022, -2.79, -3.177, -3.68, -2.379, 0.44, 3.389, -3.601, 2.709, -1.685, 0.699, 0.569, 1.138, -3.804, -1.733, -0.144], 
      "ysrc": "harry11733:104:d4a87b", 
      "y": [0.256, 0.717, -2.79, 1.299, -1.766, 1.92, 3.389, 2.209, 3.825, 3.038, -1.856, 0.529, 2.9, 2.494, -2.534, 0.749, -1.174, 3.418, -0.272, -0.232, -2.137, 1.741, -1.798, -1.503, -1.449, -3.054, 0.831, 2.466, 0.122, 2.005, 1.048, -3.75, 0.742, 2.499, -0.978, 3.004, -1.297, -0.187, -2.608, 3.501, -1.872, 3.56, 1.398, 1.325, -3.603, 1.741, -3.341, 3.731, 2.58, 2.335]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:c2c5b1", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188], 
      "ysrc": "harry11733:104:1e808f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112]
    }
  ], 
  "name": 188, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame190 = {
  "data": [
    {
      "xsrc": "harry11733:104:0a076d", 
      "x": [3.799, 2.002, 2.321, -2.927, -0.785, 0.001, -0.144, 1.179, -2.957, -1.864, 1.975, -3.643, -1.328, -2.836, 2.573, -2.908, 2.79, -1.488, 0.868, -0.81, -0.721, -3.258, -1.569, -2.354, 1.827, -3.298, -2.269, -3.044, 2.776, -2.684, 0.758, 0.026, 2.494, 0.634, -1.557, -2.97, -3.436, -3.771, -1.43, -0.127, 3.807, -3.685, 2.517, -2.307, 0.895, 0.597, 1.162, -3.735, -1.532, -0.276], 
      "ysrc": "harry11733:104:ef1be4", 
      "y": [0.535, 1.017, -2.291, 1.11, -1.849, 2.15, 2.696, 2.081, 3.843, 2.717, -1.907, 0.838, 3.318, 2.249, -2.447, 0.845, -1.411, 3.134, -0.209, 0.177, -1.515, 2.475, -1.615, -1.573, -1.629, -2.882, 1.167, 2.083, -0.367, 1.401, 0.989, -3.694, 0.513, 2.46, -1.411, 3.001, -1.119, -0.307, -2.809, 3.61, -1.272, 3.04, 1.713, 1.633, -3.688, 2.009, -3.37, 3.799, 2.636, 3.06]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b685cf", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189], 
      "ysrc": "harry11733:104:6b7be7", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076]
    }
  ], 
  "name": 189, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame191 = {
  "data": [
    {
      "xsrc": "harry11733:104:bf0880", 
      "x": [3.796, 1.201, 1.974, -3.159, -1.207, 0.24, -0.106, 0.837, -3.004, -1.405, 1.771, -3.574, -1.346, -2.181, 3.364, -2.543, 2.817, -2.027, 0.558, -1.633, -0.907, -3.644, -1.562, -2.498, 1.062, -3.264, -2.479, -3.083, 2.661, -2.987, 0.689, 0.397, 2.073, 1.052, -1.593, -2.863, -3.305, -3.841, -1.561, -0.052, 3.562, -3.809, 2.869, -2.455, 1.026, 0.164, 1.23, -3.558, -1.294, -0.581], 
      "ysrc": "harry11733:104:b94678", 
      "y": [0.295, 0.409, -2.611, 1.142, -2.22, 2.048, 2.66, 2.042, 3.811, 3.193, -2.178, 0.755, 3.275, 2.52, -2.374, 0.526, -1.666, 3.015, -0.445, 0.106, -1.623, 2.042, -1.371, -1.586, -1.712, -2.887, 1.19, 2.275, -0.965, 1.342, 1.613, -3.818, 1.075, 3.389, -1.164, 2.628, -1.131, 0.411, -2.91, 3.695, -1.11, 3.26, 1.407, 1.258, -3.767, 2.351, -3.204, 3.499, 2.08, 3.431]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:401b64", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190], 
      "ysrc": "harry11733:104:718b14", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144]
    }
  ], 
  "name": 190, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame192 = {
  "data": [
    {
      "xsrc": "harry11733:104:66ea7d", 
      "x": [3.69, 1.071, 1.824, -3.012, -1.216, 0.267, -0.515, 1.134, -2.718, -1.153, 1.771, -3.447, -1.849, -2.014, 3.27, -2.436, 3.088, -2.437, 0.859, -1.905, -1.296, -2.923, -1.096, -2.652, 0.859, -3.655, -2.346, -2.866, 2.206, -3.653, 0.249, 0.149, 2.213, 0.299, -1.62, -2.951, -3.462, -3.787, -1.374, -0.41, 3.651, -3.737, 2.759, -2.721, 1.362, 0.45, 1.169, -2.406, -1.788, -0.476], 
      "ysrc": "harry11733:104:4f91f8", 
      "y": [0.524, 0.25, -2.791, 0.927, -1.926, 2.331, 2.212, 1.705, 3.608, 3.082, -1.671, 1.13, 3.003, 2.494, -2.957, 0.693, -1.749, 3.355, -0.48, 0.305, -1.316, 1.968, -1.94, -1.397, -1.257, -3.264, 1.66, 2.476, -1.22, 1.333, 1.638, -3.474, 1.401, 3.648, -0.896, 2.25, -0.938, 0.446, -2.731, 3.579, -1.372, 3.116, 1.107, 1.18, -3.446, 2.179, -3.224, 3.751, 1.827, 3.172]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:596df8", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191], 
      "ysrc": "harry11733:104:2c85c5", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212]
    }
  ], 
  "name": 191, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame193 = {
  "data": [
    {
      "xsrc": "harry11733:104:297411", 
      "x": [3.314, 1.499, 2.184, -2.964, -0.561, 0.058, -0.637, 1.317, -2.762, -1.447, 2.023, -3.262, -1.951, -1.983, 3.026, -1.6, 2.757, -2.536, 1.046, -1.828, -1.527, -3.09, -0.859, -2.337, 1.099, -3.357, -2.06, -2.657, 1.914, -3.822, 0.606, 0.534, 2.378, 0.52, -1.985, -2.433, -3.605, -3.768, -1.031, -0.178, 3.3, -3.766, 3.157, -3.15, 0.855, 0.5, 1.467, -2.605, -1.76, -0.345], 
      "ysrc": "harry11733:104:eca966", 
      "y": [0.612, -0.488, -2.715, 1.368, -2.035, 2.008, 2.2, 1.189, 3.756, 2.756, -1.637, 1.312, 3.271, 2.366, -3.265, 1.072, -1.806, 3.475, -0.594, 0.362, -1.497, 1.908, -1.685, -1.314, -1.12, -3.647, 1.62, 2.473, -0.698, 1.231, 1.287, -3.343, 1.502, 3.345, -1.28, 2.061, -0.6, 0.762, -2.892, 3.826, -1.353, 2.902, 1.35, 1.314, -3.211, 2.152, -3.26, 3.579, 1.884, 3.223]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:695448", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192], 
      "ysrc": "harry11733:104:3cf141", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276]
    }
  ], 
  "name": 192, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame194 = {
  "data": [
    {
      "xsrc": "harry11733:104:c8b9ce", 
      "x": [3.022, 1.371, 2.297, -2.975, -0.675, 0.447, -0.871, 1.503, -2.34, -1.283, 2.334, -2.909, -2.186, -2.349, 2.947, -1.153, 2.324, -2.635, 0.583, -1.587, -1.543, -2.699, -0.767, -2.271, 0.976, -3.361, -1.288, -3.115, 1.756, -3.432, 0.803, 0.858, 2.177, 0.549, -1.851, -2.58, -3.774, -3.217, -1.148, -0.293, 3.394, -3.846, 3.468, -2.777, 1.002, 0.562, 1.476, -2.383, -1.782, -0.618], 
      "ysrc": "harry11733:104:3da189", 
      "y": [0.804, -0.325, -2.721, 1.462, -2.227, 1.961, 2.177, 1.318, 3.805, 2.63, -1.277, 1.654, 3.783, 2.572, -3.136, 0.972, -1.827, 2.7, -0.214, -0.101, -1.368, 1.726, -1.438, -1.113, -1.317, -3.474, 0.925, 2.615, -0.979, 1.092, 0.998, -3.019, 1.802, 3.243, -1.303, 1.885, -0.83, 0.54, -3.08, 3.651, -1.126, 3.159, 0.84, 1.338, -2.589, 2.189, -3.513, 3.544, 2.414, 3.146]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:bb24b9", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193], 
      "ysrc": "harry11733:104:35d375", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284]
    }
  ], 
  "name": 193, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame195 = {
  "data": [
    {
      "xsrc": "harry11733:104:39e261", 
      "x": [2.754, 1.409, 2.178, -3.658, -0.662, 0.865, -0.602, 1.881, -2.713, -0.424, 2.802, -2.76, -1.985, -3.064, 2.533, -0.838, 2.356, -3.017, 0.206, -1.746, -1.726, -2.475, -1.125, -1.843, 1.176, -3.76, -1.333, -2.431, 1.674, -3.055, 1.193, 0.534, 1.959, 0.564, -1.793, -2.894, -3.75, -3.16, -0.813, 0.526, 3.709, -3.793, 3.602, -3.076, 0.976, 0.463, 1.059, -2.58, -1.687, -0.636], 
      "ysrc": "harry11733:104:31193a", 
      "y": [1.053, -0.706, -2.619, 0.849, -2.304, 1.935, 2.047, 1.568, 3.388, 2.813, -0.751, 1.79, 3.326, 1.911, -2.635, 1.156, -1.851, 2.385, -0.316, -0.372, -1.585, 1.46, -1.329, -1.116, -1.235, -3.334, 1.372, 3.526, -0.975, 1.412, 1.267, -3.221, 2.272, 3.516, -1.626, 1.876, -0.607, 0.206, -2.628, 3.775, -1.096, 2.954, 0.783, 1.638, -2.226, 2.829, -3.502, 3.793, 2.623, 3.409]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:8a71f4", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194], 
      "ysrc": "harry11733:104:f46e5b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324]
    }
  ], 
  "name": 194, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame196 = {
  "data": [
    {
      "xsrc": "harry11733:104:009e48", 
      "x": [2.793, 1.407, 1.94, -3.714, -1.519, 0.851, -0.463, 2.055, -2.721, -0.407, 2.448, -2.64, -1.797, -3.43, 2.164, -0.823, 2.091, -2.888, 0.484, -1.421, -1.927, -2.561, -0.713, -1.711, 1.362, -3.497, -1.479, -2.387, 1.129, -3.259, 1.009, 0.779, 1.965, 0.943, -2.191, -3.162, -3.646, -2.886, -0.854, 0.492, 3.218, -3.761, 3.008, -3.304, 0.975, 0.276, 0.842, -2.667, -2.181, -0.971], 
      "ysrc": "harry11733:104:afd5fc", 
      "y": [0.796, -0.32, -2.957, 0.4, -1.979, 1.756, 1.951, 1.913, 3.488, 2.658, -1.133, 1.404, 2.903, 1.897, -2.69, 1.544, -2.142, 2.505, 0.226, -0.448, -1.715, 1.402, -1.189, -0.976, -1.362, -3.581, 1.217, 3.733, -0.692, 1.997, 1.319, -3.587, 2.584, 3.346, -1.495, 1.706, -0.73, 0.517, -2.884, 3.75, -0.973, 2.926, 0.564, 1.159, -2.394, 2.74, -3.79, 3.807, 2.552, 3.025]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:663c1e", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195], 
      "ysrc": "harry11733:104:6ece00", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324, 0.74]
    }
  ], 
  "name": 195, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame197 = {
  "data": [
    {
      "xsrc": "harry11733:104:4e0dcc", 
      "x": [2.998, 1.516, 1.593, -3.387, -1.779, 0.793, -0.55, 1.48, -2.673, -0.381, 2.069, -2.174, -1.878, -3.58, 2.298, -0.825, 2.591, -3.274, 0.738, -1.076, -2.082, -2.133, -0.505, -1.423, 1.309, -3.655, -1.733, -2.574, 1.368, -3.073, 1.161, 0.542, 1.334, 0.944, -2.637, -3.755, -3.184, -3.709, -0.915, 0.198, 2.936, -3.809, 2.967, -3.245, 0.757, 0.232, 0.989, -3.046, -2.561, -1.053], 
      "ysrc": "harry11733:104:c70a56", 
      "y": [1.055, -0.162, -2.834, 0.233, -2.592, 1.703, 1.863, 1.739, 3.412, 2.3, -1.721, 0.995, 2.866, 2.057, -2.347, 1.543, -2.723, 2.484, -0.073, 0.055, -2.199, 1.697, -0.967, -0.954, -1.795, -3.852, 1.12, 3.757, -0.833, 1.496, 1.404, -3.299, 2.274, 3.38, -1.578, 1.975, -0.799, 0.126, -2.67, 3.768, -0.85, 3.151, 0.72, 0.976, -2.022, 3.288, -3.436, 3.391, 2.68, 2.75]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:38b351", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196], 
      "ysrc": "harry11733:104:2c602e", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324, 0.74, 0.738]
    }
  ], 
  "name": 196, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame198 = {
  "data": [
    {
      "xsrc": "harry11733:104:ff85b4", 
      "x": [2.45, 1.428, 1.634, -3.257, -1.621, 0.835, -0.388, 1.494, -2.384, -0.385, 2.011, -2.114, -1.117, -3.841, 2.038, -0.551, 2.671, -3.41, 0.573, -1.186, -2.214, -2.31, -0.617, -1.091, 1.5, -3.745, -1.71, -2.957, 1.316, -2.972, 1.002, 0.43, 1.016, 0.716, -2.495, -3.587, -2.974, -3.743, -1.366, 0.676, 2.89, -3.536, 3.316, -2.739, 0.898, 0.23, 1.484, -2.92, -2.049, -1.419], 
      "ysrc": "harry11733:104:be8127", 
      "y": [1.478, -0.287, -2.532, 0.405, -2.742, 2.32, 2.228, 2.014, 3.763, 1.761, -1.645, 0.368, 3.084, 1.915, -2.172, 1.53, -2.739, 2.922, 0.127, 0.243, -2.524, 1.898, -0.741, -1.163, -1.516, -3.769, 1.451, 3.271, -0.791, 1.526, 1.002, -3.455, 2.221, 3.28, -1.663, 1.468, -0.791, 0.394, -2.564, 3.129, -0.428, 3.05, 0.111, 0.839, -2.441, 3.103, -3.398, 3.678, 2.5, 2.958]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:603bd5", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197], 
      "ysrc": "harry11733:104:f2007a", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324, 0.74, 0.738, 0.748]
    }
  ], 
  "name": 197, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame199 = {
  "data": [
    {
      "xsrc": "harry11733:104:2803a4", 
      "x": [1.997, 1.146, 1.759, -3.693, -1.105, 1.057, -0.3, 1.744, -2.751, -0.994, 2.019, -2.613, -1.37, -3.853, 1.524, -0.485, 3.234, -3.44, 0.443, -1.62, -2.142, -2.152, -0.101, -1.488, 1.73, -3.762, -1.583, -3.139, 1.354, -2.889, 1.408, 0.089, 0.784, 1.056, -2.178, -3.573, -2.934, -3.697, -1.506, 0.222, 2.593, -3.53, 3.129, -2.771, 1.578, 0.172, 2.028, -3.515, -2.336, -1.496], 
      "ysrc": "harry11733:104:d164db", 
      "y": [0.793, 0.178, -2.605, 0.459, -2.888, 2.133, 1.909, 2.169, 3.389, 1.462, -1.94, 0.064, 3.448, 1.776, -2.152, 1.956, -2.26, 2.997, -0.227, 0.254, -2.465, 1.43, -0.127, -1.021, -1.501, -3.584, 1.218, 3.312, -1.124, 1.26, 1.2, -3.695, 1.971, 2.608, -2.045, 2.005, -1.27, 0.389, -2.502, 3.325, -0.144, 3.572, -0.018, 0.392, -3.057, 3.059, -3.04, 3.844, 2.305, 2.866]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:0827e0", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198], 
      "ysrc": "harry11733:104:4dbf9f", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324, 0.74, 0.738, 0.748, 0.744]
    }
  ], 
  "name": 198, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame200 = {
  "data": [
    {
      "xsrc": "harry11733:104:22de7f", 
      "x": [1.987, 1.193, 2.729, -3.268, -1.226, 1.479, -0.154, 1.803, -2.746, -0.891, 2.025, -2.265, -1.123, -3.644, 1.555, -0.757, 2.938, -3.273, 0.8, -1.233, -2.549, -2.693, -0.156, -1.268, 1.678, -3.813, -1.544, -3.621, 0.931, -2.562, 1.441, 0.481, 0.656, 0.832, -2.197, -3.541, -2.842, -3.052, -1.071, 0.487, 2.667, -3.398, 2.524, -2.252, 1.597, -0.222, 1.583, -3.739, -2.41, -1.542], 
      "ysrc": "harry11733:104:60725b", 
      "y": [0.731, -0.164, -2.54, 0.584, -3.064, 2.191, 2.402, 1.97, 3.445, 0.812, -2.925, 0.353, 3.232, 1.887, -1.732, 1.973, -1.774, 3.735, 0.133, 0.417, -2.586, 1.51, -0.358, -0.859, -1.225, -3.516, 1.553, 3.063, -1.109, 1.566, 1.58, -3.826, 1.817, 2.42, -1.665, 1.936, -1.573, 0.141, -2.149, 3.482, -0.894, 3.272, 0.264, 0.548, -3.616, 2.584, -2.748, 3.814, 1.987, 3.124]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:471f05", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199], 
      "ysrc": "harry11733:104:d7ae8b", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324, 0.74, 0.738, 0.748, 0.744, 0.7456]
    }
  ], 
  "name": 199, 
  "traces": [0, 1, 2], 
  "layout": }
}
frame201 = {
  "data": [
    {
      "xsrc": "harry11733:104:73d2c0", 
      "x": [1.885, 0.731, 2.096, -3.183, -1.872, 1.46, -0.364, 2.169, -2.754, -0.319, 2.21, -1.935, -0.637, -3.304, 1.358, -1.049, 2.43, -2.844, 0.774, -1.116, -2.47, -2.212, -0.34, -0.689, 1.911, -3.858, -1.438, -3.807, 1.071, -2.187, 1.987, -0.211, 0.558, 0.323, -1.566, -3.06, -3.162, -2.975, -0.858, 0.836, 2.986, -3.6, 2.489, -1.82, 1.843, 0.508, 1.198, -3.604, -2.101, -0.905], 
      "ysrc": "harry11733:104:c5aed1", 
      "y": [0.584, -0.212, -2.876, 0.369, -2.945, 2.348, 2.527, 1.946, 3.164, 0.343, -2.891, 0.157, 2.834, 1.459, -1.902, 2.368, -1.749, 3.47, 0.003, -0.243, -2.45, 1.955, 0.187, -1.065, -1.487, -3.161, 1.668, 2.737, -1.109, 1.238, 1.977, -3.575, 2.286, 2.594, -1.665, 1.851, -1.848, 0.586, -1.939, 3.245, -1.325, 2.935, 0.4, 0.851, -3.72, 2.859, -2.974, 3.767, 1.651, 3.012]
    }, 
    {
      "line": {"color": "green"}, 
      "xsrc": "harry11733:104:a4fa8e", 
      "x": [0.0, 0.0], 
      "ysrc": "harry11733:104:72b2c9", 
      "y": [-4.0, 4.0]
    }, 
    {
      "xsrc": "harry11733:104:b7c232", 
      "x": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200], 
      "ysrc": "harry11733:104:c8b53d", 
      "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0368, 0.0692, 0.0772, 0.1004, 0.1164, 0.1332, 0.1468, 0.1584, 0.1656, 0.1812, 0.1864, 0.1944, 0.204, 0.222, 0.2232, 0.2324, 0.2372, 0.2516, 0.2664, 0.2776, 0.2872, 0.2904, 0.2976, 0.3072, 0.3072, 0.3136, 0.3228, 0.3324, 0.3424, 0.3376, 0.3464, 0.3488, 0.364, 0.3648, 0.3772, 0.3744, 0.3792, 0.3828, 0.386, 0.3884, 0.3948, 0.4004, 0.402, 0.3988, 0.4072, 0.4104, 0.4168, 0.4236, 0.4316, 0.428, 0.4332, 0.4364, 0.4412, 0.4484, 0.4508, 0.4596, 0.4684, 0.468, 0.4732, 0.4792, 0.4792, 0.4844, 0.484, 0.4992, 0.5036, 0.5028, 0.5036, 0.5152, 0.5064, 0.512, 0.5196, 0.5312, 0.5216, 0.5432, 0.5428, 0.5444, 0.5492, 0.564, 0.5612, 0.558, 0.5688, 0.5696, 0.5688, 0.5728, 0.5792, 0.5788, 0.586, 0.5832, 0.5796, 0.58, 0.578, 0.5836, 0.594, 0.5888, 0.5976, 0.6028, 0.6088, 0.6012, 0.6056, 0.6148, 0.6084, 0.614, 0.616, 0.6204, 0.6248, 0.6256, 0.6392, 0.6368, 0.6392, 0.6484, 0.6404, 0.6444, 0.6584, 0.664, 0.6644, 0.6656, 0.6628, 0.654, 0.672, 0.6764, 0.678, 0.682, 0.6804, 0.6864, 0.69, 0.6872, 0.6844, 0.6896, 0.6944, 0.6972, 0.6988, 0.702, 0.7116, 0.7116, 0.7128, 0.7144, 0.7104, 0.7112, 0.7076, 0.7144, 0.7212, 0.7276, 0.7284, 0.7324, 0.74, 0.738, 0.748, 0.744, 0.7456, 0.7464]
    }
  ], 
  "name": 200, 
  "traces": [0, 1, 2], 
  "layout": }
}
frames = Frames([frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10, frame11, frame12, frame13, frame14, frame15, frame16, frame17, frame18, frame19, frame20, frame21, frame22, frame23, frame24, frame25, frame26, frame27, frame28, frame29, frame30, frame31, frame32, frame33, frame34, frame35, frame36, frame37, frame38, frame39, frame40, frame41, frame42, frame43, frame44, frame45, frame46, frame47, frame48, frame49, frame50, frame51, frame52, frame53, frame54, frame55, frame56, frame57, frame58, frame59, frame60, frame61, frame62, frame63, frame64, frame65, frame66, frame67, frame68, frame69, frame70, frame71, frame72, frame73, frame74, frame75, frame76, frame77, frame78, frame79, frame80, frame81, frame82, frame83, frame84, frame85, frame86, frame87, frame88, frame89, frame90, frame91, frame92, frame93, frame94, frame95, frame96, frame97, frame98, frame99, frame100, frame101, frame102, frame103, frame104, frame105, frame106, frame107, frame108, frame109, frame110, frame111, frame112, frame113, frame114, frame115, frame116, frame117, frame118, frame119, frame120, frame121, frame122, frame123, frame124, frame125, frame126, frame127, frame128, frame129, frame130, frame131, frame132, frame133, frame134, frame135, frame136, frame137, frame138, frame139, frame140, frame141, frame142, frame143, frame144, frame145, frame146, frame147, frame148, frame149, frame150, frame151, frame152, frame153, frame154, frame155, frame156, frame157, frame158, frame159, frame160, frame161, frame162, frame163, frame164, frame165, frame166, frame167, frame168, frame169, frame170, frame171, frame172, frame173, frame174, frame175, frame176, frame177, frame178, frame179, frame180, frame181, frame182, frame183, frame184, frame185, frame186, frame187, frame188, frame189, frame190, frame191, frame192, frame193, frame194, frame195, frame196, frame197, frame198, frame199, frame200, frame201])

# Frames are not yet supported for use with Python.
fig = Figure(data=data, layout=layout)
plot_url = py.plot(fig)